﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostUsuario;

namespace AplicacaoCliente.FormUser
{
    public partial class FormNovocadastro : Form
    {
        public FormNovocadastro()
        {
            InitializeComponent();
        }

        private void textBoxNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonConfirmar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario usuario = new Usuario();
                ServiceUsuario srv = new ServiceUsuario();
                usuario.NomeUser = textBoxNome.Text;
                usuario.RgUser = textBoxRG.Text;
                usuario.CpfUser = maskedTextBoxCPF.Text;
                usuario.LoginUser = textBoxLogin.Text;
                if (textBoxSenha.Text != textBoxSenha2.Text) 
                {
                    MessageBox.Show("As senhas não conicidem.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); 
                    return;
                }
                usuario.SenhaUser = textBoxSenha.Text;

                srv.inserirUsuario(usuario);
                MessageBox.Show("Usuário "+usuario.NomeUser+" registrado com êxito.", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }
    }
}
