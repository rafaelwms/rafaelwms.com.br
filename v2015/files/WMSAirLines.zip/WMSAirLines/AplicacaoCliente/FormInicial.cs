﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.FormUser;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostUsuario;
using AplicacaoCliente.FormRH;
using AplicacaoCliente.FormAdm;

namespace AplicacaoCliente
{
    public partial class FormInicial : Form
    {
        Usuario logado = new Usuario();

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        public FormInicial()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (checkBoxFunc.Checked == false)
            {
                Usuario logon = new Usuario();
                logon.LoginUser = textBoxLogin.Text;
                logon.SenhaUser = textBoxSenha.Text;
                ServiceUsuario srvu = new ServiceUsuario();
                try
                {
                    logado = srvu.procurarUsuarios(logon);
                    if (logado.NomeUser != null && logado.NomeUser.Trim() != "")
                    {
                        MessageBox.Show("Usuario " + logado.NomeUser + " conectado com êxito.", "AUTENTICAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(MensagemValidaErro(ex.Message), "FALHA NA AUTENTICAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }

            if (checkBoxFunc.Checked == true)
            {
                try
                {
                    Funcionario logado = new Funcionario();
                    List<Funcionario> login = new List<Funcionario>();
                    ServiceEmpresa srv = new ServiceEmpresa();
                    login = srv.listarFuncionarios().ToList();
                    foreach (Funcionario tst in login)
                    {
                        if ((textBoxLogin.Text == tst.LoginFunc) && (textBoxSenha.Text == tst.SenhaFunc))
                        {
                            logado = tst;
                            break;
                        }

                    }
                    if (logado.CargoFunc == null)
                    {
                        MessageBox.Show("Login e/ou senha inválidos.", "FALHA NA AUTENTICAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        textBoxLogin.Clear();
                        textBoxSenha.Clear();
                        textBoxLogin.Focus();
                        return;
                    }

                    if (logado.CargoFunc == "Ag Administrativo")
                    {
                        FormAgAdm formAdm = new FormAgAdm(logado);
                        this.Hide();
                        formAdm.ShowDialog();
                        textBoxLogin.Clear();
                        textBoxSenha.Clear();
                        this.Show();
                    }

                    if (logado.CargoFunc == "RH")
                    {
                        FormRecHum formRH = new FormRecHum(logado);
                        this.Hide();
                        formRH.ShowDialog();
                        textBoxLogin.Clear();
                        textBoxSenha.Clear();
                        this.Show();
                    }


                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }

            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FormNovocadastro novo = new FormNovocadastro();
            novo.ShowDialog();
            this.Show();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void textBoxLogin_TextChanged(object sender, EventArgs e)
        {

            if ((textBoxSenha.Text.Trim().Length < 4) && (textBoxLogin.Text.Trim().Length < 4))
            {

                buttonConectar.Enabled = false;
            }


            if ((textBoxSenha.Text.Trim().Length >= 4) && (textBoxLogin.Text.Trim().Length >= 4))
            {

                buttonConectar.Enabled = true;
            }


        }

        private void textBoxSenha_TextChanged(object sender, EventArgs e)
        {

            if ((textBoxSenha.Text.Trim().Length < 4) && (textBoxLogin.Text.Trim().Length < 4))
            {

                buttonConectar.Enabled = false;
            }


            if ((textBoxSenha.Text.Trim().Length >= 4) && (textBoxLogin.Text.Trim().Length >= 4))
            {

                buttonConectar.Enabled = true;
            }

        }
    }
}
