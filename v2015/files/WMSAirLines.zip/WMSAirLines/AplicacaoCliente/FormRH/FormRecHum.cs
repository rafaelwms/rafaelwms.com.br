﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;


namespace AplicacaoCliente.FormRH
{
    public partial class FormRecHum : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormRecHum(Funcionario func)
        {
            logado = func;
            InitializeComponent();
            label3.Text = "Usuário: "+logado.NomeFunc;
        }

        private void buttonManterFunc_Click(object sender, EventArgs e)
        {
            FormManterFuncionario mfunc = new FormManterFuncionario(logado);
            this.Hide();
            mfunc.ShowDialog();
            this.Show();
        }

        private void buttonManterPiloto_Click(object sender, EventArgs e)
        {
            FormManterPiloto mpiloto = new FormManterPiloto(logado);
            this.Hide();
            mpiloto.ShowDialog();
            this.Show();
        }

        private void buttonManterBordo_Click(object sender, EventArgs e)
        {
            FormManterAgBordo form = new FormManterAgBordo(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void buttonManterLocal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sistema em Construção, requisito desejável.", "EM CONSTRUÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


    }
}
