﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormRH
{
    public partial class FormManterPiloto : Form
    {
        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormManterPiloto(Funcionario func)
        {
            logado = func;
            InitializeComponent();
            refreshListaFunc();
            label3.Text = "Bem vindo: " + logado.NomeFunc.ToString();
        }

        void refreshListaFunc()
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            List<Piloto> lista = new List<Piloto>();
            lista = srv.listarPilotos().ToList();
            foreach (Piloto func in lista)
            {
                if ((func != null) && (func.CargoFunc == "Piloto"))
                {
                    String ativo = "Disponível";
                    if (func.Disp == 0)
                    {
                        ativo = "Demitido";
                    }
                    if (func.Disp == 2)
                    {
                        ativo = "Em Voo";
                    }


                    String[] linha = { func.NomeFunc.ToString(), func.CpfFunc.ToString(), func.Breve.ToString(), func.HorasVoo.ToString(), ativo };
                    listViewPilotos.Items.Add(func.CodPiloto.ToString()).SubItems.AddRange(linha);
                }
            }

        }

        void alterarPiloto() 
        {


            try
            {
                ServiceEmpresa srv = new ServiceEmpresa();
                Piloto alterar = new Piloto();
                ListViewItem select = new ListViewItem();
                select = listViewPilotos.SelectedItems[0];
                int codFunc = int.Parse(select.Text);
                List<Piloto> teste = new List<Piloto>();
                teste = srv.listarPilotos().ToList();
                foreach (Piloto tst in teste)
                {
                    if (codFunc == tst.CodPiloto)
                    {
                        alterar = tst;
                    }
                }
                FormAltPiloto alterFunc = new FormAltPiloto(logado, alterar);
                this.Hide();
                alterFunc.ShowDialog();
                listViewPilotos.Items.Clear();
                refreshListaFunc();
                this.Show();
                buttonDemitirFunc.Enabled = false;
                buttonAlterarFunc.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA");
            }
        }

        void demitirPiloto() 
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            ListViewItem select = new ListViewItem();
            select = listViewPilotos.SelectedItems[0];
            int codPiloto = int.Parse(select.Text);

            localhostEmpresa.Piloto demitido = new localhostEmpresa.Piloto();
            demitido.CodPiloto = codPiloto;

            List<localhostEmpresa.Piloto> lis = new List<localhostEmpresa.Piloto>();
            lis = srv.listarPilotos().ToList();
            foreach (Piloto tst in lis)
            {
                if (demitido.CodPiloto == tst.CodPiloto)
                {
                    demitido = tst;
                }
            }
            try
            {
                if (MessageBox.Show("Tem certeza que deseja demitir o Piloto " + select.SubItems[1].Text + "?", "Confirmação de Demissão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    srv.demitirPiloto(demitido);
                    MessageBox.Show("Demissão efetuada com êxito.", "Confirmação de Demissão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    listViewPilotos.Items.Clear();
                    refreshListaFunc();
                    buttonDemitirFunc.Enabled = false;
                    buttonAlterarFunc.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA");
            }
        
        }

        void procurarPiloto() 
        {
            try
            {
                listViewPilotos.Items.Clear();
                ServiceEmpresa srv = new ServiceEmpresa();
                List<Piloto> lista = new List<Piloto>();
                lista = srv.procurarPilotos(textBox1.Text).ToList();
                foreach (Piloto func in lista)
                {
                    if ((func != null) && (func.CargoFunc == "Piloto"))
                    {
                        String ativo = "Disponível";
                        if (func.Disp == 0)
                        {
                            ativo = "Demitido";
                        }
                        if (func.Ativo == 2)
                        {
                            ativo = "Em Voo";
                        }


                        String[] linha = { func.NomeFunc.ToString(), func.CpfFunc.ToString(), func.Breve.ToString(), func.HorasVoo.ToString(), ativo };
                        listViewPilotos.Items.Add(func.CodPiloto.ToString()).SubItems.AddRange(linha);
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA");
            }
        
        }

        private void buttonInserirFunc_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInsPiloto insfunc = new FormInsPiloto(logado);
            insfunc.ShowDialog();
            listViewPilotos.Items.Clear();
            refreshListaFunc();

            this.Show();
        }

        private void buttonDemitirFunc_Click(object sender, EventArgs e)
        {
            if (listViewPilotos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um piloto na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            this.demitirPiloto();
        }

        private void buttonAlterarFunc_Click(object sender, EventArgs e)
        {
            if (listViewPilotos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um piloto na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            this.alterarPiloto();
        }

        private void listViewFunc_MouseClick(object sender, MouseEventArgs e)
        {
            buttonDemitirFunc.Enabled = true;
            buttonAlterarFunc.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.procurarPiloto();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listViewPilotos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
