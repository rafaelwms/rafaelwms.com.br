﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormRH
{
    public partial class FormAlterarFuncionario : Form
    {
        Funcionario temp = new Funcionario();
        public FormAlterarFuncionario(Funcionario func)
        {
            temp = func;
            InitializeComponent();
            textBoxNome.Text = func.NomeFunc;
            textBox1.Text = func.RgFunc;
            maskedTextBox1.Text = func.CpfFunc;
            textBoxLogin.Text = func.LoginFunc;
            textBoxSalario.Text = func.Salario.ToString();
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }


        private void buttonConfirmar_Click(object sender, EventArgs e)
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            Funcionario novoFunc = new Funcionario();

            if (textBoxSenhaAtual.Text != temp.SenhaFunc) 
            {
                MessageBox.Show("A senha atual não confere.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (textBoxSenha.Text != textBoxSenha2.Text)
            {
                MessageBox.Show("As senhas não coincidem.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            temp.NomeFunc = textBoxNome.Text;
            temp.RgFunc = textBox1.Text;
            temp.CpfFunc = maskedTextBox1.Text;
            temp.LoginFunc = textBoxLogin.Text;
            temp.SenhaFunc = textBoxSenha.Text;
            temp.Salario = Decimal.Parse(textBoxSalario.Text);
            if (comboBoxCargo.SelectedItem == null) 
            {
                MessageBox.Show("Selecione um cargo.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            temp.CargoFunc = comboBoxCargo.SelectedItem.ToString();

            try
            {
                
                srv.alterarFuncionario(temp);
                textBoxNome.Clear();
                textBox1.Clear();
                maskedTextBox1.Clear();
                textBoxLogin.Clear();
                textBoxSenha.Clear();
                textBoxSenha2.Clear();
                textBoxSenhaAtual.Clear();
                textBoxSalario.Clear();
                comboBoxCargo.ResetText();
                MessageBox.Show("Funcionário "+temp.NomeFunc+" alterado com êxito.", "CONFIRMAÇÃO DE INCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
