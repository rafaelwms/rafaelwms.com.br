﻿namespace AplicacaoCliente.FormRH
{
    partial class FormRecHum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonManterBordo = new System.Windows.Forms.Button();
            this.buttonManterLocal = new System.Windows.Forms.Button();
            this.buttonManterPiloto = new System.Windows.Forms.Button();
            this.buttonManterFunc = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonManterBordo);
            this.groupBox1.Controls.Add(this.buttonManterLocal);
            this.groupBox1.Controls.Add(this.buttonManterPiloto);
            this.groupBox1.Controls.Add(this.buttonManterFunc);
            this.groupBox1.Location = new System.Drawing.Point(12, 70);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(317, 114);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gerenciar";
            // 
            // buttonManterBordo
            // 
            this.buttonManterBordo.Location = new System.Drawing.Point(160, 73);
            this.buttonManterBordo.Name = "buttonManterBordo";
            this.buttonManterBordo.Size = new System.Drawing.Size(148, 23);
            this.buttonManterBordo.TabIndex = 3;
            this.buttonManterBordo.Text = "Agente de Bordo";
            this.buttonManterBordo.UseVisualStyleBackColor = true;
            this.buttonManterBordo.Click += new System.EventHandler(this.buttonManterBordo_Click);
            // 
            // buttonManterLocal
            // 
            this.buttonManterLocal.Location = new System.Drawing.Point(6, 73);
            this.buttonManterLocal.Name = "buttonManterLocal";
            this.buttonManterLocal.Size = new System.Drawing.Size(148, 23);
            this.buttonManterLocal.TabIndex = 2;
            this.buttonManterLocal.Text = "Agente Local";
            this.buttonManterLocal.UseVisualStyleBackColor = true;
            this.buttonManterLocal.Click += new System.EventHandler(this.buttonManterLocal_Click);
            // 
            // buttonManterPiloto
            // 
            this.buttonManterPiloto.Location = new System.Drawing.Point(160, 19);
            this.buttonManterPiloto.Name = "buttonManterPiloto";
            this.buttonManterPiloto.Size = new System.Drawing.Size(148, 23);
            this.buttonManterPiloto.TabIndex = 1;
            this.buttonManterPiloto.Text = "Piloto";
            this.buttonManterPiloto.UseVisualStyleBackColor = true;
            this.buttonManterPiloto.Click += new System.EventHandler(this.buttonManterPiloto_Click);
            // 
            // buttonManterFunc
            // 
            this.buttonManterFunc.Location = new System.Drawing.Point(6, 19);
            this.buttonManterFunc.Name = "buttonManterFunc";
            this.buttonManterFunc.Size = new System.Drawing.Size(148, 23);
            this.buttonManterFunc.TabIndex = 0;
            this.buttonManterFunc.Text = "Funcionário";
            this.buttonManterFunc.UseVisualStyleBackColor = true;
            this.buttonManterFunc.Click += new System.EventHandler(this.buttonManterFunc_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(245, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "WMS Systems®";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SketchFlow Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 21);
            this.label2.TabIndex = 2;
            this.label2.Text = "Recursos Humanos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Bem vindo ";
            // 
            // FormRecHum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 217);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormRecHum";
            this.Text = "Acesso Recursos Humanos";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonManterBordo;
        private System.Windows.Forms.Button buttonManterLocal;
        private System.Windows.Forms.Button buttonManterPiloto;
        private System.Windows.Forms.Button buttonManterFunc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}