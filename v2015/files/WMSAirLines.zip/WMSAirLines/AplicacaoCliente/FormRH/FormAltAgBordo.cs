﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormRH
{
    public partial class FormAltAgBordo : Form
    {
        Funcionario logado = new Funcionario();
        AgenteBordo temp = new AgenteBordo();
        public FormAltAgBordo(Funcionario func, AgenteBordo agbordo)
        {
            temp = agbordo;
            logado = func;
            InitializeComponent();
            label11.Text = "Bem vindo: " + logado.NomeFunc.ToString();
            textBoxNome.Text = temp.NomeFunc;
            textBox1.Text = temp.RgFunc;
            maskedTextBox1.Text = temp.CpfFunc;
            textBoxLogin.Text = temp.LoginFunc;
            textBoxSenha.Text = temp.SenhaFunc;
            textBoxSenha2.Text = temp.SenhaFunc;
            textBoxSalario.Text = temp.Salario.ToString();
            if (temp.Enfermeiro == 1) 
            {
                checkBox1.Checked = true;
            }
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        private void buttonConfirmar_Click(object sender, EventArgs e)
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            localhostEmpresa.AgenteBordo novo = new localhostEmpresa.AgenteBordo();

            if (textBoxSenha.Text != textBoxSenha2.Text)
            {
                MessageBox.Show("As senhas não coincidem.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            novo.CodFunc = temp.CodFunc;
            novo.CodAgBordo = temp.CodAgBordo;
            novo.Ativo = temp.Ativo;
            novo.NomeFunc = textBoxNome.Text;
            novo.RgFunc = textBox1.Text;
            novo.CpfFunc = maskedTextBox1.Text;
            novo.LoginFunc = textBoxLogin.Text;
            novo.SenhaFunc = textBoxSenha.Text;
            novo.Salario = Decimal.Parse(textBoxSalario.Text);
            novo.CargoFunc = "Ag de Bordo";
            if (checkBox1.Checked == true) 
            {
                novo.Enfermeiro = 1;
            }
            if (checkBox1.Checked == false)
            {
                novo.Enfermeiro = 0;
            }
            novo.Disp = 1;
            
            try
            {

                srv.alterarAgenteBordo(novo);
                textBoxNome.Clear();
                textBox1.Clear();
                maskedTextBox1.Clear();
                textBoxLogin.Clear();
                textBoxSenha.Clear();
                textBoxSalario.Clear();
                checkBox1.Checked = false;
                MessageBox.Show("Agente de Bordo "+novo.NomeFunc+" alterado com êxito.", "CONFIRMAÇÃO DE INCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
