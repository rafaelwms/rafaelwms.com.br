﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormRH
{
    public partial class FormInsPiloto : Form
    {
        Funcionario logado = new Funcionario();
        public FormInsPiloto(Funcionario func)
        {
            logado = func;
            InitializeComponent();
            label3.Text = "Bem vindo: " + logado.NomeFunc.ToString();
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        private void buttonConfirmar_Click(object sender, EventArgs e)
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            localhostEmpresa.Piloto novoPiloto = new localhostEmpresa.Piloto();

            if (textBoxSenha.Text != textBoxSenha2.Text)
            {
                MessageBox.Show("As senhas não coincidem.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            novoPiloto.NomeFunc = textBoxNome.Text;
            novoPiloto.RgFunc = textBox1.Text;
            novoPiloto.CpfFunc = maskedTextBox1.Text;
            novoPiloto.LoginFunc = textBoxLogin.Text;
            novoPiloto.SenhaFunc = textBoxSenha.Text;
            novoPiloto.Salario = Decimal.Parse(textBoxSalario.Text);
            novoPiloto.CargoFunc = "Piloto";
            novoPiloto.Breve = textBoxBreve.Text;


            try
            {
                novoPiloto.HorasVoo = int.Parse(textBoxHorasVoo.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Campo Horas Voo devem conter apenas valores inteiros e positivos.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            

            novoPiloto.Disp = 1;
            try
            {

                srv.inserirPiloto(novoPiloto);
                textBoxNome.Clear();
                textBox1.Clear();
                maskedTextBox1.Clear();
                textBoxLogin.Clear();
                textBoxSenha.Clear();
                textBoxSalario.Clear();
                textBoxBreve.Clear();
                textBoxHorasVoo.Clear();
                MessageBox.Show("Piloto "+novoPiloto.NomeFunc+" inserido com êxito.", "CONFIRMAÇÃO DE INCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        private void ButtonCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
