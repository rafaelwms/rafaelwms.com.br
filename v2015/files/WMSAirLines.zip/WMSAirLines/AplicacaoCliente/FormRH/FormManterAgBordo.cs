﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormRH
{
    public partial class FormManterAgBordo : Form
    {
        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormManterAgBordo(Funcionario func)
        {
            logado = func;
            InitializeComponent();
            refreshListaFunc();
            label3.Text = "Bem vindo: " + logado.NomeFunc.ToString();
        }

        void refreshListaFunc()
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            List<AgenteBordo> lista = new List<AgenteBordo>();
            lista = srv.listarAgsBordo().ToList();
            foreach (AgenteBordo func in lista)
            {
                if ((func != null) && (func.CargoFunc == "Ag de Bordo"))
                {
                    String ativo = "Disponível";
                    if (func.Disp == 0)
                    {
                        ativo = "Demitido";
                    }
                    if (func.Disp == 2)
                    {
                        ativo = "Em Voo";
                    }

                    String enf = "Não";

                    if (func.Enfermeiro == 1) 
                    {

                        enf = "Sim";
                    }

                    String[] linha = { func.NomeFunc.ToString(), func.CpfFunc.ToString(), enf, ativo };
                    listViewFunc.Items.Add(func.CodAgBordo.ToString()).SubItems.AddRange(linha);
                }
            }

        }

        void alterarAgBordo() 
        {
            try
            {
                ServiceEmpresa srv = new ServiceEmpresa();
                AgenteBordo alterar = new AgenteBordo();
                ListViewItem select = new ListViewItem();
                select = listViewFunc.SelectedItems[0];
                int codFunc = int.Parse(select.Text);
                List<AgenteBordo> teste = new List<AgenteBordo>();
                teste = srv.listarAgsBordo().ToList();
                foreach (AgenteBordo tst in teste)
                {
                    if (codFunc == tst.CodAgBordo)
                    {
                        alterar = tst;
                    }
                }
                FormAltAgBordo alterFunc = new FormAltAgBordo(logado, alterar);
                this.Hide();
                alterFunc.ShowDialog();
                listViewFunc.Items.Clear();
                refreshListaFunc();
                this.Show();
                buttonDemitirFunc.Enabled = false;
                buttonAlterarFunc.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA");
            }
        }

        void demitirAgBordo() 
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            ListViewItem select = new ListViewItem();
            select = listViewFunc.SelectedItems[0];
            int codAgBordo = int.Parse(select.Text);

            localhostEmpresa.AgenteBordo demitido = new localhostEmpresa.AgenteBordo();
            demitido.CodAgBordo = codAgBordo;

            List<localhostEmpresa.AgenteBordo> lis = new List<localhostEmpresa.AgenteBordo>();
            lis = srv.listarAgsBordo().ToList();
            foreach (AgenteBordo tst in lis)
            {
                if (demitido.CodAgBordo == tst.CodAgBordo)
                {
                    demitido = tst;
                }
            }
            try
            {
                if (MessageBox.Show("Tem certeza que deseja demitir o Agente de Bordo " + select.SubItems[1].Text + "?", "Confirmação de Demissão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    srv.demitirAgBordo(demitido);
                    MessageBox.Show("Demissão efetuada com êxito.", "Confirmação de Demissão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    listViewFunc.Items.Clear();
                    refreshListaFunc();
                    buttonDemitirFunc.Enabled = false;
                    buttonAlterarFunc.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        
        }

        void procurarAgBordo() 
        {
            try
            {
                ServiceEmpresa srv = new ServiceEmpresa();
                List<AgenteBordo> lista = new List<AgenteBordo>();
                lista = srv.procurarAgsBordo(textBox1.Text).ToList();
                foreach (AgenteBordo func in lista)
                {
                    if ((func != null) && (func.CargoFunc == "Ag Bordo"))
                    {
                        String ativo = "Disponível";
                        if (func.Disp == 0)
                        {
                            ativo = "Demitido";
                        }
                        if (func.Ativo == 2)
                        {
                            ativo = "Em Voo";
                        }

                        String enf = "Não";

                        if (func.Enfermeiro == 1)
                        {

                            enf = "Sim";
                        }

                        String[] linha = { func.NomeFunc.ToString(), func.CpfFunc.ToString(), enf, ativo };
                        listViewFunc.Items.Add(func.CodAgBordo.ToString()).SubItems.AddRange(linha);
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA");
            }
        }

        private void buttonInserirFunc_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInsAgBordo insfunc = new FormInsAgBordo(logado);
            insfunc.ShowDialog();
            listViewFunc.Items.Clear();
            refreshListaFunc();

            this.Show();
        }

        private void buttonDemitirFunc_Click(object sender, EventArgs e)
        {
            if (listViewFunc.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um Agente na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            this.demitirAgBordo();
        }

        private void buttonAlterarFunc_Click(object sender, EventArgs e)
        {
            if (listViewFunc.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um Agente na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            this.alterarAgBordo();
        }

        private void listViewFunc_MouseClick(object sender, MouseEventArgs e)
        {
            buttonDemitirFunc.Enabled = true;
            buttonAlterarFunc.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.procurarAgBordo();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
