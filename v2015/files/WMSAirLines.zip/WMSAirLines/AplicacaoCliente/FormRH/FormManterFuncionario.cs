﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormRH
{
    public partial class FormManterFuncionario : Form
    {
        void refreshListaFunc()
        {
            ServiceEmpresa srv = new ServiceEmpresa();
            List<Funcionario> lista = new List<Funcionario>();
            lista = srv.listarFuncionarios().ToList();
            foreach (Funcionario func in lista)
            {
                if (func != null)
                {
                    String ativo = "Ativo";
                    if (func.Ativo == 0)
                    {
                        ativo = "Demitido";
                    }
                    String[] linha = { func.NomeFunc.ToString(), func.CpfFunc.ToString(), func.CargoFunc.ToString(), func.Salario.ToString(), ativo };
                    listViewFunc.Items.Add(func.CodFunc.ToString()).SubItems.AddRange(linha);
                }
            }
        }
        Funcionario logado = new Funcionario();
        public FormManterFuncionario(Funcionario func)
        {
            logado = func;
            InitializeComponent();
            refreshListaFunc();
            label3.Text = "Bem vindo " + logado.NomeFunc;
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        private void buttonInserirFunc_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInserirFuncionario insfunc = new FormInserirFuncionario();
            insfunc.ShowDialog();
            listViewFunc.Items.Clear();
            refreshListaFunc();
            this.Show();
        }

        private void buttonDemitirFunc_Click(object sender, EventArgs e)
        {
            if (listViewFunc.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um funcionário na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                ListViewItem select = new ListViewItem();
                select = listViewFunc.SelectedItems[0];
                int codFunc = int.Parse(select.Text);
                Funcionario demitido = new Funcionario();
                demitido.CodFunc = codFunc;
                ServiceEmpresa srv = new ServiceEmpresa();

                if (MessageBox.Show("Tem certeza que deseja demitir o Funcionário " + select.SubItems[1].Text + "?", "Confirmação de Demissão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    srv.demitirFuncionario(demitido);
                    MessageBox.Show("Demissão efetuada com êxito.", "Confirmação de Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    listViewFunc.Items.Clear();
                    refreshListaFunc();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void buttonAlterarFunc_Click(object sender, EventArgs e)
        {

            if (listViewFunc.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um funcionário na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                ServiceEmpresa srv = new ServiceEmpresa();
                Funcionario alterar = new Funcionario();
                ListViewItem select = new ListViewItem();
                select = listViewFunc.SelectedItems[0];
                int codFunc = int.Parse(select.Text);
                List<Funcionario> teste = new List<Funcionario>();
                teste = srv.listarFuncionarios().ToList();
                foreach (Funcionario tst in teste)
                {
                    if (codFunc == tst.CodFunc)
                    {
                        alterar = tst;
                    }
                }
                FormAlterarFuncionario alterFunc = new FormAlterarFuncionario(alterar);
                this.Hide();
                alterFunc.ShowDialog();
                listViewFunc.Items.Clear();
                refreshListaFunc();
                this.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                ServiceEmpresa srv = new ServiceEmpresa();
                srv.procurarFuncionarios(textBox1.Text);
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }
    }
}
