﻿namespace AplicacaoCliente.FormRH
{
    partial class FormManterPiloto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonDemitirFunc = new System.Windows.Forms.Button();
            this.buttonAlterarFunc = new System.Windows.Forms.Button();
            this.buttonRegistrarPiloto = new System.Windows.Forms.Button();
            this.listViewPilotos = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.buttonCancelar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.buttonDemitirFunc);
            this.groupBox1.Controls.Add(this.buttonAlterarFunc);
            this.groupBox1.Controls.Add(this.buttonRegistrarPiloto);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(447, 125);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ações";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(64, 76);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(272, 20);
            this.textBox1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Busca";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(342, 74);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Procurar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonDemitirFunc
            // 
            this.buttonDemitirFunc.Enabled = false;
            this.buttonDemitirFunc.Location = new System.Drawing.Point(342, 34);
            this.buttonDemitirFunc.Name = "buttonDemitirFunc";
            this.buttonDemitirFunc.Size = new System.Drawing.Size(75, 23);
            this.buttonDemitirFunc.TabIndex = 2;
            this.buttonDemitirFunc.Text = "Demitir";
            this.buttonDemitirFunc.UseVisualStyleBackColor = true;
            this.buttonDemitirFunc.Click += new System.EventHandler(this.buttonDemitirFunc_Click);
            // 
            // buttonAlterarFunc
            // 
            this.buttonAlterarFunc.Enabled = false;
            this.buttonAlterarFunc.Location = new System.Drawing.Point(185, 34);
            this.buttonAlterarFunc.Name = "buttonAlterarFunc";
            this.buttonAlterarFunc.Size = new System.Drawing.Size(75, 23);
            this.buttonAlterarFunc.TabIndex = 1;
            this.buttonAlterarFunc.Text = "Alterar";
            this.buttonAlterarFunc.UseVisualStyleBackColor = true;
            this.buttonAlterarFunc.Click += new System.EventHandler(this.buttonAlterarFunc_Click);
            // 
            // buttonRegistrarPiloto
            // 
            this.buttonRegistrarPiloto.Location = new System.Drawing.Point(24, 34);
            this.buttonRegistrarPiloto.Name = "buttonRegistrarPiloto";
            this.buttonRegistrarPiloto.Size = new System.Drawing.Size(75, 23);
            this.buttonRegistrarPiloto.TabIndex = 0;
            this.buttonRegistrarPiloto.Text = "Inserir";
            this.buttonRegistrarPiloto.UseVisualStyleBackColor = true;
            this.buttonRegistrarPiloto.Click += new System.EventHandler(this.buttonInserirFunc_Click);
            // 
            // listViewPilotos
            // 
            this.listViewPilotos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
            this.listViewPilotos.FullRowSelect = true;
            this.listViewPilotos.Location = new System.Drawing.Point(12, 171);
            this.listViewPilotos.Name = "listViewPilotos";
            this.listViewPilotos.Size = new System.Drawing.Size(448, 141);
            this.listViewPilotos.TabIndex = 1;
            this.listViewPilotos.UseCompatibleStateImageBehavior = false;
            this.listViewPilotos.View = System.Windows.Forms.View.Details;
            this.listViewPilotos.SelectedIndexChanged += new System.EventHandler(this.listViewPilotos_SelectedIndexChanged);
            this.listViewPilotos.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listViewFunc_MouseClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Cod";
            this.columnHeader1.Width = 33;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nome";
            this.columnHeader2.Width = 126;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "CPF";
            this.columnHeader3.Width = 73;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Brevê";
            this.columnHeader4.Width = 78;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Horas Voo";
            this.columnHeader5.Width = 70;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Status";
            this.columnHeader6.Width = 43;
            // 
            // buttonCancelar
            // 
            this.buttonCancelar.Location = new System.Drawing.Point(197, 318);
            this.buttonCancelar.Name = "buttonCancelar";
            this.buttonCancelar.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelar.TabIndex = 6;
            this.buttonCancelar.Text = "Voltar";
            this.buttonCancelar.UseVisualStyleBackColor = true;
            this.buttonCancelar.Click += new System.EventHandler(this.buttonCancelar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(374, 323);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "WMS Systems®";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 323);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            // 
            // FormManterPiloto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 347);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonCancelar);
            this.Controls.Add(this.listViewPilotos);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormManterPiloto";
            this.Text = "Gerenciar Piloto";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonRegistrarPiloto;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonDemitirFunc;
        private System.Windows.Forms.Button buttonAlterarFunc;
        private System.Windows.Forms.ListView listViewPilotos;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button buttonCancelar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}