﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace AplicacaoCliente
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            localhostEmpresa.Funcionario func = new localhostEmpresa.Funcionario();
            func.NomeFunc = "Rafael WMS";
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormInicial());
        }
    }
}
