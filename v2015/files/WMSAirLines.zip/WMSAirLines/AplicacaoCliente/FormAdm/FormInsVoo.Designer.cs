﻿namespace AplicacaoCliente.FormAdm
{
    partial class FormInsVoo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewPiloto = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listViewAgentes = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonPiloto = new System.Windows.Forms.Button();
            this.buttonCoPiloto = new System.Windows.Forms.Button();
            this.buttonAg1 = new System.Windows.Forms.Button();
            this.buttonAg2 = new System.Windows.Forms.Button();
            this.buttonAg3 = new System.Windows.Forms.Button();
            this.buttonAg4 = new System.Windows.Forms.Button();
            this.comboBoxAeronaves = new System.Windows.Forms.ComboBox();
            this.comboBoxRotas = new System.Windows.Forms.ComboBox();
            this.textBoxMin = new System.Windows.Forms.TextBox();
            this.textBoxMilhas = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonInserir = new System.Windows.Forms.Button();
            this.maskedTextBoxHora = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxData = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.labelUser = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listViewPiloto
            // 
            this.listViewPiloto.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listViewPiloto.FullRowSelect = true;
            this.listViewPiloto.Location = new System.Drawing.Point(27, 118);
            this.listViewPiloto.Name = "listViewPiloto";
            this.listViewPiloto.Size = new System.Drawing.Size(234, 110);
            this.listViewPiloto.TabIndex = 0;
            this.listViewPiloto.UseCompatibleStateImageBehavior = false;
            this.listViewPiloto.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Cod";
            this.columnHeader1.Width = 35;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nome";
            this.columnHeader2.Width = 167;
            // 
            // listViewAgentes
            // 
            this.listViewAgentes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.listViewAgentes.FullRowSelect = true;
            this.listViewAgentes.Location = new System.Drawing.Point(27, 249);
            this.listViewAgentes.Name = "listViewAgentes";
            this.listViewAgentes.Size = new System.Drawing.Size(234, 110);
            this.listViewAgentes.TabIndex = 1;
            this.listViewAgentes.UseCompatibleStateImageBehavior = false;
            this.listViewAgentes.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Cod";
            this.columnHeader3.Width = 36;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Nome";
            this.columnHeader4.Width = 170;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Pilotos";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 231);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Agentes de Bordo";
            // 
            // textBoxNum
            // 
            this.textBoxNum.Location = new System.Drawing.Point(81, 28);
            this.textBoxNum.Name = "textBoxNum";
            this.textBoxNum.Size = new System.Drawing.Size(88, 20);
            this.textBoxNum.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Num Voo";
            // 
            // buttonPiloto
            // 
            this.buttonPiloto.Location = new System.Drawing.Point(267, 178);
            this.buttonPiloto.Name = "buttonPiloto";
            this.buttonPiloto.Size = new System.Drawing.Size(100, 23);
            this.buttonPiloto.TabIndex = 6;
            this.buttonPiloto.Text = "Definir Piloto";
            this.buttonPiloto.UseVisualStyleBackColor = true;
            this.buttonPiloto.Click += new System.EventHandler(this.buttonPiloto_Click);
            // 
            // buttonCoPiloto
            // 
            this.buttonCoPiloto.Enabled = false;
            this.buttonCoPiloto.Location = new System.Drawing.Point(267, 205);
            this.buttonCoPiloto.Name = "buttonCoPiloto";
            this.buttonCoPiloto.Size = new System.Drawing.Size(100, 23);
            this.buttonCoPiloto.TabIndex = 7;
            this.buttonCoPiloto.Text = "Definir Copiloto";
            this.buttonCoPiloto.UseVisualStyleBackColor = true;
            this.buttonCoPiloto.Click += new System.EventHandler(this.buttonCoPiloto_Click);
            // 
            // buttonAg1
            // 
            this.buttonAg1.Enabled = false;
            this.buttonAg1.Location = new System.Drawing.Point(267, 249);
            this.buttonAg1.Name = "buttonAg1";
            this.buttonAg1.Size = new System.Drawing.Size(100, 23);
            this.buttonAg1.TabIndex = 8;
            this.buttonAg1.Text = "Definir Agente1";
            this.buttonAg1.UseVisualStyleBackColor = true;
            this.buttonAg1.Click += new System.EventHandler(this.buttonAg1_Click);
            // 
            // buttonAg2
            // 
            this.buttonAg2.Enabled = false;
            this.buttonAg2.Location = new System.Drawing.Point(267, 278);
            this.buttonAg2.Name = "buttonAg2";
            this.buttonAg2.Size = new System.Drawing.Size(100, 23);
            this.buttonAg2.TabIndex = 9;
            this.buttonAg2.Text = "Definir Agente2";
            this.buttonAg2.UseVisualStyleBackColor = true;
            this.buttonAg2.Click += new System.EventHandler(this.buttonAg2_Click);
            // 
            // buttonAg3
            // 
            this.buttonAg3.Enabled = false;
            this.buttonAg3.Location = new System.Drawing.Point(267, 307);
            this.buttonAg3.Name = "buttonAg3";
            this.buttonAg3.Size = new System.Drawing.Size(100, 23);
            this.buttonAg3.TabIndex = 10;
            this.buttonAg3.Text = "Definir Agente3";
            this.buttonAg3.UseVisualStyleBackColor = true;
            this.buttonAg3.Click += new System.EventHandler(this.buttonAg3_Click);
            // 
            // buttonAg4
            // 
            this.buttonAg4.Enabled = false;
            this.buttonAg4.Location = new System.Drawing.Point(267, 336);
            this.buttonAg4.Name = "buttonAg4";
            this.buttonAg4.Size = new System.Drawing.Size(100, 23);
            this.buttonAg4.TabIndex = 11;
            this.buttonAg4.Text = "Definir Agente4";
            this.buttonAg4.UseVisualStyleBackColor = true;
            this.buttonAg4.Click += new System.EventHandler(this.buttonAg4_Click);
            // 
            // comboBoxAeronaves
            // 
            this.comboBoxAeronaves.FormattingEnabled = true;
            this.comboBoxAeronaves.Location = new System.Drawing.Point(27, 68);
            this.comboBoxAeronaves.Name = "comboBoxAeronaves";
            this.comboBoxAeronaves.Size = new System.Drawing.Size(142, 21);
            this.comboBoxAeronaves.TabIndex = 12;
            this.comboBoxAeronaves.Text = "Aeronave selecione..";
            this.comboBoxAeronaves.SelectedIndexChanged += new System.EventHandler(this.comboBoxAeronaves_SelectedIndexChanged);
            // 
            // comboBoxRotas
            // 
            this.comboBoxRotas.FormattingEnabled = true;
            this.comboBoxRotas.Location = new System.Drawing.Point(225, 68);
            this.comboBoxRotas.Name = "comboBoxRotas";
            this.comboBoxRotas.Size = new System.Drawing.Size(142, 21);
            this.comboBoxRotas.TabIndex = 13;
            this.comboBoxRotas.Text = "Rota Selecione...";
            this.comboBoxRotas.SelectedIndexChanged += new System.EventHandler(this.comboBoxRotas_SelectedIndexChanged);
            // 
            // textBoxMin
            // 
            this.textBoxMin.Enabled = false;
            this.textBoxMin.Location = new System.Drawing.Point(312, 28);
            this.textBoxMin.Name = "textBoxMin";
            this.textBoxMin.Size = new System.Drawing.Size(55, 20);
            this.textBoxMin.TabIndex = 14;
            // 
            // textBoxMilhas
            // 
            this.textBoxMilhas.Enabled = false;
            this.textBoxMilhas.Location = new System.Drawing.Point(225, 28);
            this.textBoxMilhas.Name = "textBoxMilhas";
            this.textBoxMilhas.Size = new System.Drawing.Size(49, 20);
            this.textBoxMilhas.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(182, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Milhas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(277, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Mins";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(27, 386);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonInserir
            // 
            this.buttonInserir.Enabled = false;
            this.buttonInserir.Location = new System.Drawing.Point(292, 386);
            this.buttonInserir.Name = "buttonInserir";
            this.buttonInserir.Size = new System.Drawing.Size(75, 23);
            this.buttonInserir.TabIndex = 19;
            this.buttonInserir.Text = "Confirmar";
            this.buttonInserir.UseVisualStyleBackColor = true;
            this.buttonInserir.Click += new System.EventHandler(this.buttonInserir_Click);
            // 
            // maskedTextBoxHora
            // 
            this.maskedTextBoxHora.Location = new System.Drawing.Point(303, 150);
            this.maskedTextBoxHora.Mask = "00:00";
            this.maskedTextBoxHora.Name = "maskedTextBoxHora";
            this.maskedTextBoxHora.Size = new System.Drawing.Size(64, 20);
            this.maskedTextBoxHora.TabIndex = 22;
            this.maskedTextBoxHora.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBoxData
            // 
            this.maskedTextBoxData.Location = new System.Drawing.Point(303, 122);
            this.maskedTextBoxData.Mask = "00/00/0000";
            this.maskedTextBoxData.Name = "maskedTextBoxData";
            this.maskedTextBoxData.Size = new System.Drawing.Size(64, 20);
            this.maskedTextBoxData.TabIndex = 23;
            this.maskedTextBoxData.ValidatingType = typeof(System.DateTime);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(267, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Data";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(267, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Hora";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxNum);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.listViewPiloto);
            this.groupBox1.Controls.Add(this.buttonInserir);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.listViewAgentes);
            this.groupBox1.Controls.Add(this.maskedTextBoxData);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.maskedTextBoxHora);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.buttonPiloto);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.buttonCoPiloto);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.buttonAg1);
            this.groupBox1.Controls.Add(this.textBoxMilhas);
            this.groupBox1.Controls.Add(this.buttonAg2);
            this.groupBox1.Controls.Add(this.textBoxMin);
            this.groupBox1.Controls.Add(this.buttonAg3);
            this.groupBox1.Controls.Add(this.comboBoxRotas);
            this.groupBox1.Controls.Add(this.buttonAg4);
            this.groupBox1.Controls.Add(this.comboBoxAeronaves);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(394, 415);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dados do Voo";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(167, 433);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 27;
            this.button2.Text = "Cancelar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // labelUser
            // 
            this.labelUser.AutoSize = true;
            this.labelUser.Location = new System.Drawing.Point(12, 467);
            this.labelUser.Name = "labelUser";
            this.labelUser.Size = new System.Drawing.Size(35, 13);
            this.labelUser.TabIndex = 28;
            this.labelUser.Text = "label6";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(322, 467);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 29;
            this.label6.Text = "WMS Systems®";
            // 
            // FormInsVoo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 489);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.labelUser);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormInsVoo";
            this.Text = "Inserir VOO";
            this.Load += new System.EventHandler(this.FormManterVoo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewPiloto;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListView listViewAgentes;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxNum;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonPiloto;
        private System.Windows.Forms.Button buttonCoPiloto;
        private System.Windows.Forms.Button buttonAg1;
        private System.Windows.Forms.Button buttonAg2;
        private System.Windows.Forms.Button buttonAg3;
        private System.Windows.Forms.Button buttonAg4;
        private System.Windows.Forms.ComboBox comboBoxAeronaves;
        private System.Windows.Forms.ComboBox comboBoxRotas;
        private System.Windows.Forms.TextBox textBoxMin;
        private System.Windows.Forms.TextBox textBoxMilhas;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonInserir;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxHora;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxData;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label labelUser;
        private System.Windows.Forms.Label label6;

    }
}