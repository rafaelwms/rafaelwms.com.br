﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormManterAeronave : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormManterAeronave(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            refreshLista();
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        void refreshLista() 
        {
            listViewNaves.Items.Clear();
            ServiceEmpresa srv = new ServiceEmpresa();
            List<localhostEmpresa.Aeronave> lista = new List<localhostEmpresa.Aeronave>();
            lista = srv.listarAeronaves().ToList();
            
            foreach (Aeronave nave in lista) 
            {

                String patio = "";
                if (nave.Patio == 0) 
                {
                    patio = "Inativo";
                }
                if (nave.Patio == 1)
                {
                    patio = "Disponível";
                }
                if (nave.Patio == 2)
                {
                    patio = "Em Voo";
                }
                if (nave.Patio == 3)
                {
                    patio = "Manutenção";
                }

                String[] linha = { nave.ApelidoAeronave.ToString(), nave.IdAeronave.ToString(), nave.ModeloAeronave.ToString(), nave.QtdPoltronas.ToString(), patio, nave.Milhas.ToString() };
                listViewNaves.Items.Add(nave.CodAeronave.ToString()).SubItems.AddRange(linha);      
            }
        }

        void excluirAeronave() 
        {
            if (MessageBox.Show("Tem certeza que deseja excluir a Aeronave " + listViewNaves.SelectedItems[0].SubItems[1].Text + "?", "Confirmação de Demissão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    ServiceEmpresa srv = new ServiceEmpresa();
                    srv.excluirAeronave(pegarAeronave());
                    MessageBox.Show("Aeronave excluída com êxito.", "CONFIRMAÇÃO DE EXCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refreshLista();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        localhostEmpresa.Aeronave pegarAeronave() 
        {
            localhostEmpresa.Aeronave selecionada = new localhostEmpresa.Aeronave();            
            selecionada.CodAeronave = int.Parse(listViewNaves.SelectedItems[0].Text);
            ServiceEmpresa srv = new ServiceEmpresa();
            List<localhostEmpresa.Aeronave> lista = new List<localhostEmpresa.Aeronave>();
            lista = srv.listarAeronaves().ToList();
            foreach (Aeronave nave in lista) 
            {

                if (selecionada.CodAeronave == nave.CodAeronave) 
                {
                    selecionada = nave;
                }

            }
            return selecionada;
        
        }

        private void FormManterAeronave_Load(object sender, EventArgs e)
        {

            labelUser.Text = "Bem vindo: "+logado.NomeFunc;
        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInsAeronave form = new FormInsAeronave(logado);
            form.ShowDialog();
            refreshLista();
            this.Show();
        
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {
            if (listViewNaves.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione uma Aeronave na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            excluirAeronave();
            buttonAlterar.Enabled = false;
            buttonExcluir.Enabled = false;
        }

        private void listViewNaves_MouseClick(object sender, MouseEventArgs e)
        {
            buttonAlterar.Enabled = true;
            buttonExcluir.Enabled = true;
        }

        private void buttonAlterar_Click(object sender, EventArgs e)

        {

            if (listViewNaves.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione uma Aeronave na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            FormAltAeronave form = new FormAltAeronave(logado, pegarAeronave());
            this.Hide();
            form.ShowDialog();
            refreshLista();
            this.Show();
            buttonAlterar.Enabled = false;
            buttonExcluir.Enabled = false;
        }
    }
}
