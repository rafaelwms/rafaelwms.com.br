﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormManterTrecho : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        localhostVoo.Aeroporto origem = new localhostVoo.Aeroporto();
        localhostVoo.Aeroporto destino = new localhostVoo.Aeroporto();
        localhostVoo.Trecho selecionado = new localhostVoo.Trecho();

        public FormManterTrecho(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            preencherListaAeroporto();
            preencherListaTrecho();
            label5.Text = "Bem vindo: " + logado.NomeFunc;

        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        void preencherListaAeroporto()
        {
            listViewPorto.Items.Clear();
            List<localhostVoo.Aeroporto> lista = new List<localhostVoo.Aeroporto>();
            localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
            lista = srv.listarAeroportos().ToList();

            foreach (Aeroporto porto in lista)
            {
                String[] linha = { porto.NomeAeroporto, porto.CidadeAeroporto, porto.UfAeroporto, porto.SiglaAeroporto };
                listViewPorto.Items.Add(porto.CodAeroporto.ToString()).SubItems.AddRange(linha);
            }

        }

        void preencherListaTrecho()
        {
            listViewTrechos.Items.Clear();
            List<localhostVoo.Trecho> lista = new List<localhostVoo.Trecho>();
            localhostVoo.ServiceVoo srv = new ServiceVoo();
            lista = srv.listarTrechos().ToList();
            foreach (Trecho item in lista)
            {
                String[] linha = { item.NomeTrecho, item.Origem.CidadeAeroporto, item.Destino.CidadeAeroporto, item.MinTrecho.ToString(), item.Milhas.ToString() };
                listViewTrechos.Items.Add(item.CodTrecho.ToString()).SubItems.AddRange(linha);

            }



        }

        void definirOrigem()
        {
            try
            {
                origem = new Aeroporto();
                origem.CodAeroporto = int.Parse(listViewPorto.SelectedItems[0].Text);
                List<localhostVoo.Aeroporto> lista = new List<localhostVoo.Aeroporto>();
                localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                lista = srv.listarAeroportos().ToList();
                foreach (Aeroporto porto in lista)
                {
                    if (origem.CodAeroporto == porto.CodAeroporto)
                    {
                        origem = porto;
                    }
                }
                textBoxNome.Text = origem.SiglaAeroporto + "-";
                remover();
                buttonDestino.Enabled = true;
                buttonOrigem.Enabled = false;
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        void definirDestino()
        {
            try
            {
                destino = new Aeroporto();
                destino.CodAeroporto = int.Parse(listViewPorto.SelectedItems[0].Text);
                List<localhostVoo.Aeroporto> lista = new List<localhostVoo.Aeroporto>();
                localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                lista = srv.listarAeroportos().ToList();
                foreach (Aeroporto porto in lista)
                {
                    if (destino.CodAeroporto == porto.CodAeroporto)
                    {
                        destino = porto;
                    }
                }
                textBoxNome.Text += destino.SiglaAeroporto;
                remover();
                buttonInserir.Enabled = true;
                buttonOrigem.Enabled = false;
                buttonDestino.Enabled = false;
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        void remover()
        {
            listViewPorto.Items.Remove(listViewPorto.SelectedItems[0]);
        }

        void reset()
        {
            textBoxMilhas.Clear();
            textBoxMin.Clear();
            textBoxNome.Clear();
            preencherListaAeroporto();
            preencherListaTrecho();
            buttonOrigem.Enabled = false;
            buttonDestino.Enabled = false;
            buttonInserir.Enabled = false;
            buttonAlterar.Enabled = false;
            buttonExcluir.Enabled = false;
        }

        void validarInts()
        {
            if ((textBoxMilhas.Text == null) || (textBoxMilhas.Text.Trim().Equals("")))
            {
                MessageBox.Show("Preencha o campo Milhas com números inteiros positivos.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                int tst = int.Parse(textBoxMilhas.Text);
            }
            catch (Exception) 
            {
                MessageBox.Show("Preencha o campo Milhas com números inteiros positivos.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if ((textBoxMin.Text == null) || (textBoxMin.Text.Trim().Equals("")))
            {
            
                MessageBox.Show("Preencha o campo Minutos com números inteiros positivos.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                int tst = int.Parse(textBoxMin.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Preencha o campo Minutos com números inteiros positivos.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }   

        }

        private void FormManterTrecho_Load(object sender, EventArgs e)
        {

        }

        void pegarDadosTrecho()
        {
            selecionado = new Trecho();
            selecionado.CodTrecho = int.Parse(listViewTrechos.SelectedItems[0].Text);
            selecionado.NomeTrecho = listViewTrechos.SelectedItems[0].SubItems[1].Text;
            selecionado.Milhas = int.Parse(listViewTrechos.SelectedItems[0].SubItems[5].Text);
            selecionado.MinTrecho = int.Parse(listViewTrechos.SelectedItems[0].SubItems[4].Text);
            textBoxNome.Text = listViewTrechos.SelectedItems[0].SubItems[1].Text;
            textBoxMilhas.Text = listViewTrechos.SelectedItems[0].SubItems[5].Text;
            textBoxMin.Text = listViewTrechos.SelectedItems[0].SubItems[4].Text;
        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonOrigem_Click(object sender, EventArgs e)
        {
            definirOrigem();
        }

        private void buttonDestino_Click(object sender, EventArgs e)
        {
            definirDestino();
        }

        private void listViewPorto_MouseClick(object sender, MouseEventArgs e)
        {
            buttonOrigem.Enabled = true;
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            try
            {
                
                validarInts();
                localhostVoo.Trecho novo = new localhostVoo.Trecho();
                localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                novo.NomeTrecho = textBoxNome.Text;
                novo.Milhas = int.Parse(textBoxMilhas.Text);
                novo.MinTrecho = int.Parse(textBoxMin.Text);
                novo.Origem = origem;
                novo.Destino = destino;
                srv.inserirTrecho(novo);
                MessageBox.Show("Trecho "+novo.NomeTrecho+" inserido com êxito", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                reset();
            }
            catch (Exception ex)
            {
                
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void listViewTrechos_MouseClick(object sender, MouseEventArgs e)
        {
            buttonAlterar.Enabled = true;
            buttonExcluir.Enabled = true;
            pegarDadosTrecho();
        }

        private void buttonAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                validarInts();
                localhostVoo.Trecho novo = new localhostVoo.Trecho();
                localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                novo.CodTrecho = selecionado.CodTrecho;
                novo.NomeTrecho = textBoxNome.Text;
                novo.Milhas = int.Parse(textBoxMilhas.Text);
                novo.MinTrecho = int.Parse(textBoxMin.Text);
                novo.Origem = origem;
                novo.Destino = destino;
                srv.alterarTrecho(novo);
                MessageBox.Show("Trecho " + novo.NomeTrecho + " Alterado com êxito", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                reset();
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja excluir o Trecho " + listViewTrechos.SelectedItems[0].SubItems[1].Text + "?", "Confirmação de Demissão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    localhostVoo.Trecho novo = new localhostVoo.Trecho();
                    localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                    novo.CodTrecho = selecionado.CodTrecho;
                    srv.excluirTrecho(novo);
                    MessageBox.Show("Trecho excluído com êxito.", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    reset();
                }
                catch (Exception ex)
                {
                    
                    MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }

        }
    }
}
