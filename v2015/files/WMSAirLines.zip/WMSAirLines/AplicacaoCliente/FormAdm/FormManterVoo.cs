﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormManterVoo : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        localhostVoo.ServiceVoo srvoo = new localhostVoo.ServiceVoo();

        public FormManterVoo(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            labelUser.Text = "Bem vindo: " + logado.NomeFunc;
            preencherLista();

        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        private void preencherLista()
        {
            listViewVoos.Items.Clear();
            foreach (Voo voo in srvoo.listarVoos().ToList())
            {
                String status = "No patio";
                if (voo.NaveVoo.Patio == 2)
                {
                    status = "Em Voo";
                }
                String[] linha = { voo.NumVoo.ToString(), voo.DataVoo, voo.HoraVoo, voo.RotaVoo.NomeRota, voo.NaveVoo.ApelidoAeronave, status };
                listViewVoos.Items.Add(voo.CodVoo.ToString()).SubItems.AddRange(linha);
            }
        }

        private void buttonAlterar_Click(object sender, EventArgs e)
        {

            if (listViewVoos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um voo na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            Voo alter = new Voo();
            alter.CodVoo = int.Parse(listViewVoos.SelectedItems[0].Text);

            foreach (Voo voo in srvoo.listarVoos().ToList())
            {
                if (alter.CodVoo == voo.CodVoo)
                {
                    alter = voo;
                }
            }
            FormAltVoo form = new FormAltVoo(logado, alter);
            this.Hide();
            form.ShowDialog();
            this.Show();
            preencherLista();

        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            FormInsVoo form = new FormInsVoo(logado);
            this.Hide();
            form.ShowDialog();
            this.Dispose();
            preencherLista();
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {

            if (listViewVoos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um voo na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            try
            {
                localhostVoo.Voo deletado = new localhostVoo.Voo();
                deletado.CodVoo = int.Parse(listViewVoos.SelectedItems[0].Text);
                deletado.NumVoo = int.Parse(listViewVoos.SelectedItems[0].SubItems[1].Text);
                if (MessageBox.Show("Tem certeza que deseja excluir o Voo " + deletado.NumVoo.ToString() + "?", "CONFIRMAÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    srvoo.excluirVoo(deletado);
                    MessageBox.Show("Voo Excluído com êxito.", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    preencherLista();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        private void buttonDecolar_Click(object sender, EventArgs e)
        {
            if (listViewVoos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um voo na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Voo decolado = new Voo();
            decolado.CodVoo = int.Parse(listViewVoos.SelectedItems[0].Text);
            decolado.NumVoo = int.Parse(listViewVoos.SelectedItems[0].SubItems[1].Text);
            if (MessageBox.Show("Tem certeza que deseja Confirmar decolagem do Voo " + decolado.NumVoo.ToString() + "?", "CONFIRMAÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                foreach (Voo voo in srvoo.listarVoos().ToList()) 
                {
                    if (decolado.CodVoo == voo.CodVoo) 
                    {
                        decolado = voo;
                    } 
                }

                srvoo.confirmarDecolagem(decolado);
               
                MessageBox.Show("Voo Decolado com êxito.", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                preencherLista();
            }
            


        }

        private void buttonProcurar_Click(object sender, EventArgs e)
        {
            listViewVoos.Items.Clear();
            foreach (Voo voo in srvoo.procurarVoo(textBox1.Text).ToList())
            {
                String status = "No patio";
                if (voo.NaveVoo.Patio == 2)
                {
                    status = "Em Voo";
                }
                String[] linha = { voo.NumVoo.ToString(), voo.DataVoo, voo.HoraVoo, voo.RotaVoo.NomeRota, voo.NaveVoo.ApelidoAeronave, status };
                listViewVoos.Items.Add(voo.CodVoo.ToString()).SubItems.AddRange(linha);
            }
        }

        private void buttonAterrissar_Click(object sender, EventArgs e)
        {
            if (listViewVoos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um voo na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Voo aterrissado = new Voo();
            aterrissado.CodVoo = int.Parse(listViewVoos.SelectedItems[0].Text);
            aterrissado.NumVoo = int.Parse(listViewVoos.SelectedItems[0].SubItems[1].Text);
            if (MessageBox.Show("Tem certeza que deseja Confirmar decolagem do Voo " + aterrissado.NumVoo.ToString() + "?", "CONFIRMAÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                foreach (Voo voo in srvoo.listarVoos().ToList())
                {
                    if (aterrissado.CodVoo == voo.CodVoo)
                    {
                        aterrissado = voo;
                    }
                }

                srvoo.confirmarAterrissagem(aterrissado);

                MessageBox.Show("Voo aterrissado com êxito.", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                preencherLista();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (listViewVoos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um voo na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Voo decolado = new Voo();
            decolado.CodVoo = int.Parse(listViewVoos.SelectedItems[0].Text);
            decolado.NumVoo = int.Parse(listViewVoos.SelectedItems[0].SubItems[1].Text);
            if (MessageBox.Show("Tem certeza que deseja Confirmar decolagem do Voo " + decolado.NumVoo.ToString() + "?", "CONFIRMAÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                foreach (Voo voo in srvoo.listarVoos().ToList())
                {
                    if (decolado.CodVoo == voo.CodVoo)
                    {
                        decolado = voo;
                    }
                }

                srvoo.confirmarDecolagem(decolado);

                MessageBox.Show("Voo Decolado com êxito.", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                preencherLista();
            }

        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonDados_Click(object sender, EventArgs e)
        {
             if (listViewVoos.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um voo na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            Voo info = new Voo();
            info.CodVoo = int.Parse(listViewVoos.SelectedItems[0].Text);

                foreach (Voo voo in srvoo.listarVoos().ToList())
                {
                    if (info.CodVoo == voo.CodVoo)
                    {
                        info = voo;
                    }
                }
                FormInfoVoo form = new FormInfoVoo(info);
                form.ShowDialog();

        }



    }
}
