﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormManterRota : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        localhostVoo.ServiceVoo srvoo = new ServiceVoo();

        public FormManterRota(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            preencherLista();
            labelUser.Text = "Bem vindo: " + logado.NomeFunc;
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        private void procurarRotas()
        {
            listViewRotas.Items.Clear();
            foreach (localhostVoo.Rota rota in srvoo.procurarRota(textBoxBusca.Text))
            {
                String[] linha = { rota.NomeRota, rota.MilhasRota.ToString(), rota.MinRota.ToString() };
                listViewRotas.Items.Add(rota.CodRota.ToString()).SubItems.AddRange(linha);
            }
        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void preencherLista()
        {
            listViewRotas.Items.Clear();
            foreach (localhostVoo.Rota rota in srvoo.listarRotas())
            {
                String[] linha = { rota.NomeRota, rota.MilhasRota.ToString(), rota.MinRota.ToString() };
                listViewRotas.Items.Add(rota.CodRota.ToString()).SubItems.AddRange(linha);
            }

        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            FormInsRota form = new FormInsRota(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();
            preencherLista();
        }

        private void listViewRotas_MouseClick(object sender, MouseEventArgs e)
        {
            buttonAlterar.Enabled = true;
            buttonExcluir.Enabled = true;
        }

        private void buttonExcluir_Click(object sender, EventArgs e)
        {
            if (listViewRotas.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione uma rota na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                localhostVoo.Rota deletar = new localhostVoo.Rota();
                deletar.CodRota = int.Parse(listViewRotas.SelectedItems[0].Text);
                deletar.NomeRota = listViewRotas.SelectedItems[0].SubItems[1].Text;
                if (MessageBox.Show("Tem certeza que deseja excluir a rota " + deletar.NomeRota + "?", "CONFIRMAÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    srvoo.excluirRota(deletar);
                    MessageBox.Show("Rota excluída com êxito.");
                    preencherLista();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void FormManterRota_Load(object sender, EventArgs e)
        {

        }

        private void buttonAlterar_Click(object sender, EventArgs e)
        {
            if (listViewRotas.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione uma rota na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            localhostVoo.Rota alteracao = new localhostVoo.Rota();
            alteracao.CodRota = int.Parse(listViewRotas.SelectedItems[0].Text);
            alteracao.NomeRota = listViewRotas.SelectedItems[0].SubItems[1].Text;
            alteracao.MilhasRota = int.Parse(listViewRotas.SelectedItems[0].SubItems[2].Text);
            alteracao.MinRota = int.Parse(listViewRotas.SelectedItems[0].SubItems[3].Text);
            if (alteracao.CodRota < 1) 
            {
                MessageBox.Show("Selecione uma Rota.","ALERTA",MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                
            }
            List<Trecho> listaAlteracao = new List<Trecho>();
            listaAlteracao = srvoo.listarTrechosDaRota(alteracao).ToList();


            FormAltRota form = new FormAltRota(logado, alteracao, listaAlteracao);
            this.Hide();
            form.ShowDialog();
            this.Show();
            preencherLista();
        }

        private void buttonProcurar_Click(object sender, EventArgs e)
        {
            procurarRotas();
        }
    }
}
