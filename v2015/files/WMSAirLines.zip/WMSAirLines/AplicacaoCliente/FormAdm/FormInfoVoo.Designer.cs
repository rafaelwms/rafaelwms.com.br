﻿namespace AplicacaoCliente.FormAdm
{
    partial class FormInfoVoo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNumVoo = new System.Windows.Forms.Label();
            this.textBoxNumVoo = new System.Windows.Forms.TextBox();
            this.textBoxData = new System.Windows.Forms.TextBox();
            this.textBoxHora = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxRota = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxApelido = new System.Windows.Forms.TextBox();
            this.Aeronave = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxModelo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxAcomodacao = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxMilhas = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxMinutos = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBoxPiloto = new System.Windows.Forms.TextBox();
            this.textBoxCopiloto = new System.Windows.Forms.TextBox();
            this.textBoxAg1 = new System.Windows.Forms.TextBox();
            this.textBoxAg2 = new System.Windows.Forms.TextBox();
            this.textBoxAg3 = new System.Windows.Forms.TextBox();
            this.textBoxAg4 = new System.Windows.Forms.TextBox();
            this.Comandante = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelNumVoo
            // 
            this.labelNumVoo.AutoSize = true;
            this.labelNumVoo.Location = new System.Drawing.Point(6, 32);
            this.labelNumVoo.Name = "labelNumVoo";
            this.labelNumVoo.Size = new System.Drawing.Size(26, 13);
            this.labelNumVoo.TabIndex = 0;
            this.labelNumVoo.Text = "Voo";
            // 
            // textBoxNumVoo
            // 
            this.textBoxNumVoo.Enabled = false;
            this.textBoxNumVoo.Location = new System.Drawing.Point(38, 29);
            this.textBoxNumVoo.Name = "textBoxNumVoo";
            this.textBoxNumVoo.Size = new System.Drawing.Size(91, 20);
            this.textBoxNumVoo.TabIndex = 1;
            // 
            // textBoxData
            // 
            this.textBoxData.Enabled = false;
            this.textBoxData.Location = new System.Drawing.Point(197, 29);
            this.textBoxData.Name = "textBoxData";
            this.textBoxData.Size = new System.Drawing.Size(88, 20);
            this.textBoxData.TabIndex = 2;
            // 
            // textBoxHora
            // 
            this.textBoxHora.Enabled = false;
            this.textBoxHora.Location = new System.Drawing.Point(373, 29);
            this.textBoxHora.Name = "textBoxHora";
            this.textBoxHora.Size = new System.Drawing.Size(83, 20);
            this.textBoxHora.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxNumVoo);
            this.groupBox1.Controls.Add(this.labelNumVoo);
            this.groupBox1.Controls.Add(this.textBoxHora);
            this.groupBox1.Controls.Add(this.textBoxData);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(479, 76);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Voo";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(337, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Hora";
            // 
            // textBoxRota
            // 
            this.textBoxRota.Enabled = false;
            this.textBoxRota.Location = new System.Drawing.Point(52, 23);
            this.textBoxRota.Name = "textBoxRota";
            this.textBoxRota.Size = new System.Drawing.Size(104, 20);
            this.textBoxRota.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Rota";
            // 
            // textBoxApelido
            // 
            this.textBoxApelido.Enabled = false;
            this.textBoxApelido.Location = new System.Drawing.Point(65, 28);
            this.textBoxApelido.Name = "textBoxApelido";
            this.textBoxApelido.Size = new System.Drawing.Size(91, 20);
            this.textBoxApelido.TabIndex = 8;
            // 
            // Aeronave
            // 
            this.Aeronave.AutoSize = true;
            this.Aeronave.Location = new System.Drawing.Point(16, 31);
            this.Aeronave.Name = "Aeronave";
            this.Aeronave.Size = new System.Drawing.Size(42, 13);
            this.Aeronave.TabIndex = 9;
            this.Aeronave.Text = "Apelido";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBoxAcomodacao);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBoxModelo);
            this.groupBox2.Controls.Add(this.Aeronave);
            this.groupBox2.Controls.Add(this.textBoxApelido);
            this.groupBox2.Location = new System.Drawing.Point(12, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(479, 70);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Aeronave do Voo";
            // 
            // textBoxModelo
            // 
            this.textBoxModelo.Enabled = false;
            this.textBoxModelo.Location = new System.Drawing.Point(210, 28);
            this.textBoxModelo.Name = "textBoxModelo";
            this.textBoxModelo.Size = new System.Drawing.Size(75, 20);
            this.textBoxModelo.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(162, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Modelo";
            // 
            // textBoxAcomodacao
            // 
            this.textBoxAcomodacao.Enabled = false;
            this.textBoxAcomodacao.Location = new System.Drawing.Point(396, 28);
            this.textBoxAcomodacao.Name = "textBoxAcomodacao";
            this.textBoxAcomodacao.Size = new System.Drawing.Size(60, 20);
            this.textBoxAcomodacao.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(320, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Acomodação";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listView1);
            this.groupBox3.Controls.Add(this.textBoxMinutos);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBoxMilhas);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.textBoxRota);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(12, 170);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(479, 185);
            this.groupBox3.TabIndex = 11;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Percurso";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(167, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Milhas";
            // 
            // textBoxMilhas
            // 
            this.textBoxMilhas.Enabled = false;
            this.textBoxMilhas.Location = new System.Drawing.Point(210, 23);
            this.textBoxMilhas.Name = "textBoxMilhas";
            this.textBoxMilhas.Size = new System.Drawing.Size(75, 20);
            this.textBoxMilhas.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(320, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Minutos";
            // 
            // textBoxMinutos
            // 
            this.textBoxMinutos.Enabled = false;
            this.textBoxMinutos.Location = new System.Drawing.Point(373, 23);
            this.textBoxMinutos.Name = "textBoxMinutos";
            this.textBoxMinutos.Size = new System.Drawing.Size(83, 20);
            this.textBoxMinutos.TabIndex = 11;
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12});
            this.listView1.Location = new System.Drawing.Point(19, 60);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(437, 115);
            this.listView1.TabIndex = 12;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Trecho";
            this.columnHeader8.Width = 84;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Origem";
            this.columnHeader9.Width = 106;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Destino";
            this.columnHeader10.Width = 102;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Milhas";
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Minutos";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.Comandante);
            this.groupBox4.Controls.Add(this.textBoxAg4);
            this.groupBox4.Controls.Add(this.textBoxAg3);
            this.groupBox4.Controls.Add(this.textBoxAg2);
            this.groupBox4.Controls.Add(this.textBoxAg1);
            this.groupBox4.Controls.Add(this.textBoxCopiloto);
            this.groupBox4.Controls.Add(this.textBoxPiloto);
            this.groupBox4.Location = new System.Drawing.Point(12, 370);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(479, 139);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Tripulação";
            // 
            // textBoxPiloto
            // 
            this.textBoxPiloto.Enabled = false;
            this.textBoxPiloto.Location = new System.Drawing.Point(56, 33);
            this.textBoxPiloto.Name = "textBoxPiloto";
            this.textBoxPiloto.Size = new System.Drawing.Size(164, 20);
            this.textBoxPiloto.TabIndex = 0;
            // 
            // textBoxCopiloto
            // 
            this.textBoxCopiloto.Enabled = false;
            this.textBoxCopiloto.Location = new System.Drawing.Point(290, 33);
            this.textBoxCopiloto.Name = "textBoxCopiloto";
            this.textBoxCopiloto.Size = new System.Drawing.Size(166, 20);
            this.textBoxCopiloto.TabIndex = 1;
            // 
            // textBoxAg1
            // 
            this.textBoxAg1.Enabled = false;
            this.textBoxAg1.Location = new System.Drawing.Point(56, 71);
            this.textBoxAg1.Name = "textBoxAg1";
            this.textBoxAg1.Size = new System.Drawing.Size(164, 20);
            this.textBoxAg1.TabIndex = 2;
            // 
            // textBoxAg2
            // 
            this.textBoxAg2.Enabled = false;
            this.textBoxAg2.Location = new System.Drawing.Point(290, 71);
            this.textBoxAg2.Name = "textBoxAg2";
            this.textBoxAg2.Size = new System.Drawing.Size(166, 20);
            this.textBoxAg2.TabIndex = 3;
            // 
            // textBoxAg3
            // 
            this.textBoxAg3.Enabled = false;
            this.textBoxAg3.Location = new System.Drawing.Point(56, 110);
            this.textBoxAg3.Name = "textBoxAg3";
            this.textBoxAg3.Size = new System.Drawing.Size(164, 20);
            this.textBoxAg3.TabIndex = 4;
            // 
            // textBoxAg4
            // 
            this.textBoxAg4.Enabled = false;
            this.textBoxAg4.Location = new System.Drawing.Point(290, 110);
            this.textBoxAg4.Name = "textBoxAg4";
            this.textBoxAg4.Size = new System.Drawing.Size(166, 20);
            this.textBoxAg4.TabIndex = 5;
            // 
            // Comandante
            // 
            this.Comandante.AutoSize = true;
            this.Comandante.Location = new System.Drawing.Point(17, 36);
            this.Comandante.Name = "Comandante";
            this.Comandante.Size = new System.Drawing.Size(33, 13);
            this.Comandante.TabIndex = 6;
            this.Comandante.Text = "Piloto";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(239, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Copiloto";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Agente";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(243, 74);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Agente";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 113);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Agente";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(244, 113);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Agente";
            // 
            // FormInfoVoo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 536);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormInfoVoo";
            this.Text = "FormInfoVoo";
            this.Load += new System.EventHandler(this.FormInfoVoo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelNumVoo;
        private System.Windows.Forms.TextBox textBoxNumVoo;
        private System.Windows.Forms.TextBox textBoxData;
        private System.Windows.Forms.TextBox textBoxHora;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxRota;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxApelido;
        private System.Windows.Forms.Label Aeronave;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxAcomodacao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxModelo;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox textBoxMinutos;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxMilhas;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Comandante;
        private System.Windows.Forms.TextBox textBoxAg4;
        private System.Windows.Forms.TextBox textBoxAg3;
        private System.Windows.Forms.TextBox textBoxAg2;
        private System.Windows.Forms.TextBox textBoxAg1;
        private System.Windows.Forms.TextBox textBoxCopiloto;
        private System.Windows.Forms.TextBox textBoxPiloto;
    }
}