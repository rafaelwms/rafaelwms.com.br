﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{


    public partial class FormAltVoo : Form
    {
       
        List<localhostEmpresa.Aeronave> navelist = new List<localhostEmpresa.Aeronave>();
        List<localhostEmpresa.Piloto> pilotos = new List<localhostEmpresa.Piloto>();
        List<localhostEmpresa.AgenteBordo> bordos = new List<localhostEmpresa.AgenteBordo>();
        List<localhostVoo.Rota> rotalist = new List<localhostVoo.Rota>();
        localhostVoo.Piloto piloto, copiloto = new localhostVoo.Piloto();
        localhostVoo.AgenteBordo ag1, ag2, ag3, ag4 = new localhostVoo.AgenteBordo();
        localhostVoo.Rota rota = new localhostVoo.Rota();
        localhostVoo.Aeronave nave = new localhostVoo.Aeronave();
        localhostVoo.ServiceVoo voosrv = new localhostVoo.ServiceVoo();
        localhostEmpresa.ServiceEmpresa empresa = new localhostEmpresa.ServiceEmpresa();
        int[] codAeronave;
        int[] codRota;
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        localhostVoo.Voo alter = new localhostVoo.Voo();
        public FormAltVoo(localhostEmpresa.Funcionario func, localhostVoo.Voo voo)
        {
            alter = voo;
            logado = func;
            InitializeComponent();
           
            bordos = empresa.listarAgsBordo().ToList();
            pilotos = empresa.listarPilotos().ToList();
            rotalist = voosrv.listarRotas().ToList();
            navelist = empresa.listarAeronaves().ToList();
            codAeronave = new int[navelist.Count];
            codRota = new int[rotalist.Count];
            labelUser.Text = "Bem vindo " + logado.NomeFunc;
            textBoxNum.Text = alter.NumVoo.ToString();
            textBoxMilhas.Text = alter.RotaVoo.MilhasRota.ToString();
            textBoxMin.Text = alter.RotaVoo.MinRota.ToString();
            maskedTextBoxData.Text = alter.DataVoo;
            maskedTextBoxHora.Text = alter.HoraVoo;
            buttonPiloto.Text = alter.PilotoVoo.NomeFunc;
            buttonCoPiloto.Text = alter.CoPilotoVoo.NomeFunc;
            buttonAg1.Text = alter.AgBordo1.NomeFunc;
            buttonAg2.Text = alter.AgBordo2.NomeFunc;
            buttonAg3.Text = alter.AgBordo3.NomeFunc;
            buttonAg4.Text = alter.AgBordo4.NomeFunc;
        }

        private void FormManterVoo_Load(object sender, EventArgs e)
        {
            preencherComboAeronaves();
            preencherComboRotas();
            preencherListaAgentes();
            preencherListaPiloto();

        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        void preencherComboAeronaves()
        {
            int baseado = 0;
            foreach (localhostEmpresa.Aeronave nave in navelist)
            {
                if (nave.Patio > 0)
                {
                    codAeronave[baseado] = nave.CodAeronave;
                    baseado++;
                    comboBoxAeronaves.Items.Add(nave.ApelidoAeronave);
                }
            }

        }

        void preencherComboRotas()
        {
            int baseado = 0;
            foreach (localhostVoo.Rota rota in rotalist)
            {
                codRota[baseado] = rota.CodRota;
                baseado++;
                comboBoxRotas.Items.Add(rota.NomeRota);
            }

        }

        void preencherListaPiloto()
        {
            listViewPiloto.Items.Clear();
            foreach (localhostEmpresa.Piloto piloto in pilotos)
            {

                if (piloto.Ativo > 0)
                {
                    listViewPiloto.Items.Add(piloto.CodPiloto.ToString()).SubItems.Add(piloto.NomeFunc);
                }
            }
        }

        void preencherListaAgentes()
        {
            listViewAgentes.Items.Clear();
            foreach (localhostEmpresa.AgenteBordo bordo in bordos)
            {
                if (bordo.Ativo > 0)
                {
                    listViewAgentes.Items.Add(bordo.CodAgBordo.ToString()).SubItems.Add(bordo.NomeFunc);
                }
            }
        }

        private void buttonPiloto_Click(object sender, EventArgs e)
        {
            if (listViewPiloto.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um piloto na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            piloto = new localhostVoo.Piloto();
            piloto.CodPiloto = int.Parse(listViewPiloto.SelectedItems[0].Text);
            piloto.NomeFunc = listViewPiloto.SelectedItems[0].SubItems[1].Text;
            listViewPiloto.Items.Remove(listViewPiloto.SelectedItems[0]);
            buttonCoPiloto.Enabled = true;
            buttonPiloto.Text = piloto.NomeFunc;
            buttonPiloto.Enabled = false;
        }

        private void buttonCoPiloto_Click(object sender, EventArgs e)
        {
            if (listViewPiloto.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um copiloto na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            copiloto = new localhostVoo.Piloto();
            copiloto.CodPiloto = int.Parse(listViewPiloto.SelectedItems[0].Text);
            copiloto.NomeFunc = listViewPiloto.SelectedItems[0].SubItems[1].Text;
            listViewPiloto.Items.Remove(listViewPiloto.SelectedItems[0]);
            buttonAg1.Enabled = true;
            buttonCoPiloto.Text = copiloto.NomeFunc;
            buttonCoPiloto.Enabled = false;

        }

        private void buttonAg1_Click(object sender, EventArgs e)
        {
            if (listViewAgentes.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um agente na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            ag1 = new localhostVoo.AgenteBordo();
            ag1.CodAgBordo = int.Parse(listViewAgentes.SelectedItems[0].Text);
            ag1.NomeFunc = listViewAgentes.SelectedItems[0].SubItems[1].Text;
            listViewAgentes.Items.Remove(listViewAgentes.SelectedItems[0]);
            buttonAg2.Enabled = true;
            buttonAg1.Text = ag1.NomeFunc;
            buttonAg1.Enabled = false;
        }

        private void buttonAg2_Click(object sender, EventArgs e)
        {
            if (listViewAgentes.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um agente na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            ag2 = new localhostVoo.AgenteBordo();
            ag2.CodAgBordo = int.Parse(listViewAgentes.SelectedItems[0].Text);
            ag2.NomeFunc = listViewAgentes.SelectedItems[0].SubItems[1].Text;
            listViewAgentes.Items.Remove(listViewAgentes.SelectedItems[0]);
            buttonAg3.Enabled = true;
            buttonAg2.Text = ag2.NomeFunc;
            buttonAg2.Enabled = false;
        }

        private void buttonAg3_Click(object sender, EventArgs e)
        {
            if (listViewAgentes.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um agente na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            ag3 = new localhostVoo.AgenteBordo();
            ag3.CodAgBordo = int.Parse(listViewAgentes.SelectedItems[0].Text);
            ag3.NomeFunc = listViewAgentes.SelectedItems[0].SubItems[1].Text;
            listViewAgentes.Items.Remove(listViewAgentes.SelectedItems[0]);
            buttonAg4.Enabled = true;
            buttonAg3.Text = ag3.NomeFunc;
            buttonAg3.Enabled = false;
        }

        private void buttonAg4_Click(object sender, EventArgs e)
        {
            if (listViewAgentes.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um agente na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            ag4 = new localhostVoo.AgenteBordo();
            ag4.CodAgBordo = int.Parse(listViewAgentes.SelectedItems[0].Text);
            ag4.NomeFunc = listViewAgentes.SelectedItems[0].SubItems[1].Text;
            listViewAgentes.Items.Remove(listViewAgentes.SelectedItems[0]);
            buttonInserir.Enabled = true;
            buttonAg4.Text = ag4.NomeFunc;
            buttonAg4.Enabled = false;
        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            if (maskedTextBoxData.Text == "  /  /")
            {
                MessageBox.Show("É necessário preencher o campo Data.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (maskedTextBoxHora.Text == "  :")
            {
                MessageBox.Show("É necessário preencher o campo Data.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }


            try
            {
                localhostVoo.Voo novo = new localhostVoo.Voo();
                novo.CodVoo = alter.CodVoo;
                novo.NumVoo = int.Parse(textBoxNum.Text);
                novo.RotaVoo = rota;
                novo.NaveVoo = nave;
                novo.AgBordo1 = ag1;
                novo.AgBordo2 = ag2;
                novo.AgBordo3 = ag3;
                novo.AgBordo4 = ag4;
                novo.PilotoVoo = piloto;
                novo.CoPilotoVoo = copiloto;
                novo.DataVoo = maskedTextBoxData.Text;
                novo.HoraVoo = maskedTextBoxHora.Text;
                voosrv.alterarVoo(novo);
                MessageBox.Show("Voo " + novo.NumVoo.ToString() + " alterado com êxito.", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Dispose();
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void comboBoxAeronaves_SelectedIndexChanged(object sender, EventArgs e)
        {
            nave = new localhostVoo.Aeronave();
            foreach (localhostEmpresa.Aeronave tst in navelist)
            {
                if (codAeronave[comboBoxAeronaves.SelectedIndex] == tst.CodAeronave)
                {
                    nave.ApelidoAeronave = tst.ApelidoAeronave;
                    nave.CodAeronave = tst.CodAeronave;
                }

            }


        }

        private void comboBoxRotas_SelectedIndexChanged(object sender, EventArgs e)
        {

            rota = new Rota();
            foreach (Rota tst in rotalist)
            {
                if (codRota[comboBoxRotas.SelectedIndex] == tst.CodRota)
                {
                    rota = tst;
                }

            }
            textBoxMilhas.Text = rota.MilhasRota.ToString();
            textBoxMin.Text = rota.MinRota.ToString();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

       
        private void button1_Click(object sender, EventArgs e)
        {
            ag1 = new localhostVoo.AgenteBordo();
            ag2 = new localhostVoo.AgenteBordo();
            ag3 = new localhostVoo.AgenteBordo();
            ag4 = new localhostVoo.AgenteBordo();
            piloto = new localhostVoo.Piloto();
            copiloto = new localhostVoo.Piloto();
            buttonPiloto.Text = "Definir Piloto";
            buttonCoPiloto.Text = "Definir Copiloto";
            buttonAg1.Text = "Definir Agente1";
            buttonAg2.Text = "Definir Agente2";
            buttonAg3.Text = "Definir Agente3";
            buttonAg4.Text = "Definir Agente4";
            buttonPiloto.Enabled = true;
            buttonCoPiloto.Enabled = false;
            buttonAg1.Enabled = false;
            buttonAg2.Enabled = false;
            buttonAg3.Enabled = false;
            buttonAg4.Enabled = false;
            buttonInserir.Enabled = false;
            preencherListaAgentes();
            preencherListaPiloto();
            comboBoxAeronaves.SelectedIndex = 0;
            comboBoxRotas.SelectedIndex = 0;
            textBoxMilhas.Clear();
            textBoxMin.Clear();
            textBoxNum.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {


        }




}
    }

