﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormManterAeroporto : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormManterAeroporto(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            refreshLista();
            labelUser.Text = "Bem vindo: " + logado.NomeFunc;
        }

        private void FormManterAeroporto_Load(object sender, EventArgs e)
        {

        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        localhostVoo.Aeroporto pegarAeroporto()
        {
            int codPorto = int.Parse(listViewPorto.SelectedItems[0].Text);
            localhostVoo.Aeroporto porto = new localhostVoo.Aeroporto();
            porto.CodAeroporto = codPorto;
            List<localhostVoo.Aeroporto> lista = new List<localhostVoo.Aeroporto>();
            localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
            lista = srv.listarAeroportos().ToList();

            foreach (Aeroporto por in lista)
            {

                if (porto.CodAeroporto == por.CodAeroporto)
                {
                    porto = por;
                }

            }
            return porto;
        }

        void preencherCampos() 
        {
            localhostVoo.Aeroporto porto = new localhostVoo.Aeroporto();
            porto = pegarAeroporto();
            textBoxNome.Text = porto.NomeAeroporto;
            textBoxCidade.Text = porto.CidadeAeroporto;
            textBoxUf.Text = porto.UfAeroporto;
            textBoxSigla.Text = porto.SiglaAeroporto;
        
        }

        void refreshLista()
        {
            listViewPorto.Items.Clear();
            List<localhostVoo.Aeroporto> lista = new List<localhostVoo.Aeroporto>();
            localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
            lista = srv.listarAeroportos().ToList();

            foreach (Aeroporto porto in lista)
            {
                String[] linha = { porto.NomeAeroporto, porto.CidadeAeroporto, porto.UfAeroporto, porto.SiglaAeroporto };
                listViewPorto.Items.Add(porto.CodAeroporto.ToString()).SubItems.AddRange(linha);
            }
        }

        void limparCampos()
        {
            textBoxNome.Clear();
            textBoxCidade.Clear();
            textBoxUf.Clear();
            textBoxSigla.Clear();
        }

        private void listViewPorto_MouseClick(object sender, MouseEventArgs e)
        {
            preencherCampos();
            buttonAlterar.Enabled = true;
            buttonExcluir.Enabled = true;
        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            try
            {
                localhostVoo.Aeroporto novo = new localhostVoo.Aeroporto();
                novo.NomeAeroporto = textBoxNome.Text;
                novo.CidadeAeroporto = textBoxCidade.Text;
                novo.UfAeroporto = textBoxUf.Text;
                novo.SiglaAeroporto = textBoxSigla.Text;
                localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                srv.inserirAeroporto(novo);
                MessageBox.Show("Aeroporto " + novo.NomeAeroporto + " inserido com êxito.", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                limparCampos();
                refreshLista();
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        private void buttonAlterar_Click(object sender, EventArgs e)
        {
            if (listViewPorto.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um Aeroporto na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                localhostVoo.Aeroporto alterar = new localhostVoo.Aeroporto();
                alterar = pegarAeroporto();
                alterar.NomeAeroporto = textBoxNome.Text;
                alterar.CidadeAeroporto = textBoxCidade.Text;
                alterar.UfAeroporto = textBoxUf.Text;
                alterar.SiglaAeroporto = textBoxSigla.Text;
                localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                srv.alterarAeroporto(alterar);
                MessageBox.Show("Aeroporto " + alterar.NomeAeroporto + " alterado com êxito.", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                refreshLista();
                limparCampos();
            }
            catch (Exception ex)
            {

                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void buttonExcluir_Click(object sender, EventArgs e)

        {
            if (listViewPorto.SelectedItems.Count < 1)
            {
                MessageBox.Show("Selecione um Aeroporto na lista.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            if (MessageBox.Show("Tem certeza que deseja excluir o Aeroporto " + listViewPorto.SelectedItems[0].SubItems[1].Text + "?", "Confirmação de Demissão", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
            {
                try
                {
                    localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
                    srv.excluirAeroporto(pegarAeroporto());
                    MessageBox.Show("Aeroporto excluído com êxito.", "CONFIRMAÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    refreshLista();
                    limparCampos();
                }
                catch (Exception ex)
                {
                    
                    MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }


    }
}
