﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormInfoVoo : Form
    {
        localhostVoo.Voo info = new localhostVoo.Voo();
        localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
        public FormInfoVoo(Voo voo)
        {
            info = voo;
            InitializeComponent();
        }

        private void FormInfoVoo_Load(object sender, EventArgs e)
        {
            this.Text = "Voo " + info.NumVoo.ToString();
            textBoxNumVoo.Text = info.NumVoo.ToString();
            textBoxData.Text = info.DataVoo;
            textBoxHora.Text = info.HoraVoo;
            textBoxRota.Text = info.RotaVoo.NomeRota;
            textBoxMilhas.Text = info.RotaVoo.MilhasRota.ToString();
            textBoxMinutos.Text = info.RotaVoo.MinRota.ToString();
            textBoxApelido.Text = info.NaveVoo.ApelidoAeronave;
            textBoxModelo.Text = info.NaveVoo.ModeloAeronave;
            textBoxAcomodacao.Text = info.NaveVoo.QtdPoltronas.ToString();
            textBoxPiloto.Text = info.PilotoVoo.NomeFunc;
            textBoxCopiloto.Text = info.CoPilotoVoo.NomeFunc;
            textBoxAg1.Text = info.AgBordo1.NomeFunc;
            textBoxAg2.Text = info.AgBordo2.NomeFunc;
            textBoxAg3.Text = info.AgBordo3.NomeFunc;
            textBoxAg4.Text = info.AgBordo4.NomeFunc;
            Rota temp = new Rota();
            temp = info.RotaVoo;
            foreach (localhostVoo.Trecho trecho in srv.listarTrechosDaRota(temp).ToList()) 
            {
                String[] linha = { trecho.Origem.CidadeAeroporto, trecho.Destino.CidadeAeroporto, trecho.Milhas.ToString(), trecho.MinTrecho.ToString() };
                listView1.Items.Add(trecho.NomeTrecho).SubItems.AddRange(linha);
            
            }



        }
    }
}
