﻿namespace AplicacaoCliente.FormAdm
{
    partial class FormAgAdm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.buttonManterAeronave = new System.Windows.Forms.Button();
            this.buttonManterAeroporto = new System.Windows.Forms.Button();
            this.buttonManterTrecho = new System.Windows.Forms.Button();
            this.buttonManterRota = new System.Windows.Forms.Button();
            this.buttonManterVoo = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("SketchFlow Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(234, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Agente Administrativo";
            // 
            // buttonManterAeronave
            // 
            this.buttonManterAeronave.Location = new System.Drawing.Point(23, 28);
            this.buttonManterAeronave.Name = "buttonManterAeronave";
            this.buttonManterAeronave.Size = new System.Drawing.Size(144, 23);
            this.buttonManterAeronave.TabIndex = 1;
            this.buttonManterAeronave.Text = "Aeronave";
            this.buttonManterAeronave.UseVisualStyleBackColor = true;
            this.buttonManterAeronave.Click += new System.EventHandler(this.buttonManterAeronave_Click);
            // 
            // buttonManterAeroporto
            // 
            this.buttonManterAeroporto.Location = new System.Drawing.Point(23, 76);
            this.buttonManterAeroporto.Name = "buttonManterAeroporto";
            this.buttonManterAeroporto.Size = new System.Drawing.Size(144, 23);
            this.buttonManterAeroporto.TabIndex = 2;
            this.buttonManterAeroporto.Text = "Aeroporto";
            this.buttonManterAeroporto.UseVisualStyleBackColor = true;
            this.buttonManterAeroporto.Click += new System.EventHandler(this.buttonManterAeroporto_Click);
            // 
            // buttonManterTrecho
            // 
            this.buttonManterTrecho.Location = new System.Drawing.Point(199, 28);
            this.buttonManterTrecho.Name = "buttonManterTrecho";
            this.buttonManterTrecho.Size = new System.Drawing.Size(144, 23);
            this.buttonManterTrecho.TabIndex = 3;
            this.buttonManterTrecho.Text = "Trecho";
            this.buttonManterTrecho.UseVisualStyleBackColor = true;
            this.buttonManterTrecho.Click += new System.EventHandler(this.buttonManterTrecho_Click);
            // 
            // buttonManterRota
            // 
            this.buttonManterRota.Location = new System.Drawing.Point(199, 76);
            this.buttonManterRota.Name = "buttonManterRota";
            this.buttonManterRota.Size = new System.Drawing.Size(144, 23);
            this.buttonManterRota.TabIndex = 4;
            this.buttonManterRota.Text = "Rota";
            this.buttonManterRota.UseVisualStyleBackColor = true;
            this.buttonManterRota.Click += new System.EventHandler(this.buttonManterRota_Click);
            // 
            // buttonManterVoo
            // 
            this.buttonManterVoo.Location = new System.Drawing.Point(112, 125);
            this.buttonManterVoo.Name = "buttonManterVoo";
            this.buttonManterVoo.Size = new System.Drawing.Size(144, 23);
            this.buttonManterVoo.TabIndex = 5;
            this.buttonManterVoo.Text = "Voo";
            this.buttonManterVoo.UseVisualStyleBackColor = true;
            this.buttonManterVoo.Click += new System.EventHandler(this.buttonManterVoo_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonManterTrecho);
            this.groupBox1.Controls.Add(this.buttonManterVoo);
            this.groupBox1.Controls.Add(this.buttonManterAeronave);
            this.groupBox1.Controls.Add(this.buttonManterRota);
            this.groupBox1.Controls.Add(this.buttonManterAeroporto);
            this.groupBox1.Location = new System.Drawing.Point(12, 78);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(362, 168);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gerenciar";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(290, 249);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "WMS Systems®";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 249);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            // 
            // FormAgAdm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 271);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "FormAgAdm";
            this.Text = "Agente Administrativo";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonManterAeronave;
        private System.Windows.Forms.Button buttonManterAeroporto;
        private System.Windows.Forms.Button buttonManterTrecho;
        private System.Windows.Forms.Button buttonManterRota;
        private System.Windows.Forms.Button buttonManterVoo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}