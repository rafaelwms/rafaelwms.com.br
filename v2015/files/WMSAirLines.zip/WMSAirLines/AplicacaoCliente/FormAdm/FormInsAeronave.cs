﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormInsAeronave : Form
    {
        Funcionario logado = new Funcionario();
        public FormInsAeronave(Funcionario func)
        {
            logado = func;
            InitializeComponent();
            localhostEmpresa.Aeronave novo = new localhostEmpresa.Aeronave();
            labelUser.Text = "Bem vindo: " + logado.NomeFunc;
        }

        private string MensagemValidaErro(string erro)
        {
            string erroValido = erro;
            string[] vetor = erro.Split(':');
            int index = vetor[2].IndexOf("\n");
            erroValido = vetor[2].Substring(0, index);
            return erroValido;
        }

        void inserirAeronave() 
        {
            localhostEmpresa.Aeronave novo = new localhostEmpresa.Aeronave();
            novo.ApelidoAeronave = textBoxApelido.Text;
            novo.IdAeronave = textBoxID.Text;
            novo.ModeloAeronave = textBoxModelo.Text;
            novo.Patio = comboBox1.SelectedIndex;

            try
            {
                novo.Milhas = int.Parse(textBoxMilhas.Text);
            }
            catch (Exception) 
            {
                MessageBox.Show("Use apenas números inteiros no campo de Milhas.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            try
            {
                novo.QtdPoltronas = int.Parse(textBoxPoltronas.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Use apenas números inteiros no campo de Poltronas.", "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            ServiceEmpresa srv = new ServiceEmpresa();

            try
            {
                srv.inserirAeronave(novo);
                MessageBox.Show("Aeronave "+ novo.ApelidoAeronave+ " inserido com êxito", "CONFIRMAÇÃO DE INCLUSÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(MensagemValidaErro(ex.Message), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }


        private void buttonConfirmar_Click(object sender, EventArgs e)
        {
            this.inserirAeronave();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }


    }
}
