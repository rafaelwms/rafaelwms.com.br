﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostVoo;
using AplicacaoCliente.localhostEmpresa;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormInsRota : Form
    {
        localhostVoo.ServiceVoo srv = new localhostVoo.ServiceVoo();
        Trecho temp = new Trecho();
        List<localhostVoo.Trecho> listaRota = new List<localhostVoo.Trecho>();
        int MinutosRota = 0;
        int MilhasRota = 0;
        int SeqTrecho = 1;
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormInsRota(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            preencherListaTrechos();
            LabelUser.Text = "Bem Vindo: " + logado.NomeFunc;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            alimentarRota();
        }

        private void preencherListaTrechos()
        {
            listViewTrechos.Items.Clear();
            List<Trecho> lista = new List<Trecho>();
            lista = srv.listarTrechos().ToList();
            foreach (Trecho tre in lista)
            {
                String[] linha = { tre.NomeTrecho, tre.Milhas.ToString(), tre.MinTrecho.ToString() };
                listViewTrechos.Items.Add(tre.CodTrecho.ToString()).SubItems.AddRange(linha);
            }

        }

        private void alimentarRota() 
        {
            Trecho trecho = new Trecho();
            trecho.CodTrecho = int.Parse(listViewTrechos.SelectedItems[0].Text);
            trecho.NomeTrecho = listViewTrechos.SelectedItems[0].SubItems[1].Text;
            trecho.Milhas = int.Parse(listViewTrechos.SelectedItems[0].SubItems[2].Text);
            trecho.MinTrecho = int.Parse(listViewTrechos.SelectedItems[0].SubItems[3].Text);
            
            if ((listViewTrechoTemp.Items.Count != 0) && (trecho.NomeTrecho.Substring(0,3) != temp.NomeTrecho.Substring(4, 3)))
            {
                MessageBox.Show("Só é possível adicinoar um trecho que possua a origem em: " + temp.NomeTrecho.Substring(4, 3), "ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            listaRota.Add(trecho);
            MilhasRota += trecho.Milhas;
            MinutosRota += trecho.MinTrecho;
            listViewTrechoTemp.Items.Add(SeqTrecho.ToString()).SubItems.Add(trecho.NomeTrecho);
            listViewTrechos.Items.Remove(listViewTrechos.SelectedItems[0]);
            textBoxMilhas.Text = MilhasRota.ToString();
            textBoxMinutos.Text = MinutosRota.ToString();
            SeqTrecho++;
            temp = trecho;
        }

        private void reset() 
        {
            MinutosRota = 0;
            MilhasRota = 0;
            SeqTrecho = 1;
            preencherListaTrechos();
            textBoxMilhas.Clear();
            textBoxMinutos.Clear();
            textBoxNome.Clear();
            listaRota = new List<Trecho>();
            listViewTrechoTemp.Items.Clear();
            temp = new Trecho();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void buttonInserir_Click(object sender, EventArgs e)
        {
            try
            {
                localhostVoo.Rota nova = new localhostVoo.Rota();
                nova.NomeRota = textBoxNome.Text;
                nova.MinRota = MinutosRota;
                nova.MilhasRota = MilhasRota;
                srv.inserirRota(nova);
                nova.CodRota = srv.localizarRotaInserida();
                SeqTrecho = 1;
                foreach (Trecho trecho in listaRota) 
                {
                    srv.inserirTrechoDaRota(nova, SeqTrecho, trecho);
                    SeqTrecho++;
                }
                MessageBox.Show("Rota " + nova.NomeRota + " inserida com êxito.", "Confirmação", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                
                reset();
            }
            catch (Exception ex)
            {
                
                 MessageBox.Show(ex.Message,"ALERTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        


    }
}
