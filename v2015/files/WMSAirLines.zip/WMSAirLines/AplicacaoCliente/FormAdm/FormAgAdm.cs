﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AplicacaoCliente.localhostEmpresa;
using AplicacaoCliente.localhostVoo;

namespace AplicacaoCliente.FormAdm
{
    public partial class FormAgAdm : Form
    {
        localhostEmpresa.Funcionario logado = new localhostEmpresa.Funcionario();
        public FormAgAdm(localhostEmpresa.Funcionario func)
        {
            logado = func;
            InitializeComponent();
            label3.Text = "Usuário: "+logado.NomeFunc;
        }

        private void buttonManterAeronave_Click(object sender, EventArgs e)
        {
            FormManterAeronave form = new FormManterAeronave(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void buttonManterAeroporto_Click(object sender, EventArgs e)
        {
            FormManterAeroporto form = new FormManterAeroporto(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();

        }

        private void buttonManterTrecho_Click(object sender, EventArgs e)
        {
            FormManterTrecho form = new FormManterTrecho(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void buttonManterVoo_Click(object sender, EventArgs e)
        {
            FormManterVoo form = new FormManterVoo(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();
        }

        private void buttonManterRota_Click(object sender, EventArgs e)
        {
            FormManterRota form = new FormManterRota(logado);
            this.Hide();
            form.ShowDialog();
            this.Show();
        }
    }
}
