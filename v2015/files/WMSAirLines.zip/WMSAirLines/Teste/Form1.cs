﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ClassesComuns.Basicas;
using ClassesComuns.Controladores;

namespace Teste
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Usuario usr = new Usuario();

            usr.NomeUser = textBoxNome.Text;
            usr.LoginUser = textBoxLogin.Text;
            usr.SenhaUser = textBoxSenha.Text;
            usr.ModoAcesso = "TESTE";

            try 
            {
                ControladorUsuario ctl = new ControladorUsuario();
                ctl.inserirUsuario(usr);
                MessageBox.Show("Usuario inserido com êxito.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }
    }
}
