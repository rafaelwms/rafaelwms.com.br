﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using ClassesComuns.Basicas;
using ClassesComuns.Controladores;
using ClassesComuns.Interfaces;
namespace WebServiceVoo
{
    /// <summary>
    /// Summary description for ServiceVoo
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ServiceVoo : System.Web.Services.WebService
    {

        [WebMethod]
        public void inserirAeroporto(Aeroporto porto)
        {
            try
            {
                ControladorAeroporto ctl = new ControladorAeroporto();
                ctl.inserirAeroporto(porto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void alterarAeroporto(Aeroporto porto)
        {
            try
            {
                ControladorAeroporto ctl = new ControladorAeroporto();
                ctl.alterarAeroporto(porto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void excluirAeroporto(Aeroporto porto)
        {
            try
            {
                ControladorAeroporto ctl = new ControladorAeroporto();
                ctl.excluirAeroporto(porto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Aeroporto> listarAeroportos()
        {
            try
            {
                List<Aeroporto> lista = new List<Aeroporto>();
                ControladorAeroporto ctl = new ControladorAeroporto();
                lista = ctl.listarAeroportos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Aeroporto> procurarAeroportos(String busca)
        {
            try
            {
                List<Aeroporto> lista = new List<Aeroporto>();
                ControladorAeroporto ctl = new ControladorAeroporto();
                lista = ctl.procurarAeroporto(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirTrecho(Trecho trecho)
        {
            try
            {
                ControladorTrecho ctl = new ControladorTrecho();
                ctl.inserirTrecho(trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void alterarTrecho(Trecho trecho)
        {
            try
            {
                ControladorTrecho ctl = new ControladorTrecho();
                ctl.alterarTrecho(trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void excluirTrecho(Trecho trecho)
        {
            try
            {
                ControladorTrecho ctl = new ControladorTrecho();
                ctl.excluirTrecho(trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Trecho> listarTrechos()
        {
            try
            {
                List<Trecho> lista = new List<Trecho>();
                ControladorTrecho ctl = new ControladorTrecho();
                lista = ctl.listarTrechos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Trecho> procurarTrecho(String busca)
        {
            try
            {
                List<Trecho> lista = new List<Trecho>();
                ControladorTrecho ctl = new ControladorTrecho();
                lista = ctl.procurarTrecho(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirRota(Rota rota)
        {
            try
            {
                ControladorRota ctl = new ControladorRota();
                ctl.inserirRota(rota);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void alterarrRota(Rota rota)
        {
            try
            {
                ControladorRota ctl = new ControladorRota();
                ctl.alterarRota(rota);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void excluirRota(Rota rota)
        {
            try
            {
                ControladorRota ctl = new ControladorRota();
                ctl.excluirRota(rota);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Rota> listarRotas()
        {
            try
            {
                List<Rota> lista = new List<Rota>();
                ControladorRota ctl = new ControladorRota();
                lista = ctl.listarRotas();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Rota> procurarRota(String busca)
        {
            try
            {
                List<Rota> lista = new List<Rota>();
                ControladorRota ctl = new ControladorRota();
                lista = ctl.procurarRota(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirTrechoDaRota(Rota rota, int numtrecho, Trecho trecho)
        {
            try
            {
                ControladorRota ctl = new ControladorRota();
                ctl.inserirTrechoDaRota(rota, numtrecho, trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void excluirTrechoDaRota(Rota rota, Trecho trecho)
        {
            try
            {
                ControladorRota ctl = new ControladorRota();
                ctl.removerTrechoDaRota(rota, trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Trecho> listarTrechosDaRota(Rota rota)
        {
            try
            {
                List<Trecho> lista = new List<Trecho>();
                ControladorRota ctl = new ControladorRota();
                lista = ctl.listarTrechosDaRota(rota);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public int localizarRotaInserida()
        {
            try
            {
                ControladorRota ctl = new ControladorRota();           
                return ctl.localizarRotaInserida();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirVoo(Voo voo)
        {
            try
            {
                ControladorVoo ctl = new ControladorVoo();
                ctl.inserirVoo(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void alterarVoo(Voo voo)
        {
            try
            {
                ControladorVoo ctl = new ControladorVoo();
                ctl.alterarVoo(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void excluirVoo(Voo voo)
        {
            try
            {
                ControladorVoo ctl = new ControladorVoo();
                ctl.excluirVoo(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Voo> listarVoos()
        {
            try
            {
                List<Voo> lista = new List<Voo>();
                ControladorVoo ctl = new ControladorVoo();
                lista = ctl.listarVoos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Voo> procurarVoo(String busca)
        {
            try
            {
                List<Voo> lista = new List<Voo>();
                ControladorVoo ctl = new ControladorVoo();
                lista = ctl.procurarVoo(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void confirmarDecolagem(Voo voo)
        {
            try
            {
                ControladorVoo ctl = new ControladorVoo();
                ctl.confirmarDecolagem(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        [WebMethod]
        public void confirmarAterrissagem(Voo voo)
        {
            try
            {
                ControladorVoo ctl = new ControladorVoo();
                ctl.confirmarAterrissagem(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


    }
}
