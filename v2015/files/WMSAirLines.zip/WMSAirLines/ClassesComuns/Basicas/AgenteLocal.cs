﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
    class AgenteLocal : Funcionario
    {

        private int codAgLocal;

        public int CodAgLocal
        {
            get { return codAgLocal; }
            set { codAgLocal = value; }
        }

        private String posicao;

        public String Posicao
        {
            get { return posicao; }
            set { posicao = value; }
        }


    }
}
