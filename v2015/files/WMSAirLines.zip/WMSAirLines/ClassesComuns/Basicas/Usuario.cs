﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
   public class Usuario
    {

        private int codUser;

        public int CodUser
        {
            get { return codUser; }
            set { codUser = value; }
        }

        private String nomeUser;

        public String NomeUser
        {
            get { return nomeUser; }
            set { nomeUser = value; }
        }

        private String loginUser;

        public String LoginUser
        {
            get { return loginUser; }
            set { loginUser = value; }
        }

        private String senhaUser;

        public String SenhaUser
        {
            get { return senhaUser; }
            set { senhaUser = value; }
        }

        private String cpfUser;

        public String CpfUser
        {
            get { return cpfUser; }
            set { cpfUser = value; }
        }


        private String rgUser;

        public String RgUser
        {
            get { return rgUser; }
            set { rgUser = value; }
        }

    }
}
