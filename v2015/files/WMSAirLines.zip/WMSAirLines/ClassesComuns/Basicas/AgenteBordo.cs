﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
   public class AgenteBordo : Funcionario
    {

        private int codAgBordo;

        public int CodAgBordo
        {
            get { return codAgBordo; }
            set { codAgBordo = value; }
        }

        private int enfermeiro;

        public int Enfermeiro
        {
            get { return enfermeiro; }
            set { enfermeiro = value; }
        }

        private int disp;

        public int Disp
        {
            get { return disp; }
            set { disp = value; }
        }

    }
}
