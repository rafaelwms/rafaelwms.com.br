﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
   public class Aeronave
    {

        private int codAeronave;

        public int CodAeronave
        {
            get { return codAeronave; }
            set { codAeronave = value; }
        }

        private String idAeronave;

        public String IdAeronave
        {
            get { return idAeronave; }
            set { idAeronave = value; }
        }

        private String apelidoAeronave;

        public String ApelidoAeronave
        {
            get { return apelidoAeronave; }
            set { apelidoAeronave = value; }
        }

        private String modeloAeronave;

        public String ModeloAeronave
        {
            get { return modeloAeronave; }
            set { modeloAeronave = value; }
        }

        private int qtdPoltronas;

        public int QtdPoltronas
        {
            get { return qtdPoltronas; }
            set { qtdPoltronas = value; }
        }

        private int milhas;

        public int Milhas
        {
            get { return milhas; }
            set { milhas = value; }
        }

        private int patio;

        public int Patio
        {
            get { return patio; }
            set { patio = value; }
        }

    }
}
