﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
   public class Piloto : Funcionario
    {



        private int codPiloto;

        public int CodPiloto
        {
            get { return codPiloto; }
            set { codPiloto = value; }
        }

        private String breve;

        public String Breve
        {
            get { return breve; }
            set { breve = value; }
        }

        private int horasVoo;

        public int HorasVoo
        {
            get { return horasVoo; }
            set { horasVoo = value; }
        }

        private int disp;

        public int Disp
        {
            get { return disp; }
            set { disp = value; }
        }

    }
}
