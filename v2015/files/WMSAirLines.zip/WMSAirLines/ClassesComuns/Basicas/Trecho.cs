﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
    public class Trecho
    {

        private int codTrecho;

        public int CodTrecho
        {
            get { return codTrecho; }
            set { codTrecho = value; }
        }


        private String nomeTrecho;

        public String NomeTrecho
        {
            get { return nomeTrecho; }
            set { nomeTrecho = value; }
        }


        private Aeroporto origem;

        public Aeroporto Origem
        {
            get { return origem; }
            set { origem = value; }
        }


        private Aeroporto destino;

        public Aeroporto Destino
        {
            get { return destino; }
            set { destino = value; }
        }


        private int milhas;

        public int Milhas
        {
            get { return milhas; }
            set { milhas = value; }
        }


        private int minTrecho;

        public int MinTrecho
        {
            get { return minTrecho; }
            set { minTrecho = value; }
        }

    }
}
