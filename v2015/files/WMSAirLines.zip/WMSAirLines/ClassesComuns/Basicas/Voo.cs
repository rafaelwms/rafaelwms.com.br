﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
    public class Voo
    {
        private int codVoo;

        public int CodVoo
        {
            get { return codVoo; }
            set { codVoo = value; }
        }


        private int numVoo;

        public int NumVoo
        {
            get { return numVoo; }
            set { numVoo = value; }
        }


        private String dataVoo;

        public String DataVoo
        {
            get { return dataVoo; }
            set { dataVoo = value; }
        }


        private String horaVoo;

        public String HoraVoo
        {
            get { return horaVoo; }
            set { horaVoo = value; }
        }


        private Aeronave naveVoo;

        public Aeronave NaveVoo
        {
            get { return naveVoo; }
            set { naveVoo = value; }
        }


        private Rota rotaVoo;

        public Rota RotaVoo
        {
            get { return rotaVoo; }
            set { rotaVoo = value; }
        }


        private Piloto pilotoVoo;

        public Piloto PilotoVoo
        {
            get { return pilotoVoo; }
            set { pilotoVoo = value; }
        }


        private Piloto coPilotoVoo;

        public Piloto CoPilotoVoo
        {
            get { return coPilotoVoo; }
            set { coPilotoVoo = value; }
        }


        private AgenteBordo agBordo1;

        public AgenteBordo AgBordo1
        {
            get { return agBordo1; }
            set { agBordo1 = value; }
        }


        private AgenteBordo agBordo2;

        public AgenteBordo AgBordo2
        {
            get { return agBordo2; }
            set { agBordo2 = value; }
        }


        private AgenteBordo agBordo3;

        public AgenteBordo AgBordo3
        {
            get { return agBordo3; }
            set { agBordo3 = value; }
        }


        private AgenteBordo agBordo4;

        public AgenteBordo AgBordo4
        {
            get { return agBordo4; }
            set { agBordo4 = value; }
        }


    }
}
