﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
    public class Aeroporto
    {

        private int codAeroporto;

        public int CodAeroporto
        {
            get { return codAeroporto; }
            set { codAeroporto = value; }
        }


        private String nomeAeroporto;

        public String NomeAeroporto
        {
            get { return nomeAeroporto; }
            set { nomeAeroporto = value; }
        }


        private String cidadeAeroporto;

        public String CidadeAeroporto
        {
            get { return cidadeAeroporto; }
            set { cidadeAeroporto = value; }
        }


        private String ufAeroporto;

        public String UfAeroporto
        {
            get { return ufAeroporto; }
            set { ufAeroporto = value; }
        }


        private String siglaAeroporto;

        public String SiglaAeroporto
        {
            get { return siglaAeroporto; }
            set { siglaAeroporto = value; }
        }


    }
}
