﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
   public class Funcionario
    {
        private int codFunc;

        public int CodFunc
        {
            get { return codFunc; }
            set { codFunc = value; }
        }

        private String nomeFunc;

        public String NomeFunc
        {
            get { return nomeFunc; }
            set { nomeFunc = value; }
        }


        private String loginFunc;

        public String LoginFunc
        {
            get { return loginFunc; }
            set { loginFunc = value; }
        }


        private String senhaFunc;

        public String SenhaFunc
        {
            get { return senhaFunc; }
            set { senhaFunc = value; }
        }


        private String rgFunc;


        public String RgFunc
        {
            get { return rgFunc; }
            set { rgFunc = value; }
        }

        private String cpfFunc;

        public String CpfFunc
        {
            get { return cpfFunc; }
            set { cpfFunc = value; }
        }

        private Decimal salario;

        public Decimal Salario
        {
            get { return salario; }
            set { salario = value; }
        }


        private String cargoFunc;

        public String CargoFunc
        {
            get { return cargoFunc; }
            set { cargoFunc = value; }
        }


        private int ativo;

        public int Ativo
        {
            get { return ativo; }
            set { ativo = value; }
        }
    }
}
