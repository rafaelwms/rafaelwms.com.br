﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassesComuns.Basicas
{
   public class Rota
    {

        private int codRota;

        public int CodRota
        {
            get { return codRota; }
            set { codRota = value; }
        }


        private String nomeRota;

        public String NomeRota
        {
            get { return nomeRota; }
            set { nomeRota = value; }
        }


        private int milhasRota;

        public int MilhasRota
        {
            get { return milhasRota; }
            set { milhasRota = value; }
        }


        private int minRota;

        public int MinRota
        {
            get { return minRota; }
            set { minRota = value; }
        }




    }
}
