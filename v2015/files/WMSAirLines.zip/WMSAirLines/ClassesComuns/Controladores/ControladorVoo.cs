﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
    public class ControladorVoo : InterfaceVoo
    {

        DadosVoo dados = new DadosVoo();

        public void inserirVoo(Voo voo)
        {
            try
            {
                if ((voo.NaveVoo.CodAeronave == null) || (voo.NaveVoo.CodAeronave < 1))
                {
                    throw new Exception("É preciso selecionar uma aeronave.");
                }
                if ((voo.RotaVoo.CodRota == null) || (voo.RotaVoo.CodRota < 1))
                {
                    throw new Exception("É preciso selecionar uma rota.");
                }
                if ((voo.PilotoVoo.CodPiloto == null) || (voo.PilotoVoo.CodPiloto < 1))
                {
                    throw new Exception("É preciso selecionar um piloto.");
                }
                if ((voo.CoPilotoVoo.CodPiloto == null) || (voo.CoPilotoVoo.CodPiloto < 1))
                {
                    throw new Exception("É preciso selecionar um co-piloto.");
                }
                if (voo.CoPilotoVoo.CodPiloto == voo.PilotoVoo.CodPiloto)
                {
                    throw new Exception("O piloto e o co-piloto não podem ser o mesmo.");
                }
                if ((voo.AgBordo1.CodAgBordo == null) || (voo.AgBordo1.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o primeiro Agente de Bordo.");
                }
                if ((voo.AgBordo2.CodAgBordo == null) || (voo.AgBordo2.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o segundo Agente de Bordo.");
                }
                if ((voo.AgBordo3.CodAgBordo == null) || (voo.AgBordo3.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o terceiro Agente de Bordo.");
                }
                if ((voo.AgBordo4.CodAgBordo == null) || (voo.AgBordo4.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o quarto Agente de Bordo.");
                }
                if ((voo.AgBordo1.CodAgBordo == voo.AgBordo2.CodAgBordo) || (voo.AgBordo1.CodAgBordo == voo.AgBordo3.CodAgBordo)
                    || (voo.AgBordo1.CodAgBordo == voo.AgBordo4.CodAgBordo) || (voo.AgBordo2.CodAgBordo == voo.AgBordo3.CodAgBordo)
                    || (voo.AgBordo2.CodAgBordo == voo.AgBordo4.CodAgBordo) || (voo.AgBordo3.CodAgBordo == voo.AgBordo4.CodAgBordo))
                {
                    throw new Exception("Não é possivel selecionar agentes repetidos.");
                }

                dados.inserirVoo(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarVoo(Voo voo)
        {
            try
            {
                if ((voo.NaveVoo.CodAeronave == null) || (voo.NaveVoo.CodAeronave < 1))
                {
                    throw new Exception("É preciso selecionar uma aeronave.");
                }
                if ((voo.RotaVoo.CodRota == null) || (voo.RotaVoo.CodRota < 1))
                {
                    throw new Exception("É preciso selecionar uma rota.");
                }
                if ((voo.PilotoVoo.CodPiloto == null) || (voo.PilotoVoo.CodPiloto < 1))
                {
                    throw new Exception("É preciso selecionar um piloto.");
                }
                if ((voo.CoPilotoVoo.CodPiloto == null) || (voo.CoPilotoVoo.CodPiloto < 1))
                {
                    throw new Exception("É preciso selecionar um co-piloto.");
                }
                if (voo.CoPilotoVoo.CodPiloto == voo.PilotoVoo.CodPiloto)
                {
                    throw new Exception("O piloto e o co-piloto não podem ser o mesmo.");
                }
                if ((voo.AgBordo1.CodAgBordo == null) || (voo.AgBordo1.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o primeiro Agente de Bordo.");
                }
                if ((voo.AgBordo2.CodAgBordo == null) || (voo.AgBordo2.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o segundo Agente de Bordo.");
                }
                if ((voo.AgBordo3.CodAgBordo == null) || (voo.AgBordo3.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o terceiro Agente de Bordo.");
                }
                if ((voo.AgBordo4.CodAgBordo == null) || (voo.AgBordo4.CodAgBordo < 1))
                {
                    throw new Exception("É preciso selecionar o quarto Agente de Bordo.");
                }
                if ((voo.AgBordo1.CodAgBordo == voo.AgBordo2.CodAgBordo) || (voo.AgBordo1.CodAgBordo == voo.AgBordo3.CodAgBordo)
                    || (voo.AgBordo1.CodAgBordo == voo.AgBordo4.CodAgBordo) || (voo.AgBordo2.CodAgBordo == voo.AgBordo3.CodAgBordo)
                    || (voo.AgBordo2.CodAgBordo == voo.AgBordo4.CodAgBordo) || (voo.AgBordo3.CodAgBordo == voo.AgBordo4.CodAgBordo))
                {
                    throw new Exception("Não é possivel selecionar agentes repetidos.");
                }

                dados.alterarVoo(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirVoo(Voo voo)
        {

            try
            {
                if ((voo.CodVoo == null) || (voo.CodVoo < 1))
                {
                    throw new Exception("É preciso escolher um voo para exclusão.");
                }
                dados.excluirVoo(voo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Voo> listarVoos()
        {

            try
            {
                List<Voo> lista = new List<Voo>();
                lista = dados.listarVoos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Voo> procurarVoo(string busca)
        {
            try
            {
                List<Voo> lista = new List<Voo>();
                lista = dados.procurarVoo(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void confirmarDecolagem(Voo voo)
        {
            try
            {
                dados.confirmarDecolagem(voo);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }

        public void confirmarAterrissagem(Voo voo)
        {
            try
            {
                dados.confirmarAterrissagem(voo);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }




    }
}

