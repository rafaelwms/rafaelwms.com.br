﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
    public class ControladorAgenteBordo : InterfaceAgenteBordo
    {

        DadosAgenteBordo dados = new DadosAgenteBordo();

        public void inserirAgenteBordo(AgenteBordo agbordo)
        {
            try
            {
                if (agbordo.CodFunc == null) 
                {
                    throw new Exception("Selecione um Agente de Bordo na lista."); 
                }
                if (agbordo.CodFunc < 0)
                {
                    throw new Exception("Selecione um Agente de Bordo na lista.");
                }

                #region Tratando Nome
                if (agbordo.NomeFunc.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o agente de bordo.");
                }

                if (agbordo.NomeFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o agente de bordo deve conter de 4 até 100 caractéres.");
                }

                if (agbordo.NomeFunc.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o agente de bordo deve conter de 4 até 100 caractéres.");
                }

                if ((agbordo.NomeFunc.Contains("@")) || (agbordo.NomeFunc.Contains("#")) || (agbordo.NomeFunc.Contains("$")) || (agbordo.NomeFunc.Contains("'"))
                    || (agbordo.NomeFunc.Contains("%")) || (agbordo.NomeFunc.Contains("&")) || (agbordo.NomeFunc.Contains("(")) || (agbordo.NomeFunc.Contains(")"))
                    || (agbordo.NomeFunc.Contains("-")) || (agbordo.NomeFunc.Contains("+")) || (agbordo.NomeFunc.Contains("=")) || (agbordo.NomeFunc.Contains("{"))
                    || (agbordo.NomeFunc.Contains("}")) || (agbordo.NomeFunc.Contains("[")) || (agbordo.NomeFunc.Contains("]")) || (agbordo.NomeFunc.Contains("?"))
                    || (agbordo.NomeFunc.Contains("!")) || (agbordo.NomeFunc.Contains("§")))
                {
                    throw new Exception("O nome para o agente de bordo não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Login
                if (agbordo.LoginFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar um login para o agente de bordo.");
                }

                if (agbordo.LoginFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O login para o agente de bordo deve conter de 4 até 20 caractéres.");
                }

                if (agbordo.LoginFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. O login para o agente de bordo deve conter de 4 até 20 caractéres.");
                }

                if ((agbordo.LoginFunc.Contains("@")) || (agbordo.LoginFunc.Contains("#")) || (agbordo.LoginFunc.Contains("$")) || (agbordo.LoginFunc.Contains("'"))
                   || (agbordo.LoginFunc.Contains("%")) || (agbordo.LoginFunc.Contains("&")) || (agbordo.LoginFunc.Contains("(")) || (agbordo.LoginFunc.Contains(")"))
                   || (agbordo.LoginFunc.Contains("+")) || (agbordo.LoginFunc.Contains("=")) || (agbordo.LoginFunc.Contains("{"))
                   || (agbordo.LoginFunc.Contains("}")) || (agbordo.LoginFunc.Contains("[")) || (agbordo.LoginFunc.Contains("]")) || (agbordo.LoginFunc.Contains("?"))
                   || (agbordo.LoginFunc.Contains("!")) || (agbordo.LoginFunc.Contains("§")))
                {
                    throw new Exception("O login para o agente de bordo não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }

                List<AgenteBordo> teste = new List<AgenteBordo>();
                teste = dados.listarAgsBordo();

                foreach (AgenteBordo tst in teste)
                {
                    if (agbordo.LoginFunc == tst.LoginFunc)
                    {
                        throw new Exception("Login indisponível");
                    }
                }
                #endregion

                #region Tratando Senha
                if (agbordo.SenhaFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o agente de bordo.");
                }

                if (agbordo.SenhaFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A senha para o agente de bordo deve conter de 4 até 20 caractéres.");
                }

                if (agbordo.SenhaFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o agente de bordo deve conter de 4 até 20 caractéres.");
                }

                if ((agbordo.SenhaFunc.Contains("@")) || (agbordo.SenhaFunc.Contains("#")) || (agbordo.SenhaFunc.Contains("$")) || (agbordo.SenhaFunc.Contains("'"))
                   || (agbordo.SenhaFunc.Contains("%")) || (agbordo.SenhaFunc.Contains("&")) || (agbordo.SenhaFunc.Contains("(")) || (agbordo.SenhaFunc.Contains(")"))
                   || (agbordo.SenhaFunc.Contains("+")) || (agbordo.SenhaFunc.Contains("=")) || (agbordo.SenhaFunc.Contains("{"))
                   || (agbordo.SenhaFunc.Contains("}")) || (agbordo.SenhaFunc.Contains("[")) || (agbordo.SenhaFunc.Contains("]")) || (agbordo.SenhaFunc.Contains("?"))
                   || (agbordo.SenhaFunc.Contains("!")) || (agbordo.SenhaFunc.Contains("§")))
                {
                    throw new Exception("A senha para o agente de bordo não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando CPF
                if (agbordo.CpfFunc.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((agbordo.CpfFunc.Equals("111,111,111-11")) || (agbordo.CpfFunc.Equals("222,222,222-22")) || (agbordo.CpfFunc.Equals("333,333,333-33"))
                    || (agbordo.CpfFunc.Equals("444,444,444-44")) || (agbordo.CpfFunc.Equals("555,555,555-55")) || (agbordo.CpfFunc.Equals("666,666,666-66"))
                    || (agbordo.CpfFunc.Equals("777,777,777-77")) || (agbordo.CpfFunc.Equals("888,888,888-88")) || (agbordo.CpfFunc.Equals("999,999,999-9"))
                    || (agbordo.CpfFunc.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                }
                #endregion

                #region Tartando Cargo
                if (agbordo.CargoFunc == null)
                {
                    throw new Exception("Escolha um cargo");
                }

                if (agbordo.CargoFunc.Equals(""))
                {
                    throw new Exception("Escolha um cargo");
                }
                #endregion

                dados.inserirAgenteBordo(agbordo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<AgenteBordo> listarAgsBordo()
        {
            try
            {
                List<AgenteBordo> lista = new List<AgenteBordo>();
                lista = dados.listarAgsBordo();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<AgenteBordo> procurarAgBordo(string busca)
        {

            try
            {
                if (busca == null) 
                {
                    throw new Exception("Busca nula.");
                }

                if (busca.Trim().Equals(""))
                {
                    throw new Exception("Digite algo para referenciar a busca.");
                }
                List<AgenteBordo> lista = new List<AgenteBordo>();
                lista = dados.procurarAgBordo(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void alterarAgenteBordo(AgenteBordo agbordo)
        {

            try
            {
                if (agbordo.CodFunc == null)
                {
                    throw new Exception("Selecione um Agente de Bordo na lista.");
                }
                if (agbordo.CodFunc < 0)
                {
                    throw new Exception("Selecione um Agente de Bordo na lista.");
                }

                #region Tratando Nome
                if (agbordo.NomeFunc.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o agente de bordo.");
                }

                if (agbordo.NomeFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o agente de bordo deve conter de 4 até 100 caractéres.");
                }

                if (agbordo.NomeFunc.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o agente de bordo deve conter de 4 até 100 caractéres.");
                }

                if ((agbordo.NomeFunc.Contains("@")) || (agbordo.NomeFunc.Contains("#")) || (agbordo.NomeFunc.Contains("$")) || (agbordo.NomeFunc.Contains("'"))
                    || (agbordo.NomeFunc.Contains("%")) || (agbordo.NomeFunc.Contains("&")) || (agbordo.NomeFunc.Contains("(")) || (agbordo.NomeFunc.Contains(")"))
                    || (agbordo.NomeFunc.Contains("-")) || (agbordo.NomeFunc.Contains("+")) || (agbordo.NomeFunc.Contains("=")) || (agbordo.NomeFunc.Contains("{"))
                    || (agbordo.NomeFunc.Contains("}")) || (agbordo.NomeFunc.Contains("[")) || (agbordo.NomeFunc.Contains("]")) || (agbordo.NomeFunc.Contains("?"))
                    || (agbordo.NomeFunc.Contains("!")) || (agbordo.NomeFunc.Contains("§")))
                {
                    throw new Exception("O nome para o agente de bordo não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Senha
                if (agbordo.SenhaFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o agente de bordo.");
                }

                if (agbordo.SenhaFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A senha para o agente de bordo deve conter de 4 até 20 caractéres.");
                }

                if (agbordo.SenhaFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o agente de bordo deve conter de 4 até 20 caractéres.");
                }

                if ((agbordo.SenhaFunc.Contains("@")) || (agbordo.SenhaFunc.Contains("#")) || (agbordo.SenhaFunc.Contains("$")) || (agbordo.SenhaFunc.Contains("'"))
                   || (agbordo.SenhaFunc.Contains("%")) || (agbordo.SenhaFunc.Contains("&")) || (agbordo.SenhaFunc.Contains("(")) || (agbordo.SenhaFunc.Contains(")"))
                   || (agbordo.SenhaFunc.Contains("+")) || (agbordo.SenhaFunc.Contains("=")) || (agbordo.SenhaFunc.Contains("{"))
                   || (agbordo.SenhaFunc.Contains("}")) || (agbordo.SenhaFunc.Contains("[")) || (agbordo.SenhaFunc.Contains("]")) || (agbordo.SenhaFunc.Contains("?"))
                   || (agbordo.SenhaFunc.Contains("!")) || (agbordo.SenhaFunc.Contains("§")))
                {
                    throw new Exception("A senha para o agente de bordo não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando CPF
                if (agbordo.CpfFunc.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((agbordo.CpfFunc.Equals("111,111,111-11")) || (agbordo.CpfFunc.Equals("222,222,222-22")) || (agbordo.CpfFunc.Equals("333,333,333-33"))
                    || (agbordo.CpfFunc.Equals("444,444,444-44")) || (agbordo.CpfFunc.Equals("555,555,555-55")) || (agbordo.CpfFunc.Equals("666,666,666-66"))
                    || (agbordo.CpfFunc.Equals("777,777,777-77")) || (agbordo.CpfFunc.Equals("888,888,888-88")) || (agbordo.CpfFunc.Equals("999,999,999-9"))
                    || (agbordo.CpfFunc.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                }
                #endregion


                dados.alterarAgenteBordo(agbordo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void demitirAgBordo(AgenteBordo agbordo)
        {
            try
            {
                if (agbordo.CodAgBordo == null)
                {
                    throw new Exception("Selecione um Agente de Bordo na lista.");
                }
                if (agbordo.CodAgBordo < 0)
                {
                    throw new Exception("Selecione um Agente de Bordo na lista.");
                }

                dados.demitirAgBordo(agbordo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
