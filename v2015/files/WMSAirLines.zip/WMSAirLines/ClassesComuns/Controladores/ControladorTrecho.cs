﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
    public class ControladorTrecho : InterfaceTrecho
    {

        DadosTrecho dados = new DadosTrecho();

        public void inserirTrecho(Trecho trecho)
        {

            try
            {
                if ((trecho.Origem.CodAeroporto == null) || (trecho.Origem.CodAeroporto < 1))
                {
                    throw new Exception("Escolha um aeroporto de origem.");
                }
                if ((trecho.Destino.CodAeroporto == null) || (trecho.Destino.CodAeroporto < 1))
                {
                    throw new Exception("Escolha um aeroporto de destino.");
                }
                if (trecho.Milhas < 100) 
                {
                throw new Exception("Trecho com menos de 100 milhas. Não compensa o voo.");
                }
                if (trecho.MinTrecho < 60)
                {
                    throw new Exception("Trecho com menos de 60 minutos. Não compreende todos os procedimentos.");
                }


                dados.inserirTrecho(trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Trecho> listarTrechos()
        {
            try
            {
                List<Trecho> lista = new List<Trecho>();
                lista = dados.listarTrechos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Trecho> procurarTrecho(string busca)
        {

            try
            {
                if (busca == null)
                {
                    throw new Exception("Busca nula.");
                }

                if (busca.Trim().Equals(""))
                {
                    throw new Exception("Digite algo para a busca.");
                }
                List<Trecho> lista = new List<Trecho>();
                lista = dados.procurarTrecho(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void alterarTrecho(Trecho trecho)
        {

            try
            {
                if ((trecho.Origem.CodAeroporto == null) || (trecho.Origem.CodAeroporto < 1))
                {
                    throw new Exception("Escolha um aeroporto de origem.");
                }
                if ((trecho.Destino.CodAeroporto == null) || (trecho.Destino.CodAeroporto < 1))
                {
                    throw new Exception("Escolha um aeroporto de destino.");
                }
                if (trecho.Milhas < 100)
                {
                    throw new Exception("Trecho com menos de 100 milhas. Não compensa o voo.");
                }
                if (trecho.MinTrecho < 60)
                {
                    throw new Exception("Trecho com menos de 60 minutos. Não compreende todos os procedimentos.");
                }


                dados.alterarTrecho(trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void excluirTrecho(Trecho trecho)
        {

            try
            {
                if ((trecho.CodTrecho == null) || (trecho.CodTrecho < 1)) 
                {
                    throw new Exception("É necessário escolher um trecho para excluir.");
                }
                if (dados.procurarTrechoRota(trecho.CodTrecho).Count != 0) 
                {
                    throw new Exception("Não é possível excluir o trecho, pois, está associado a uma rota.");
                }

                dados.excluirTrecho(trecho);
            }
            catch (Exception ex)
            {
                
                throw new Exception(ex.Message);
            }

        }
    }
}
