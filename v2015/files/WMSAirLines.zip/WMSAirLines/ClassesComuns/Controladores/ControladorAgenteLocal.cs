﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;

namespace ClassesComuns.Controladores
{
    class ControladorAgenteLocal : InterfaceAgenteLocal
    {
        public void inserirAgLocal(AgenteLocal aglocal)
        {
            throw new NotImplementedException();
        }

        public List<AgenteLocal> listarAgsLocal()
        {
            throw new NotImplementedException();
        }

        public List<AgenteLocal> procurarAgLocal(string busca)
        {
            throw new NotImplementedException();
        }

        public void alterarAgLocal(AgenteLocal aglocal)
        {
            throw new NotImplementedException();
        }

        public void demitirAgLocal(AgenteLocal aglocal)
        {
            throw new NotImplementedException();
        }
    }
}
