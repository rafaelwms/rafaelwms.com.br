﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
    public class ControladorUsuario : InterfaceUsuario
    {

        DadosUsuario dados = new DadosUsuario();
        public void inserirUsuario(Usuario usuario)
        {
            
            try
            {

                #region Tratando Nome
                if (usuario.NomeUser.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o usuário.");
                }

                if (usuario.NomeUser.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o usuário deve conter de 4 até 100 caractéres.");
                }

                if (usuario.NomeUser.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o usuário deve conter de 4 até 100 caractéres.");
                }

                if ((usuario.NomeUser.Contains("@")) || (usuario.NomeUser.Contains("#")) || (usuario.NomeUser.Contains("$")) || (usuario.NomeUser.Contains("'"))
                    || (usuario.NomeUser.Contains("%")) || (usuario.NomeUser.Contains("&")) || (usuario.NomeUser.Contains("(")) || (usuario.NomeUser.Contains(")"))
                    || (usuario.NomeUser.Contains("-")) || (usuario.NomeUser.Contains("+")) || (usuario.NomeUser.Contains("=")) || (usuario.NomeUser.Contains("{"))
                    || (usuario.NomeUser.Contains("}")) || (usuario.NomeUser.Contains("[")) || (usuario.NomeUser.Contains("]")) || (usuario.NomeUser.Contains("?"))
                    || (usuario.NomeUser.Contains("!")) || (usuario.NomeUser.Contains("§")))
                {
                    throw new Exception("O nome para o usuário não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Login
                if (usuario.LoginUser.Trim() == "")
                {
                    throw new Exception("É necessário digitar um login para o usuário.");
                }

                if (usuario.LoginUser.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O login para o usuário deve conter de 4 até 20 caractéres.");
                }

                if (usuario.LoginUser.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. O login para o usuário deve conter de 4 até 20 caractéres.");
                }

                if ((usuario.LoginUser.Contains("@")) || (usuario.LoginUser.Contains("#")) || (usuario.LoginUser.Contains("$")) || (usuario.LoginUser.Contains("'"))
                   || (usuario.LoginUser.Contains("%")) || (usuario.LoginUser.Contains("&")) || (usuario.LoginUser.Contains("(")) || (usuario.LoginUser.Contains(")"))
                   || (usuario.LoginUser.Contains("+")) || (usuario.LoginUser.Contains("=")) || (usuario.LoginUser.Contains("{"))
                   || (usuario.LoginUser.Contains("}")) || (usuario.LoginUser.Contains("[")) || (usuario.LoginUser.Contains("]")) || (usuario.LoginUser.Contains("?"))
                   || (usuario.LoginUser.Contains("!")) || (usuario.LoginUser.Contains("§")))
                {
                    throw new Exception("O login para o usuário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }

                List<Usuario> teste = new List<Usuario>();
                teste = dados.listarUsuarios();

                foreach (Usuario tst in teste)
                {
                    if (usuario.LoginUser == tst.LoginUser)
                    {
                        throw new Exception("Login indisponível");
                    }
                }


                #endregion

                #region Tratando Senha
                if (usuario.SenhaUser.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o usuário.");
                }

                if (usuario.SenhaUser.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A seinha para o usuário deve conter de 4 até 20 caractéres.");
                }

                if (usuario.SenhaUser.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o usuário deve conter de 4 até 20 caractéres.");
                }

                if ((usuario.SenhaUser.Contains("@")) || (usuario.SenhaUser.Contains("#")) || (usuario.SenhaUser.Contains("$")) || (usuario.SenhaUser.Contains("'"))
                   || (usuario.SenhaUser.Contains("%")) || (usuario.SenhaUser.Contains("&")) || (usuario.SenhaUser.Contains("(")) || (usuario.SenhaUser.Contains(")"))
                   || (usuario.SenhaUser.Contains("+")) || (usuario.SenhaUser.Contains("=")) || (usuario.SenhaUser.Contains("{"))
                   || (usuario.SenhaUser.Contains("}")) || (usuario.SenhaUser.Contains("[")) || (usuario.SenhaUser.Contains("]")) || (usuario.SenhaUser.Contains("?"))
                   || (usuario.SenhaUser.Contains("!")) || (usuario.SenhaUser.Contains("§")))
                {
                    throw new Exception("A senha para o usuário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }

                #endregion

                #region Tratando CPF
                if (usuario.CpfUser.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((usuario.CpfUser.Equals("111,111,111-11")) || (usuario.CpfUser.Equals("222,222,222-22")) || (usuario.CpfUser.Equals("333,333,333-33"))
                    || (usuario.CpfUser.Equals("444,444,444-44")) || (usuario.CpfUser.Equals("555,555,555-55")) || (usuario.CpfUser.Equals("666,666,666-66"))
                    || (usuario.CpfUser.Equals("777,777,777-77")) || (usuario.CpfUser.Equals("888,888,888-88")) || (usuario.CpfUser.Equals("999,999,999-9"))
                    || (usuario.CpfUser.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                } 
                #endregion


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            dados.inserirUsuario(usuario);

        }

        public List<Usuario> listarUsuarios()
        {

            try
            {
                List<Usuario> retorno = new List<Usuario>();
                retorno = dados.listarUsuarios();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public Usuario procurarUsuario(Usuario usuario)
        {

            try
            {
                Usuario retorno = dados.procurarUsuario(usuario);
                if (retorno.CodUser <= 0)
                {
                    throw new Exception("Login e/ou senha inválidos");
                }
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarUsuario(Usuario usuario, String novasenha)
        {
            try
            {

                #region Tratando o Nome do Usuário
                if (usuario.NomeUser.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o usuário.");
                }

                if (usuario.NomeUser.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o usuário deve conter de 4 até 100 caractéres.");
                }

                if (usuario.NomeUser.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o usuário deve conter de 4 até 100 caractéres.");
                }

                if ((usuario.NomeUser.Contains("@")) || (usuario.NomeUser.Contains("#")) || (usuario.NomeUser.Contains("$")) || (usuario.NomeUser.Contains("'"))
                    || (usuario.NomeUser.Contains("%")) || (usuario.NomeUser.Contains("&")) || (usuario.NomeUser.Contains("(")) || (usuario.NomeUser.Contains(")"))
                    || (usuario.NomeUser.Contains("-")) || (usuario.NomeUser.Contains("+")) || (usuario.NomeUser.Contains("=")) || (usuario.NomeUser.Contains("{"))
                    || (usuario.NomeUser.Contains("}")) || (usuario.NomeUser.Contains("[")) || (usuario.NomeUser.Contains("]")) || (usuario.NomeUser.Contains("?"))
                    || (usuario.NomeUser.Contains("!")) || (usuario.NomeUser.Contains("§")))
                {
                    throw new Exception("O nome para o usuário não deve conter caracteres especiais.");
                }

                #endregion

                #region Tratando o Login do Usuário
                if (usuario.LoginUser.Trim() == "")
                {
                    throw new Exception("É necessário digitar um login para o usuário.");
                }

                if (usuario.LoginUser.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O login para o usuário deve conter de 4 até 20 caractéres.");
                }

                if (usuario.LoginUser.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. O login para o usuário deve conter de 4 até 20 caractéres.");
                }

                if ((usuario.LoginUser.Contains("@")) || (usuario.LoginUser.Contains("#")) || (usuario.LoginUser.Contains("$")) || (usuario.LoginUser.Contains("'"))
                   || (usuario.LoginUser.Contains("%")) || (usuario.LoginUser.Contains("&")) || (usuario.LoginUser.Contains("(")) || (usuario.LoginUser.Contains(")"))
                   || (usuario.LoginUser.Contains("+")) || (usuario.LoginUser.Contains("=")) || (usuario.LoginUser.Contains("{"))
                   || (usuario.LoginUser.Contains("}")) || (usuario.LoginUser.Contains("[")) || (usuario.LoginUser.Contains("]")) || (usuario.LoginUser.Contains("?"))
                   || (usuario.LoginUser.Contains("!")) || (usuario.LoginUser.Contains("§")))
                {
                    throw new Exception("O login para o usuário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando a Nova Senha do Usuário
                if (novasenha.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o usuário.");
                }

                if (novasenha.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A seinha para o usuário deve conter de 4 até 20 caractéres.");
                }

                if (novasenha.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o usuário deve conter de 4 até 20 caractéres.");
                }

                if ((novasenha.Contains("@")) || (novasenha.Contains("#")) || (novasenha.Contains("$")) || (novasenha.Contains("'"))
                   || (novasenha.Contains("%")) || (novasenha.Contains("&")) || (novasenha.Contains("(")) || (novasenha.Contains(")"))
                   || (novasenha.Contains("+")) || (novasenha.Contains("=")) || (novasenha.Contains("{"))
                   || (novasenha.Contains("}")) || (novasenha.Contains("[")) || (novasenha.Contains("]")) || (novasenha.Contains("?"))
                   || (novasenha.Contains("!")) || (novasenha.Contains("§")))
                {
                    throw new Exception("A senha para o usuário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando CPF
                if (usuario.CpfUser.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((usuario.CpfUser.Equals("111,111,111-11")) || (usuario.CpfUser.Equals("222,222,222-22")) || (usuario.CpfUser.Equals("333,333,333-33"))
                    || (usuario.CpfUser.Equals("444,444,444-44")) || (usuario.CpfUser.Equals("555,555,555-55")) || (usuario.CpfUser.Equals("666,666,666-66"))
                    || (usuario.CpfUser.Equals("777,777,777-77")) || (usuario.CpfUser.Equals("888,888,888-88")) || (usuario.CpfUser.Equals("999,999,999-9"))
                    || (usuario.CpfUser.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                }
                #endregion

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            dados.alterarUsuario(usuario, novasenha);

        }

        public void excluirUsuario(Usuario usuario)
        {
            throw new NotImplementedException();
        }

        public List<Usuario> listarUsuarios(Usuario filtro)
        {
            throw new NotImplementedException();
        }
    }
}
