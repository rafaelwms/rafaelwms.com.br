﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
  public  class ControladorFuncionario : InterfaceFucionario
    {
        DadosFuncionario dados = new DadosFuncionario();

        public void inserirFuncionario(Funcionario func)
        {
            try
            {

                #region Tratando Nome
                if (func.NomeFunc.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o funcionário.");
                }

                if (func.NomeFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o funcionário deve conter de 4 até 100 caractéres.");
                }

                if (func.NomeFunc.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o funcionário deve conter de 4 até 100 caractéres.");
                }

                if ((func.NomeFunc.Contains("@")) || (func.NomeFunc.Contains("#")) || (func.NomeFunc.Contains("$")) || (func.NomeFunc.Contains("'"))
                    || (func.NomeFunc.Contains("%")) || (func.NomeFunc.Contains("&")) || (func.NomeFunc.Contains("(")) || (func.NomeFunc.Contains(")"))
                    || (func.NomeFunc.Contains("-")) || (func.NomeFunc.Contains("+")) || (func.NomeFunc.Contains("=")) || (func.NomeFunc.Contains("{"))
                    || (func.NomeFunc.Contains("}")) || (func.NomeFunc.Contains("[")) || (func.NomeFunc.Contains("]")) || (func.NomeFunc.Contains("?"))
                    || (func.NomeFunc.Contains("!")) || (func.NomeFunc.Contains("§")))
                {
                    throw new Exception("O nome para o funcionário não deve conter caracteres especiais.");
                } 
                #endregion

                #region Tratando Login
                if (func.LoginFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar um login para o funcionário.");
                }

                if (func.LoginFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O login para o funcionário deve conter de 4 até 20 caractéres.");
                }

                if (func.LoginFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. O login para o funcionário deve conter de 4 até 20 caractéres.");
                }

                if ((func.LoginFunc.Contains("@")) || (func.LoginFunc.Contains("#")) || (func.LoginFunc.Contains("$")) || (func.LoginFunc.Contains("'"))
                   || (func.LoginFunc.Contains("%")) || (func.LoginFunc.Contains("&")) || (func.LoginFunc.Contains("(")) || (func.LoginFunc.Contains(")"))
                   || (func.LoginFunc.Contains("+")) || (func.LoginFunc.Contains("=")) || (func.LoginFunc.Contains("{"))
                   || (func.LoginFunc.Contains("}")) || (func.LoginFunc.Contains("[")) || (func.LoginFunc.Contains("]")) || (func.LoginFunc.Contains("?"))
                   || (func.LoginFunc.Contains("!")) || (func.LoginFunc.Contains("§")))
                {
                    throw new Exception("O login para o funcionário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }

                List<Funcionario> teste = new List<Funcionario>();
                teste = dados.listarFuncionarios();

                foreach (Funcionario tst in teste)
                {
                    if (func.LoginFunc == tst.LoginFunc)
                    {
                        throw new Exception("Login indisponível");
                    }
                } 
                #endregion

                #region Tratando Senha
                if (func.SenhaFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o funcionário.");
                }

                if (func.SenhaFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A senha para o funcionário deve conter de 4 até 20 caractéres.");
                }

                if (func.SenhaFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o funcionário deve conter de 4 até 20 caractéres.");
                }

                if ((func.SenhaFunc.Contains("@")) || (func.SenhaFunc.Contains("#")) || (func.SenhaFunc.Contains("$")) || (func.SenhaFunc.Contains("'"))
                   || (func.SenhaFunc.Contains("%")) || (func.SenhaFunc.Contains("&")) || (func.SenhaFunc.Contains("(")) || (func.SenhaFunc.Contains(")"))
                   || (func.SenhaFunc.Contains("+")) || (func.SenhaFunc.Contains("=")) || (func.SenhaFunc.Contains("{"))
                   || (func.SenhaFunc.Contains("}")) || (func.SenhaFunc.Contains("[")) || (func.SenhaFunc.Contains("]")) || (func.SenhaFunc.Contains("?"))
                   || (func.SenhaFunc.Contains("!")) || (func.SenhaFunc.Contains("§")))
                {
                    throw new Exception("A senha para o funcionário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                } 
                #endregion

                #region Tratando CPF
                if (func.CpfFunc.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((func.CpfFunc.Equals("111,111,111-11")) || (func.CpfFunc.Equals("222,222,222-22")) || (func.CpfFunc.Equals("333,333,333-33"))
                    || (func.CpfFunc.Equals("444,444,444-44")) || (func.CpfFunc.Equals("555,555,555-55")) || (func.CpfFunc.Equals("666,666,666-66"))
                    || (func.CpfFunc.Equals("777,777,777-77")) || (func.CpfFunc.Equals("888,888,888-88")) || (func.CpfFunc.Equals("999,999,999-9"))
                    || (func.CpfFunc.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                } 
                #endregion

                #region Tartando Cargo
                if (func.CargoFunc == null)
                {
                    throw new Exception("Escolha um cargo");
                }

                if (func.CargoFunc.Equals(""))
                {
                    throw new Exception("Escolha um cargo");
                } 
                #endregion

                #region Tratando Salário
                //if (func.Salario < 678.00)
                //{
                //    throw new Exception("Valor do Salário menor que um salário mínimo.");
                //} 
                #endregion
                
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            dados.inserirFuncionario(func);
        }

        public List<Funcionario> listarFuncionarios()
        {
    
                List<Funcionario> funcs = new List<Funcionario>();
                funcs = dados.listarFuncionarios();
                return funcs;
            
        }

        public List<Funcionario> procurarFuncionario(string busca)
        {
            List<Funcionario> funcs = new List<Funcionario>();
            funcs = dados.procurarFuncionario(busca);
            return funcs;
        }

        public void alterarFucionario(Funcionario func)
        {
            try
            {
                #region Tratando Nome
                if (func.NomeFunc.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o funcionário.");
                }

                if (func.NomeFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o funcionário deve conter de 4 até 100 caractéres.");
                }

                if (func.NomeFunc.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o funcionário deve conter de 4 até 100 caractéres.");
                }

                if ((func.NomeFunc.Contains("@")) || (func.NomeFunc.Contains("#")) || (func.NomeFunc.Contains("$")) || (func.NomeFunc.Contains("'"))
                    || (func.NomeFunc.Contains("%")) || (func.NomeFunc.Contains("&")) || (func.NomeFunc.Contains("(")) || (func.NomeFunc.Contains(")"))
                    || (func.NomeFunc.Contains("-")) || (func.NomeFunc.Contains("+")) || (func.NomeFunc.Contains("=")) || (func.NomeFunc.Contains("{"))
                    || (func.NomeFunc.Contains("}")) || (func.NomeFunc.Contains("[")) || (func.NomeFunc.Contains("]")) || (func.NomeFunc.Contains("?"))
                    || (func.NomeFunc.Contains("!")) || (func.NomeFunc.Contains("§")))
                {
                    throw new Exception("O nome para o funcionário não deve conter caracteres especiais.");
                }
                #endregion
 
                #region Tratando Senha
                if (func.SenhaFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o funcionário.");
                }

                if (func.SenhaFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A senha para o funcionário deve conter de 4 até 20 caractéres.");
                }

                if (func.SenhaFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o funcionário deve conter de 4 até 20 caractéres.");
                }

                if ((func.SenhaFunc.Contains("@")) || (func.SenhaFunc.Contains("#")) || (func.SenhaFunc.Contains("$")) || (func.SenhaFunc.Contains("'"))
                   || (func.SenhaFunc.Contains("%")) || (func.SenhaFunc.Contains("&")) || (func.SenhaFunc.Contains("(")) || (func.SenhaFunc.Contains(")"))
                   || (func.SenhaFunc.Contains("+")) || (func.SenhaFunc.Contains("=")) || (func.SenhaFunc.Contains("{"))
                   || (func.SenhaFunc.Contains("}")) || (func.SenhaFunc.Contains("[")) || (func.SenhaFunc.Contains("]")) || (func.SenhaFunc.Contains("?"))
                   || (func.SenhaFunc.Contains("!")) || (func.SenhaFunc.Contains("§")))
                {
                    throw new Exception("A senha para o funcionário não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando CPF
                if (func.CpfFunc.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((func.CpfFunc.Equals("111,111,111-11")) || (func.CpfFunc.Equals("222,222,222-22")) || (func.CpfFunc.Equals("333,333,333-33"))
                    || (func.CpfFunc.Equals("444,444,444-44")) || (func.CpfFunc.Equals("555,555,555-55")) || (func.CpfFunc.Equals("666,666,666-66"))
                    || (func.CpfFunc.Equals("777,777,777-77")) || (func.CpfFunc.Equals("888,888,888-88")) || (func.CpfFunc.Equals("999,999,999-9"))
                    || (func.CpfFunc.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                }
                #endregion

                #region Tartando Cargo
                if (func.CargoFunc == null)
                {
                    throw new Exception("Escolha um cargo");
                }

                if (func.CargoFunc.Equals(""))
                {
                    throw new Exception("Escolha um cargo");
                }
                #endregion

                #region Tratando Salário
                //if (func.Salario < 678.00)
                //{
                //    throw new Exception("Valor do Salário menor que um salário mínimo.");
                //}
                #endregion

            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            dados.alterarFucionario(func);
        }

        public void demitirFuncionario(Funcionario func)
        {
            dados.demitirFuncionario(func);
        }
    }
}
