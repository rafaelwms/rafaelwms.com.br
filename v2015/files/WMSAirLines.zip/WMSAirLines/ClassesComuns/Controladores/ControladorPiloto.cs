﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{

    public class ControladorPiloto : InterfacePiloto
    {


        DadosPiloto dados = new DadosPiloto();

        public void inserirPiloto(Piloto piloto)
        {

            try
            {
                if (piloto.Breve == null)
                {
                    throw new Exception("Brevê nulo.");
                }
                if (piloto.Breve.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar o Brevê para registro do piloto.");
                }
                if (piloto.Breve.Trim().Length > 20)
                {
                    throw new Exception("O Brevê deve conter até 20 caracteres.");
                }
                if (piloto.HorasVoo < 0)
                {
                    throw new Exception("As horas de voo deve constituir valores positivos.");
                }
                #region Tratando Nome
                if (piloto.NomeFunc.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o piloto.");
                }

                if (piloto.NomeFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o piloto deve conter de 4 até 100 caractéres.");
                }

                if (piloto.NomeFunc.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o piloto deve conter de 4 até 100 caractéres.");
                }

                if ((piloto.NomeFunc.Contains("@")) || (piloto.NomeFunc.Contains("#")) || (piloto.NomeFunc.Contains("$")) || (piloto.NomeFunc.Contains("'"))
                    || (piloto.NomeFunc.Contains("%")) || (piloto.NomeFunc.Contains("&")) || (piloto.NomeFunc.Contains("(")) || (piloto.NomeFunc.Contains(")"))
                    || (piloto.NomeFunc.Contains("-")) || (piloto.NomeFunc.Contains("+")) || (piloto.NomeFunc.Contains("=")) || (piloto.NomeFunc.Contains("{"))
                    || (piloto.NomeFunc.Contains("}")) || (piloto.NomeFunc.Contains("[")) || (piloto.NomeFunc.Contains("]")) || (piloto.NomeFunc.Contains("?"))
                    || (piloto.NomeFunc.Contains("!")) || (piloto.NomeFunc.Contains("§")))
                {
                    throw new Exception("O nome para o piloto não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Login
                if (piloto.LoginFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar um login para o piloto.");
                }

                if (piloto.LoginFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O login para o piloto deve conter de 4 até 20 caractéres.");
                }

                if (piloto.LoginFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. O login para o piloto deve conter de 4 até 20 caractéres.");
                }

                if ((piloto.LoginFunc.Contains("@")) || (piloto.LoginFunc.Contains("#")) || (piloto.LoginFunc.Contains("$")) || (piloto.LoginFunc.Contains("'"))
                   || (piloto.LoginFunc.Contains("%")) || (piloto.LoginFunc.Contains("&")) || (piloto.LoginFunc.Contains("(")) || (piloto.LoginFunc.Contains(")"))
                   || (piloto.LoginFunc.Contains("+")) || (piloto.LoginFunc.Contains("=")) || (piloto.LoginFunc.Contains("{"))
                   || (piloto.LoginFunc.Contains("}")) || (piloto.LoginFunc.Contains("[")) || (piloto.LoginFunc.Contains("]")) || (piloto.LoginFunc.Contains("?"))
                   || (piloto.LoginFunc.Contains("!")) || (piloto.LoginFunc.Contains("§")))
                {
                    throw new Exception("O login para o piloto não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }

                List<Piloto> teste = new List<Piloto>();
                teste = dados.listarPilotos();

                foreach (Piloto tst in teste)
                {
                    if (piloto.LoginFunc == tst.LoginFunc)
                    {
                        throw new Exception("Login indisponível");
                    }
                }
                #endregion

                #region Tratando Senha
                if (piloto.SenhaFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o piloto.");
                }

                if (piloto.SenhaFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A senha para o piloto deve conter de 4 até 20 caractéres.");
                }

                if (piloto.SenhaFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o piloto deve conter de 4 até 20 caractéres.");
                }

                if ((piloto.SenhaFunc.Contains("@")) || (piloto.SenhaFunc.Contains("#")) || (piloto.SenhaFunc.Contains("$")) || (piloto.SenhaFunc.Contains("'"))
                   || (piloto.SenhaFunc.Contains("%")) || (piloto.SenhaFunc.Contains("&")) || (piloto.SenhaFunc.Contains("(")) || (piloto.SenhaFunc.Contains(")"))
                   || (piloto.SenhaFunc.Contains("+")) || (piloto.SenhaFunc.Contains("=")) || (piloto.SenhaFunc.Contains("{"))
                   || (piloto.SenhaFunc.Contains("}")) || (piloto.SenhaFunc.Contains("[")) || (piloto.SenhaFunc.Contains("]")) || (piloto.SenhaFunc.Contains("?"))
                   || (piloto.SenhaFunc.Contains("!")) || (piloto.SenhaFunc.Contains("§")))
                {
                    throw new Exception("A senha para o piloto não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando CPF
                if (piloto.CpfFunc.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((piloto.CpfFunc.Equals("111,111,111-11")) || (piloto.CpfFunc.Equals("222,222,222-22")) || (piloto.CpfFunc.Equals("333,333,333-33"))
                    || (piloto.CpfFunc.Equals("444,444,444-44")) || (piloto.CpfFunc.Equals("555,555,555-55")) || (piloto.CpfFunc.Equals("666,666,666-66"))
                    || (piloto.CpfFunc.Equals("777,777,777-77")) || (piloto.CpfFunc.Equals("888,888,888-88")) || (piloto.CpfFunc.Equals("999,999,999-9"))
                    || (piloto.CpfFunc.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                }
                #endregion



            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            dados.inserirPiloto(piloto);

        }

        public List<Piloto> listarPilotos()
        {

            try
            {
                List<Piloto> lista = new List<Piloto>();
                lista = dados.listarPilotos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Piloto> procurarPiloto(String busca)
        {
            try
            {
                if ((busca == null) || (busca.Trim().Equals("")))
                {
                    throw new Exception("É necessário digitar algo no campo busca.");
                }
                List<Piloto> lista = new List<Piloto>();
                lista = dados.procurarPiloto(busca);
                return lista;

            }
            catch (Exception ex)
            {
              throw new Exception(ex.Message);
            }
        }

        public void alterarPiloto(Piloto piloto)
        {

            try
            {
                if (piloto.Breve == null)
                {
                    throw new Exception("Brevê nulo.");
                }
                if (piloto.Breve.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar o Brevê para registro do piloto.");
                }
                if (piloto.Breve.Trim().Length > 20)
                {
                    throw new Exception("O Brevê deve conter até 20 caracteres.");
                }
                if (piloto.HorasVoo < 0)
                {
                    throw new Exception("As horas de voo deve constituir valores positivos.");
                }

                #region Tratando Nome
                if (piloto.NomeFunc.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o piloto.");
                }

                if (piloto.NomeFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. O nome para o piloto deve conter de 4 até 100 caractéres.");
                }

                if (piloto.NomeFunc.Trim().Length > 100)
                {
                    throw new Exception("Acima de 100 caracteres. O nome para o piloto deve conter de 4 até 100 caractéres.");
                }

                if ((piloto.NomeFunc.Contains("@")) || (piloto.NomeFunc.Contains("#")) || (piloto.NomeFunc.Contains("$")) || (piloto.NomeFunc.Contains("'"))
                    || (piloto.NomeFunc.Contains("%")) || (piloto.NomeFunc.Contains("&")) || (piloto.NomeFunc.Contains("(")) || (piloto.NomeFunc.Contains(")"))
                    || (piloto.NomeFunc.Contains("-")) || (piloto.NomeFunc.Contains("+")) || (piloto.NomeFunc.Contains("=")) || (piloto.NomeFunc.Contains("{"))
                    || (piloto.NomeFunc.Contains("}")) || (piloto.NomeFunc.Contains("[")) || (piloto.NomeFunc.Contains("]")) || (piloto.NomeFunc.Contains("?"))
                    || (piloto.NomeFunc.Contains("!")) || (piloto.NomeFunc.Contains("§")))
                {
                    throw new Exception("O nome para o piloto não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Senha
                if (piloto.SenhaFunc.Trim() == "")
                {
                    throw new Exception("É necessário digitar uma senha para o piloto.");
                }

                if (piloto.SenhaFunc.Trim().Length < 4)
                {
                    throw new Exception("Abaixo de 4 caracteres. A senha para o piloto deve conter de 4 até 20 caractéres.");
                }

                if (piloto.SenhaFunc.Trim().Length > 20)
                {
                    throw new Exception("Acima de 20 caracteres. A senha para o piloto deve conter de 4 até 20 caractéres.");
                }

                if ((piloto.SenhaFunc.Contains("@")) || (piloto.SenhaFunc.Contains("#")) || (piloto.SenhaFunc.Contains("$")) || (piloto.SenhaFunc.Contains("'"))
                   || (piloto.SenhaFunc.Contains("%")) || (piloto.SenhaFunc.Contains("&")) || (piloto.SenhaFunc.Contains("(")) || (piloto.SenhaFunc.Contains(")"))
                   || (piloto.SenhaFunc.Contains("+")) || (piloto.SenhaFunc.Contains("=")) || (piloto.SenhaFunc.Contains("{"))
                   || (piloto.SenhaFunc.Contains("}")) || (piloto.SenhaFunc.Contains("[")) || (piloto.SenhaFunc.Contains("]")) || (piloto.SenhaFunc.Contains("?"))
                   || (piloto.SenhaFunc.Contains("!")) || (piloto.SenhaFunc.Contains("§")))
                {
                    throw new Exception("A senha para o piloto não deve conter caracteres especiais. Exceto \".\", \"-\" e \"_\".");
                }
                #endregion

                #region Tratando CPF
                if (piloto.CpfFunc.Equals("   ,   ,   -"))
                {
                    throw new Exception("É necessário digitar algum valor no campo CPF.");
                }

                if ((piloto.CpfFunc.Equals("111,111,111-11")) || (piloto.CpfFunc.Equals("222,222,222-22")) || (piloto.CpfFunc.Equals("333,333,333-33"))
                    || (piloto.CpfFunc.Equals("444,444,444-44")) || (piloto.CpfFunc.Equals("555,555,555-55")) || (piloto.CpfFunc.Equals("666,666,666-66"))
                    || (piloto.CpfFunc.Equals("777,777,777-77")) || (piloto.CpfFunc.Equals("888,888,888-88")) || (piloto.CpfFunc.Equals("999,999,999-9"))
                    || (piloto.CpfFunc.Equals("000,000,000-00")))
                {
                    throw new Exception("CPF inválido.");
                }
                #endregion

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            dados.alterarPiloto(piloto);

        }

        public void demitirPiloto(Piloto piloto)
        {
            try
            {
                dados.demitirPiloto(piloto);
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}