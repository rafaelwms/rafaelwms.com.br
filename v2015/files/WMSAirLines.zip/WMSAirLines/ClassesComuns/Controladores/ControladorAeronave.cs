﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
    public class ControladorAeronave : InterfaceAeronave
    {

        DadosAeronave dados = new DadosAeronave();

        public void inserirAeronave(Aeronave nave)
        {
            try
            {

                #region Tratando ID
                if (nave.IdAeronave == null)
                {
                    throw new Exception("Id da aeronave nulo.");
                }
                if (nave.IdAeronave.Trim().Equals(""))
                {
                    throw new Exception("É necessário preencher o ID da Aeronave.");
                }
                if (nave.IdAeronave.Trim().Length > 10)
                {
                    throw new Exception("O ID da Aeronave deve conter no máximo 10 caracteres.");
                }
                if ((nave.IdAeronave.Contains("@")) || (nave.IdAeronave.Contains("#")) || (nave.IdAeronave.Contains("$")) || (nave.IdAeronave.Contains("'"))
                    || (nave.IdAeronave.Contains("%")) || (nave.IdAeronave.Contains("&")) || (nave.IdAeronave.Contains("(")) || (nave.IdAeronave.Contains(")"))
                    || (nave.IdAeronave.Contains("+")) || (nave.IdAeronave.Contains("=")) || (nave.IdAeronave.Contains("{"))
                    || (nave.IdAeronave.Contains("}")) || (nave.IdAeronave.Contains("[")) || (nave.IdAeronave.Contains("]")) || (nave.IdAeronave.Contains("?"))
                    || (nave.IdAeronave.Contains("!")) || (nave.IdAeronave.Contains("§")))
                {
                    throw new Exception("O ID da aeronave não deve conter caracteres especiais.");
                } 
                #endregion

                #region Tratando Apelido
                if (nave.ApelidoAeronave == null)
                {
                    throw new Exception("Apelido da aeronave nulo.");
                }
                if (nave.ApelidoAeronave.Trim().Equals(""))
                {
                    throw new Exception("É necessário preencher o apelido da Aeronave.");
                }
                if (nave.ApelidoAeronave.Trim().Length > 30)
                {
                    throw new Exception("O apelido da Aeronave deve conter no máximo 30 caracteres.");
                }
                if ((nave.ApelidoAeronave.Contains("@")) || (nave.ApelidoAeronave.Contains("#")) || (nave.ApelidoAeronave.Contains("$")) || (nave.ApelidoAeronave.Contains("'"))
                    || (nave.ApelidoAeronave.Contains("%")) || (nave.ApelidoAeronave.Contains("&")) || (nave.ApelidoAeronave.Contains("(")) || (nave.ApelidoAeronave.Contains(")"))
                    || (nave.ApelidoAeronave.Contains("+")) || (nave.ApelidoAeronave.Contains("=")) || (nave.ApelidoAeronave.Contains("{"))
                    || (nave.ApelidoAeronave.Contains("}")) || (nave.ApelidoAeronave.Contains("[")) || (nave.ApelidoAeronave.Contains("]")) || (nave.ApelidoAeronave.Contains("?"))
                    || (nave.ApelidoAeronave.Contains("!")) || (nave.ApelidoAeronave.Contains("§")))
                {
                    throw new Exception("O apelido da aeronave não deve conter caracteres especiais.");
                } 
                #endregion

                #region Tratando Modelo
                if (nave.ModeloAeronave == null)
                {
                    throw new Exception("Modelo da aeronave nulo.");
                }
                if (nave.ModeloAeronave.Trim().Equals(""))
                {
                    throw new Exception("É necessário preencher o modelo da Aeronave.");
                }
                if (nave.ModeloAeronave.Trim().Length > 30)
                {
                    throw new Exception("O modelo da Aeronave deve conter no máximo 30 caracteres.");
                }
                if ((nave.ModeloAeronave.Contains("@")) || (nave.ModeloAeronave.Contains("#")) || (nave.ModeloAeronave.Contains("$")) || (nave.ModeloAeronave.Contains("'"))
                    || (nave.ModeloAeronave.Contains("%")) || (nave.ModeloAeronave.Contains("&")) || (nave.ModeloAeronave.Contains("(")) || (nave.ModeloAeronave.Contains(")"))
                    || (nave.ModeloAeronave.Contains("+")) || (nave.ModeloAeronave.Contains("=")) || (nave.ModeloAeronave.Contains("{"))
                    || (nave.ModeloAeronave.Contains("}")) || (nave.ModeloAeronave.Contains("[")) || (nave.ModeloAeronave.Contains("]")) || (nave.ModeloAeronave.Contains("?"))
                    || (nave.ModeloAeronave.Contains("!")) || (nave.ModeloAeronave.Contains("§")))
                {
                    throw new Exception("O modelo da aeronave não deve conter caracteres especiais.");
                } 
                #endregion

                #region Tratando Poltronas
                if (nave.QtdPoltronas <= 10)
                {
                    throw new Exception("Quantidade de Poltronas inferior a 10.");
                }

                if (nave.QtdPoltronas > 853)
                {
                    throw new Exception("Quantidade de Poltronas superior a 853.");
                } 
                #endregion

                if (nave.Milhas < 0) 
                {
                    throw new Exception("Valor de milhas inferior a zero.");
                }
                dados.inserirAeronave(nave);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeronave> listarAeronaves()
        {
            try
            {
                List<Aeronave> lista = new List<Aeronave>();
                lista = dados.listarAeronaves();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeronave> procurarAeronave(string busca)
        {

            try
            {
                List<Aeronave> lista = new List<Aeronave>();
                lista = dados.procurarAeronave(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void alterarAeronave(Aeronave nave)
        {

            try
            {

                #region Tratando ID
                if (nave.IdAeronave == null)
                {
                    throw new Exception("Id da aeronave nulo.");
                }
                if (nave.IdAeronave.Trim().Equals(""))
                {
                    throw new Exception("É necessário preencher o ID da Aeronave.");
                }
                if (nave.IdAeronave.Trim().Length > 10)
                {
                    throw new Exception("O ID da Aeronave deve conter no máximo 10 caracteres.");
                }
                if ((nave.IdAeronave.Contains("@")) || (nave.IdAeronave.Contains("#")) || (nave.IdAeronave.Contains("$")) || (nave.IdAeronave.Contains("'"))
                    || (nave.IdAeronave.Contains("%")) || (nave.IdAeronave.Contains("&")) || (nave.IdAeronave.Contains("(")) || (nave.IdAeronave.Contains(")"))
                    || (nave.IdAeronave.Contains("+")) || (nave.IdAeronave.Contains("=")) || (nave.IdAeronave.Contains("{"))
                    || (nave.IdAeronave.Contains("}")) || (nave.IdAeronave.Contains("[")) || (nave.IdAeronave.Contains("]")) || (nave.IdAeronave.Contains("?"))
                    || (nave.IdAeronave.Contains("!")) || (nave.IdAeronave.Contains("§")))
                {
                    throw new Exception("O ID da aeronave não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Apelido
                if (nave.ApelidoAeronave == null)
                {
                    throw new Exception("Apelido da aeronave nulo.");
                }
                if (nave.ApelidoAeronave.Trim().Equals(""))
                {
                    throw new Exception("É necessário preencher o apelido da Aeronave.");
                }
                if (nave.ApelidoAeronave.Trim().Length > 30)
                {
                    throw new Exception("O apelido da Aeronave deve conter no máximo 30 caracteres.");
                }
                if ((nave.ApelidoAeronave.Contains("@")) || (nave.ApelidoAeronave.Contains("#")) || (nave.ApelidoAeronave.Contains("$")) || (nave.ApelidoAeronave.Contains("'"))
                    || (nave.ApelidoAeronave.Contains("%")) || (nave.ApelidoAeronave.Contains("&")) || (nave.ApelidoAeronave.Contains("(")) || (nave.ApelidoAeronave.Contains(")"))
                    || (nave.ApelidoAeronave.Contains("+")) || (nave.ApelidoAeronave.Contains("=")) || (nave.ApelidoAeronave.Contains("{"))
                    || (nave.ApelidoAeronave.Contains("}")) || (nave.ApelidoAeronave.Contains("[")) || (nave.ApelidoAeronave.Contains("]")) || (nave.ApelidoAeronave.Contains("?"))
                    || (nave.ApelidoAeronave.Contains("!")) || (nave.ApelidoAeronave.Contains("§")))
                {
                    throw new Exception("O apelido da aeronave não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Modelo
                if (nave.ModeloAeronave == null)
                {
                    throw new Exception("Modelo da aeronave nulo.");
                }
                if (nave.ModeloAeronave.Trim().Equals(""))
                {
                    throw new Exception("É necessário preencher o modelo da Aeronave.");
                }
                if (nave.ModeloAeronave.Trim().Length > 30)
                {
                    throw new Exception("O modelo da Aeronave deve conter no máximo 30 caracteres.");
                }
                if ((nave.ModeloAeronave.Contains("@")) || (nave.ModeloAeronave.Contains("#")) || (nave.ModeloAeronave.Contains("$")) || (nave.ModeloAeronave.Contains("'"))
                    || (nave.ModeloAeronave.Contains("%")) || (nave.ModeloAeronave.Contains("&")) || (nave.ModeloAeronave.Contains("(")) || (nave.ModeloAeronave.Contains(")"))
                    || (nave.ModeloAeronave.Contains("+")) || (nave.ModeloAeronave.Contains("=")) || (nave.ModeloAeronave.Contains("{"))
                    || (nave.ModeloAeronave.Contains("}")) || (nave.ModeloAeronave.Contains("[")) || (nave.ModeloAeronave.Contains("]")) || (nave.ModeloAeronave.Contains("?"))
                    || (nave.ModeloAeronave.Contains("!")) || (nave.ModeloAeronave.Contains("§")))
                {
                    throw new Exception("O modelo da aeronave não deve conter caracteres especiais.");
                }
                #endregion

                #region Tratando Poltronas
                if (nave.QtdPoltronas <= 10)
                {
                    throw new Exception("Quantidade de Poltronas inferior a 10.");
                }

                if (nave.QtdPoltronas > 853)
                {
                    throw new Exception("Quantidade de Poltronas superior a 853.");
                }
                #endregion

                if (nave.Milhas < 0)
                {
                    throw new Exception("Valor de milhas inferior a zero.");
                }
                dados.alterarAeronave(nave);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void excluirAeronave(Aeronave nave)
        {
            try
            {
                if (nave.CodAeronave == null)
                {
                    throw new Exception("É necessário selecionar uma aeronave.");
                }
                if (nave.CodAeronave < 1)
                {
                    throw new Exception("É necessário selecionar uma aeronave.");
                }
                if (dados.procurarAeronaveVoo(nave.CodAeronave).Count != 0) 
                {
                    throw new Exception("Não é possível Excluir a aeronave, pois está associada a um Voo.");
                }
                dados.excluirAeronave(nave);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
