﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Dados;

namespace ClassesComuns.Controladores
{
   public class ControladorRota : InterfaceRota
    {

        DadosRota dados = new DadosRota();

        public void inserirRota(Rota rota)
        {

            try
            {

                if (rota.NomeRota == null)
                {
                    throw new Exception("Nome da rota nulo.");
                }
                if (rota.NomeRota.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para a rota.");
                }
                if (rota.NomeRota.Trim().Length > 30)
                {
                    throw new Exception("O nome da rota deve conter no maximo 30 caracteres.");
                }
                if (rota.MilhasRota < 0)
                {
                    throw new Exception("Milhas da rota em valor negativo.");
                }
                if (rota.MinRota < 0)
                {
                    throw new Exception("Minutos da rota em valor negativo.");
                }

                dados.inserirRota(rota);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Rota> listarRotas()
        {
            try
            {
                List<Rota> lista = new List<Rota>();
                lista = dados.listarRotas();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Rota> procurarRota(string busca)
        {
            try
            {
                if ((busca == null) || (busca.Trim().Equals("")))
                {

                    throw new Exception("Digite algo para ser procurado");
                }


                List<Rota> lista = new List<Rota>();
                lista = dados.procurarRota(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarRota(Rota rota)
        {

            try
            {

                if (rota.NomeRota == null)
                {
                    throw new Exception("Nome da rota nulo.");
                }
                if (rota.NomeRota.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para a rota.");
                }
                if (rota.NomeRota.Trim().Length > 30)
                {
                    throw new Exception("O nome da rota deve conter no maximo 30 caracteres.");
                }
                if (rota.MilhasRota < 0)
                {
                    throw new Exception("Milhas da rota em valor negativo.");
                }
                if (rota.MinRota < 0)
                {
                    throw new Exception("Minutos da rota em valor negativo.");
                }

                dados.excluirTodosTrechosdaRota(rota);

                dados.alterarRota(rota);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void excluirRota(Rota rota)
        {
            try
            {

                if ((rota.CodRota == null) || (rota.CodRota < 0))
                {
                    throw new Exception("Escolha uma rota pra excluir.");
                }
                if (dados.procurarRotaVoo(rota).Count != 0) 
                {
                    throw new Exception("Não é possível excluir a rota, pois, está associada a um voo.");
                }


                dados.excluirRota(rota);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void inserirTrechoDaRota(Rota rota, int numTrecho, Trecho trecho)
        {
            try
            {
                if ((trecho.CodTrecho == null) || (trecho.CodTrecho < 0))
                {
                    throw new Exception("É necessário escolher um trecho para inserção.");
                }
                dados.inserirTrechoDaRota(rota, numTrecho, trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void removerTrechoDaRota(Rota rota, Trecho trecho)
        {
            try
            {
                if ((trecho.CodTrecho == null) || (trecho.CodTrecho < 0))
                {
                    throw new Exception("É necessário escolher um trecho para remoção.");
                }
                dados.removerTrechoDaRota(rota, trecho);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Trecho> listarTrechosDaRota(Rota rota)
        {
            try
            {
                List<Trecho> lista = new List<Trecho>();
                lista = dados.listarTrechosDaRota(rota);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public int localizarRotaInserida()
        {
            try
            {
                return dados.localizarRotaInserida();
            }
            catch (Exception ex)
            {
                
                throw new Exception(ex.Message);
            }
        }
    }
}
