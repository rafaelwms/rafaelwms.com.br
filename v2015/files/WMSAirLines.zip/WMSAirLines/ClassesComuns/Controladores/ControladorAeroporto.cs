﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Dados;
using ClassesComuns.Interfaces;

namespace ClassesComuns.Controladores
{
    public class ControladorAeroporto : InterfaceAeroporto
    {

        DadosAeroporto dados = new DadosAeroporto();

        public void inserirAeroporto(Aeroporto porto)
        {
            try
            {
                #region Tratando Nome
                if (porto.NomeAeroporto == null)
                {
                    throw new Exception("Nome do aeroporto nulo.");
                }
                if (porto.NomeAeroporto.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o aeroporto.");
                }
                if (porto.NomeAeroporto.Trim().Length > 30)
                {
                    throw new Exception("O nome do aeroporto deve conter no máximo 30 caracteres.");
                }
                if ((porto.NomeAeroporto.Contains("@")) || (porto.NomeAeroporto.Contains("#")) || (porto.NomeAeroporto.Contains("$")) || (porto.NomeAeroporto.Contains("'"))
                    || (porto.NomeAeroporto.Contains("%")) || (porto.NomeAeroporto.Contains("&")) || (porto.NomeAeroporto.Contains("(")) || (porto.NomeAeroporto.Contains(")"))
                    || (porto.NomeAeroporto.Contains("+")) || (porto.NomeAeroporto.Contains("=")) || (porto.NomeAeroporto.Contains("{"))
                    || (porto.NomeAeroporto.Contains("}")) || (porto.NomeAeroporto.Contains("[")) || (porto.NomeAeroporto.Contains("]")) || (porto.NomeAeroporto.Contains("?"))
                    || (porto.NomeAeroporto.Contains("!")) || (porto.NomeAeroporto.Contains("§")))
                {
                    throw new Exception("O nome do aeroporto não deve conter caracteres especiais.");
                }  
                #endregion

                #region Tratando Cidade
                if (porto.CidadeAeroporto == null)
                {
                    throw new Exception("Cidade do aeroporto nulo.");
                }
                if (porto.CidadeAeroporto.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome da cidade para o aeroporto.");
                }
                if (porto.CidadeAeroporto.Trim().Length > 30)
                {
                    throw new Exception("O nome da cidade do aeroporto deve conter no máximo 30 caracteres.");
                }
                if ((porto.CidadeAeroporto.Contains("@")) || (porto.CidadeAeroporto.Contains("#")) || (porto.CidadeAeroporto.Contains("$")) || (porto.CidadeAeroporto.Contains("'"))
                    || (porto.CidadeAeroporto.Contains("%")) || (porto.CidadeAeroporto.Contains("&")) || (porto.CidadeAeroporto.Contains("(")) || (porto.CidadeAeroporto.Contains(")"))
                    || (porto.CidadeAeroporto.Contains("+")) || (porto.CidadeAeroporto.Contains("=")) || (porto.CidadeAeroporto.Contains("{"))
                    || (porto.CidadeAeroporto.Contains("}")) || (porto.CidadeAeroporto.Contains("[")) || (porto.CidadeAeroporto.Contains("]")) || (porto.CidadeAeroporto.Contains("?"))
                    || (porto.CidadeAeroporto.Contains("!")) || (porto.CidadeAeroporto.Contains("§")))
                {
                    throw new Exception("O nome da cidade do aeroporto não deve conter caracteres especiais.");
                }   
                #endregion

                #region Tratando Sigla
                if (porto.SiglaAeroporto == null)
                {
                    throw new Exception("Sigla do aeroporto nulo.");
                }
                if (porto.SiglaAeroporto.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar uma sigla para o aeroporto.");
                }
                if (porto.SiglaAeroporto.Trim().Length != 3)
                {
                    throw new Exception("A sigla do aeroporto deve conter 3 caracteres.");
                }
                if ((porto.SiglaAeroporto.Contains("@")) || (porto.SiglaAeroporto.Contains("#")) || (porto.SiglaAeroporto.Contains("$")) || (porto.SiglaAeroporto.Contains("'"))
                    || (porto.SiglaAeroporto.Contains("%")) || (porto.SiglaAeroporto.Contains("&")) || (porto.SiglaAeroporto.Contains("(")) || (porto.SiglaAeroporto.Contains(")"))
                    || (porto.SiglaAeroporto.Contains("+")) || (porto.SiglaAeroporto.Contains("=")) || (porto.SiglaAeroporto.Contains("{"))
                    || (porto.SiglaAeroporto.Contains("}")) || (porto.SiglaAeroporto.Contains("[")) || (porto.SiglaAeroporto.Contains("]")) || (porto.SiglaAeroporto.Contains("?"))
                    || (porto.SiglaAeroporto.Contains("!")) || (porto.SiglaAeroporto.Contains("§")) || (porto.SiglaAeroporto.Contains("1")) || (porto.SiglaAeroporto.Contains("2"))
                    || (porto.SiglaAeroporto.Contains("3")) || (porto.SiglaAeroporto.Contains("4")) || (porto.SiglaAeroporto.Contains("5")) || (porto.SiglaAeroporto.Contains("6"))
                    || (porto.SiglaAeroporto.Contains("7")) || (porto.SiglaAeroporto.Contains("8")) || (porto.SiglaAeroporto.Contains("9")) || (porto.SiglaAeroporto.Contains("0")))
                {
                    throw new Exception("A sigla do aeroporto não deve conter números ou caracteres especiais.");
                }   
                #endregion

                dados.inserirAeroporto(porto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeroporto> listarAeroportos()
        {
            try
            {
                List<Aeroporto> lista = new List<Aeroporto>();
                lista = dados.listarAeroportos();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeroporto> procurarAeroporto(string busca)
        {
            try
            {
                if (busca == null)                 
                {
                    throw new Exception("Busca nula.");
                }

                if (busca.Trim().Equals(""))
                {
                    throw new Exception("Digite algo para a busca.");
                }

                List<Aeroporto> lista = new List<Aeroporto>();
                lista = dados.procurarAeroporto(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void alterarAeroporto(Aeroporto porto)
        {
            
            try
            {
                #region Tratando Nome
                if (porto.NomeAeroporto == null)
                {
                    throw new Exception("Nome do aeroporto nulo.");
                }
                if (porto.NomeAeroporto.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome para o aeroporto.");
                }
                if (porto.NomeAeroporto.Trim().Length > 30)
                {
                    throw new Exception("O nome do aeroporto deve conter no máximo 30 caracteres.");
                }
                if ((porto.NomeAeroporto.Contains("@")) || (porto.NomeAeroporto.Contains("#")) || (porto.NomeAeroporto.Contains("$")) || (porto.NomeAeroporto.Contains("'"))
                    || (porto.NomeAeroporto.Contains("%")) || (porto.NomeAeroporto.Contains("&")) || (porto.NomeAeroporto.Contains("(")) || (porto.NomeAeroporto.Contains(")"))
                    || (porto.NomeAeroporto.Contains("+")) || (porto.NomeAeroporto.Contains("=")) || (porto.NomeAeroporto.Contains("{"))
                    || (porto.NomeAeroporto.Contains("}")) || (porto.NomeAeroporto.Contains("[")) || (porto.NomeAeroporto.Contains("]")) || (porto.NomeAeroporto.Contains("?"))
                    || (porto.NomeAeroporto.Contains("!")) || (porto.NomeAeroporto.Contains("§")))
                {
                    throw new Exception("O nome do aeroporto não deve conter caracteres especiais.");
                }  
                #endregion

                #region Tratando Cidade
                if (porto.CidadeAeroporto == null)
                {
                    throw new Exception("Cidade do aeroporto nulo.");
                }
                if (porto.CidadeAeroporto.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar um nome da cidade para o aeroporto.");
                }
                if (porto.CidadeAeroporto.Trim().Length > 30)
                {
                    throw new Exception("O nome da cidade do aeroporto deve conter no máximo 30 caracteres.");
                }
                if ((porto.CidadeAeroporto.Contains("@")) || (porto.CidadeAeroporto.Contains("#")) || (porto.CidadeAeroporto.Contains("$")) || (porto.CidadeAeroporto.Contains("'"))
                    || (porto.CidadeAeroporto.Contains("%")) || (porto.CidadeAeroporto.Contains("&")) || (porto.CidadeAeroporto.Contains("(")) || (porto.CidadeAeroporto.Contains(")"))
                    || (porto.CidadeAeroporto.Contains("+")) || (porto.CidadeAeroporto.Contains("=")) || (porto.CidadeAeroporto.Contains("{"))
                    || (porto.CidadeAeroporto.Contains("}")) || (porto.CidadeAeroporto.Contains("[")) || (porto.CidadeAeroporto.Contains("]")) || (porto.CidadeAeroporto.Contains("?"))
                    || (porto.CidadeAeroporto.Contains("!")) || (porto.CidadeAeroporto.Contains("§")))
                {
                    throw new Exception("O nome da cidade do aeroporto não deve conter caracteres especiais.");
                }   
                #endregion

                #region Tratando Sigla
                if (porto.SiglaAeroporto == null)
                {
                    throw new Exception("Sigla do aeroporto nulo.");
                }
                if (porto.SiglaAeroporto.Trim().Equals(""))
                {
                    throw new Exception("É necessário digitar uma sigla para o aeroporto.");
                }
                if (porto.SiglaAeroporto.Trim().Length != 3)
                {
                    throw new Exception("A sigla do aeroporto deve conter 3 caracteres.");
                }
                if ((porto.SiglaAeroporto.Contains("@")) || (porto.SiglaAeroporto.Contains("#")) || (porto.SiglaAeroporto.Contains("$")) || (porto.SiglaAeroporto.Contains("'"))
                    || (porto.SiglaAeroporto.Contains("%")) || (porto.SiglaAeroporto.Contains("&")) || (porto.SiglaAeroporto.Contains("(")) || (porto.SiglaAeroporto.Contains(")"))
                    || (porto.SiglaAeroporto.Contains("+")) || (porto.SiglaAeroporto.Contains("=")) || (porto.SiglaAeroporto.Contains("{"))
                    || (porto.SiglaAeroporto.Contains("}")) || (porto.SiglaAeroporto.Contains("[")) || (porto.SiglaAeroporto.Contains("]")) || (porto.SiglaAeroporto.Contains("?"))
                    || (porto.SiglaAeroporto.Contains("!")) || (porto.SiglaAeroporto.Contains("§")) || (porto.SiglaAeroporto.Contains("1")) || (porto.SiglaAeroporto.Contains("2"))
                    || (porto.SiglaAeroporto.Contains("3")) || (porto.SiglaAeroporto.Contains("4")) || (porto.SiglaAeroporto.Contains("5")) || (porto.SiglaAeroporto.Contains("6"))
                    || (porto.SiglaAeroporto.Contains("7")) || (porto.SiglaAeroporto.Contains("8")) || (porto.SiglaAeroporto.Contains("9")) || (porto.SiglaAeroporto.Contains("0")))
                {
                    throw new Exception("A sigla do aeroporto não deve conter números ou caracteres especiais.");
                }   
                #endregion

                dados.alterarAeroporto(porto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirAeroporto(Aeroporto porto)
        {
            try
            {
                if (porto.CodAeroporto == null)
                {
                    throw new Exception("É necessário escolher um aeroporto para excluir.");
                }
                if (porto.CodAeroporto < 1)
                {
                    throw new Exception("É necessário escolher um aeroporto para excluir.");
                }

                foreach (Trecho trecho in dados.listarTrechos()) 
                {
                    if ((porto.CodAeroporto == trecho.Origem.CodAeroporto) || (porto.CodAeroporto == trecho.Origem.CodAeroporto)) 
                    {
                        throw new Exception("Não é possível excluir o aeroporto "+porto.NomeAeroporto+", pois está associado ao trecho "+trecho.NomeTrecho);
                        
                    }
                
                }

                dados.excluirAeroporto(porto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
