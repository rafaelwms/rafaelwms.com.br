﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Odbc;
using System.Data.OleDb;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;

namespace ClassesComuns.Dados
{
    class DadosVoo : ConexaoODBC, InterfaceVoo
    {


        public void inserirVoo(Voo voo)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Voo (numVoo, dataVoo, horaVoo, rotaVoo, naveVoo, piloto, copiloto, agentea, agenteb, agentec, agented) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.NumVoo;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = voo.DataVoo;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = voo.HoraVoo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.RotaVoo.CodRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.NaveVoo.CodAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.PilotoVoo.CodPiloto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.CoPilotoVoo.CodPiloto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo1.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo2.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo3.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo4.CodAgBordo;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarVoo(Voo voo)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Voo set numVoo = ?, dataVoo = ?, horaVoo = ?, rotaVoo = ?, naveVoo = ?, piloto = ?, copiloto = ?, agentea = ?, agenteb = ?, agentec = ?, agented = ? WHERE codVoo = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.NumVoo;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = voo.DataVoo;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = voo.HoraVoo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.RotaVoo.CodRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.NaveVoo.CodAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.PilotoVoo.CodPiloto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.CoPilotoVoo.CodPiloto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo1.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo2.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo3.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo4.CodAgBordo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.CodVoo;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirVoo(Voo voo)
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM Voo WHERE codVoo = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.CodVoo;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Voo> listarVoos()
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Voo.codVoo, Voo.numVoo, Voo.dataVoo, Voo.horaVoo, Aeronave.codAeronave, Aeronave.idAeronave, Aeronave.apelidoAeronave, Aeronave.modeloAeronave,  Aeronave.qtdPoltronas, Aeronave.milhas, Aeronave.patio, Rota.codRota, Rota.nomeRota, Rota.milhasRota, Rota.minRota, Piloto.codPiloto, Piloto.horasVooPiloto,  Piloto.disp, FuncPiloto.codFunc AS codFuncPi, FuncPiloto.nomeFunc AS nomeFuncPi, Copiloto.codPiloto AS codCopiloto, Copiloto.horasVooPiloto AS horasVooCopiloto, Copiloto.disp AS dispCoPiloto, FuncCoPiloto.codFunc AS codFuncCo, FuncCoPiloto.nomeFunc AS nomeFuncCo, AgenteA.codAgBordo AS codAgA, AgenteA.enfermeiro AS enfermeiroAgA, AgenteA.disp AS dispAgA, FuncA.codFunc AS codFuncAgA, FuncA.nomeFunc AS nomeFuncAgA, AgenteB.codAgBordo AS codAgB, AgenteB.enfermeiro AS enfermeiroAgB, AgenteB.disp AS dispAgB, FuncB.codFunc AS codFuncAgB, FuncB.nomeFunc AS nomeFuncAgB, AgenteC.codAgBordo AS codAgC, AgenteC.enfermeiro AS enfermeiroAgC, AgenteC.disp AS dispAgC, FuncC.codFunc AS codFuncAgC, FuncC.nomeFunc AS nomeFuncAgC, AgenteD.codAgBordo AS codAgD, AgenteD.enfermeiro AS enfermeiroAgD, AgenteD.disp AS dispAgD, FuncD.codFunc AS codFuncAgD, FuncD.nomeFunc AS nomeFuncAgD,  Copiloto.breve AS breveCo, Piloto.breve AS brevePi FROM Voo INNER JOIN Aeronave ON Voo.naveVoo = Aeronave.codAeronave INNER JOIN Rota ON Voo.rotaVoo = Rota.codRota INNER JOIN Piloto ON Voo.piloto = Piloto.codPiloto INNER JOIN Piloto AS Copiloto ON Voo.copiloto = Copiloto.codPiloto INNER JOIN AgenteBordo AS AgenteA ON Voo.agentea = AgenteA.codAgBordo INNER JOIN AgenteBordo AS AgenteB ON Voo.agenteb = AgenteB.codAgBordo INNER JOIN AgenteBordo AS AgenteC ON Voo.agentec = AgenteC.codAgBordo INNER JOIN AgenteBordo AS AgenteD ON Voo.agented = AgenteD.codAgBordo INNER JOIN Funcionario AS FuncA ON AgenteA.codFunc = FuncA.codFunc INNER JOIN Funcionario AS FuncPiloto ON Piloto.codFunc = FuncPiloto.codFunc INNER JOIN Funcionario AS FuncCoPiloto ON Copiloto.codFunc = FuncCoPiloto.codFunc INNER JOIN Funcionario AS FuncB ON AgenteB.codFunc = FuncB.codFunc INNER JOIN Funcionario AS FuncC ON AgenteC.codFunc = FuncC.codFunc INNER JOIN Funcionario AS FuncD ON AgenteD.codFunc = FuncD.codFunc";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Voo> retorno = new List<Voo>();
                while (leitor.Read())
                {
                    Voo voo = new Voo();
                    voo.CodVoo = leitor.GetInt32(leitor.GetOrdinal("codVoo"));
                    voo.NumVoo = leitor.GetInt32(leitor.GetOrdinal("numVoo"));
                    voo.DataVoo = leitor.GetString(leitor.GetOrdinal("dataVoo"));
                    voo.HoraVoo = leitor.GetString(leitor.GetOrdinal("horaVoo"));

                    Aeronave nave = new Aeronave();
                    nave.CodAeronave = leitor.GetInt32(leitor.GetOrdinal("codAeronave"));
                    nave.IdAeronave = leitor.GetString(leitor.GetOrdinal("idAeronave"));
                    nave.ApelidoAeronave = leitor.GetString(leitor.GetOrdinal("apelidoAeronave"));
                    nave.ModeloAeronave = leitor.GetString(leitor.GetOrdinal("modeloAeronave"));
                    nave.QtdPoltronas = leitor.GetInt32(leitor.GetOrdinal("qtdPoltronas"));
                    nave.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhas"));
                    nave.Patio = leitor.GetInt32(leitor.GetOrdinal("patio"));
                    voo.NaveVoo = nave;

                    Rota rota = new Rota();
                    rota.CodRota = leitor.GetInt32(leitor.GetOrdinal("codRota"));
                    rota.NomeRota = leitor.GetString(leitor.GetOrdinal("nomeRota"));
                    rota.MilhasRota = leitor.GetInt32(leitor.GetOrdinal("milhasRota"));
                    rota.MinRota = leitor.GetInt32(leitor.GetOrdinal("minRota"));
                    voo.RotaVoo = rota;

                    Piloto piloto = new Piloto();
                    piloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codPiloto"));
                    piloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooPiloto"));
                    piloto.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                    piloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncPi"));
                    piloto.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncPi"));
                    

                    Piloto copiloto = new Piloto();
                    copiloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codCopiloto"));
                    copiloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooCopiloto"));
                    copiloto.Disp = leitor.GetInt32(leitor.GetOrdinal("dispCoPiloto"));
                    copiloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncCo"));
                    copiloto.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncCo"));
                    

                    AgenteBordo ag1 = new AgenteBordo();
                    ag1.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgA"));
                    ag1.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgA"));
                    ag1.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgA"));
                    ag1.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgA"));
                    ag1.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgA"));
                    voo.AgBordo1 = ag1;

                    AgenteBordo ag2 = new AgenteBordo();
                    ag2.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgB"));
                    ag2.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgB"));
                    ag2.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgB"));
                    ag2.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgB"));
                    ag2.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgB"));
                    voo.AgBordo2 = ag2;

                    AgenteBordo ag3 = new AgenteBordo();
                    ag3.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgC"));
                    ag3.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgC"));
                    ag3.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgC"));
                    ag3.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgC"));
                    ag3.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgC"));
                    voo.AgBordo3 = ag3;

                    AgenteBordo ag4 = new AgenteBordo();
                    ag4.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgD"));
                    ag4.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgD"));
                    ag4.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgD"));
                    ag4.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgD"));
                    ag4.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgD"));
                    voo.AgBordo4 = ag4;

                    copiloto.Breve = leitor.GetString(leitor.GetOrdinal("breveCo"));
                    piloto.Breve = leitor.GetString(leitor.GetOrdinal("brevePi"));
                    voo.PilotoVoo = piloto;
                    voo.CoPilotoVoo = copiloto;
                    retorno.Add(voo);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Voo> procurarVoo(string busca)
        {
            busca += "%";
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Voo.codVoo, Voo.numVoo, Voo.dataVoo, Voo.horaVoo, Aeronave.codAeronave, Aeronave.idAeronave, Aeronave.apelidoAeronave, Aeronave.modeloAeronave,  Aeronave.qtdPoltronas, Aeronave.milhas, Aeronave.patio, Rota.codRota, Rota.nomeRota, Rota.milhasRota, Rota.minRota, Piloto.codPiloto, Piloto.horasVooPiloto,  Piloto.disp, FuncPiloto.codFunc AS codFuncPi, FuncPiloto.nomeFunc AS nomeFuncPi, Copiloto.codPiloto AS codCopiloto, Copiloto.horasVooPiloto AS horasVooCopiloto, Copiloto.disp AS dispCoPiloto, FuncCoPiloto.codFunc AS codFuncCo, FuncCoPiloto.nomeFunc AS nomeFuncCo, AgenteA.codAgBordo AS codAgA, AgenteA.enfermeiro AS enfermeiroAgA, AgenteA.disp AS dispAgA, FuncA.codFunc AS codFuncAgA, FuncA.nomeFunc AS nomeFuncAgA, AgenteB.codAgBordo AS codAgB, AgenteB.enfermeiro AS enfermeiroAgB, AgenteB.disp AS dispAgB, FuncB.codFunc AS codFuncAgB, FuncB.nomeFunc AS nomeFuncAgB, AgenteC.codAgBordo AS codAgC, AgenteC.enfermeiro AS enfermeiroAgC, AgenteC.disp AS dispAgC, FuncC.codFunc AS codFuncAgC, FuncC.nomeFunc AS nomeFuncAgC, AgenteD.codAgBordo AS codAgD, AgenteD.enfermeiro AS enfermeiroAgD, AgenteD.disp AS dispAgD, FuncD.codFunc AS codFuncAgD, FuncD.nomeFunc AS nomeFuncAgD,  Copiloto.breve AS breveCo, Piloto.breve AS brevePi FROM Voo INNER JOIN Aeronave ON Voo.naveVoo = Aeronave.codAeronave INNER JOIN Rota ON Voo.rotaVoo = Rota.codRota INNER JOIN Piloto ON Voo.piloto = Piloto.codPiloto INNER JOIN Piloto AS Copiloto ON Voo.copiloto = Copiloto.codPiloto INNER JOIN AgenteBordo AS AgenteA ON Voo.agentea = AgenteA.codAgBordo INNER JOIN AgenteBordo AS AgenteB ON Voo.agenteb = AgenteB.codAgBordo INNER JOIN AgenteBordo AS AgenteC ON Voo.agentec = AgenteC.codAgBordo INNER JOIN AgenteBordo AS AgenteD ON Voo.agented = AgenteD.codAgBordo INNER JOIN Funcionario AS FuncA ON AgenteA.codFunc = FuncA.codFunc INNER JOIN Funcionario AS FuncPiloto ON Piloto.codFunc = FuncPiloto.codFunc INNER JOIN Funcionario AS FuncCoPiloto ON Copiloto.codFunc = FuncCoPiloto.codFunc INNER JOIN Funcionario AS FuncB ON AgenteB.codFunc = FuncB.codFunc INNER JOIN Funcionario AS FuncC ON AgenteC.codFunc = FuncC.codFunc INNER JOIN Funcionario AS FuncD ON AgenteD.codFunc = FuncD.codFunc WHERE Rota.nomeRota like ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = busca;
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Voo> retorno = new List<Voo>();
                while (leitor.Read())
                {
                    Voo voo = new Voo();
                    voo.CodVoo = leitor.GetInt32(leitor.GetOrdinal("codVoo"));
                    voo.CodVoo = leitor.GetInt32(leitor.GetOrdinal("numVoo"));
                    voo.DataVoo = leitor.GetString(leitor.GetOrdinal("dataVoo"));
                    voo.HoraVoo = leitor.GetString(leitor.GetOrdinal("horaVoo"));

                    Aeronave nave = new Aeronave();
                    nave.CodAeronave = leitor.GetInt32(leitor.GetOrdinal("codAeronave"));
                    nave.IdAeronave = leitor.GetString(leitor.GetOrdinal("idAeronave"));
                    nave.ApelidoAeronave = leitor.GetString(leitor.GetOrdinal("apelidoAeronave"));
                    nave.ModeloAeronave = leitor.GetString(leitor.GetOrdinal("modeloAeronave"));
                    nave.QtdPoltronas = leitor.GetInt32(leitor.GetOrdinal("qtdPoltronas"));
                    nave.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhas"));
                    nave.Patio = leitor.GetInt32(leitor.GetOrdinal("patio"));
                    voo.NaveVoo = nave;

                    Rota rota = new Rota();
                    rota.CodRota = leitor.GetInt32(leitor.GetOrdinal("codRota"));
                    rota.NomeRota = leitor.GetString(leitor.GetOrdinal("nomeRota"));
                    rota.MilhasRota = leitor.GetInt32(leitor.GetOrdinal("milhasRota"));
                    rota.MinRota = leitor.GetInt32(leitor.GetOrdinal("minRota"));
                    voo.RotaVoo = rota;

                    Piloto piloto = new Piloto();
                    piloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codPiloto"));
                    piloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooPiloto"));
                    piloto.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                    piloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncPi"));
                    piloto.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncPi"));


                    Piloto copiloto = new Piloto();
                    copiloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codCopiloto"));
                    copiloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooCopiloto"));
                    copiloto.Disp = leitor.GetInt32(leitor.GetOrdinal("dispCoPiloto"));
                    copiloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncCo"));
                    copiloto.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncCo"));


                    AgenteBordo ag1 = new AgenteBordo();
                    ag1.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgA"));
                    ag1.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgA"));
                    ag1.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgA"));
                    ag1.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgA"));
                    ag1.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgA"));
                    voo.AgBordo1 = ag1;

                    AgenteBordo ag2 = new AgenteBordo();
                    ag2.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgB"));
                    ag2.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgB"));
                    ag2.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgB"));
                    ag2.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgB"));
                    ag2.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgB"));
                    voo.AgBordo2 = ag2;

                    AgenteBordo ag3 = new AgenteBordo();
                    ag3.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgC"));
                    ag3.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgC"));
                    ag3.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgC"));
                    ag3.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgC"));
                    ag3.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgC"));
                    voo.AgBordo3 = ag3;

                    AgenteBordo ag4 = new AgenteBordo();
                    ag4.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgD"));
                    ag4.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiroAgD"));
                    ag4.Disp = leitor.GetInt32(leitor.GetOrdinal("dispAgD"));
                    ag4.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFuncAgD"));
                    ag4.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFuncAgD"));
                    voo.AgBordo4 = ag4;

                    copiloto.Breve = leitor.GetString(leitor.GetOrdinal("breveCo"));
                    piloto.Breve = leitor.GetString(leitor.GetOrdinal("brevePi"));
                    voo.PilotoVoo = piloto;
                    voo.CoPilotoVoo = copiloto;
                    retorno.Add(voo);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void confirmarDecolagem(Voo voo)
        {

            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 2 WHERE codAgBordo = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo1.CodAgBordo;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 2 WHERE codAgBordo = ?";
                comando.Connection = conn2;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo2.CodAgBordo;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn3 = conexaoOdbc();
            conn3.Open();
            OdbcTransaction trans3 = conn3.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 2 WHERE codAgBordo = ?";
                comando.Connection = conn3;
                comando.Transaction = trans3;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo3.CodAgBordo;
                comando.ExecuteNonQuery();
                trans3.Commit();
                conn3.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn4 = conexaoOdbc();
            conn4.Open();
            OdbcTransaction trans4 = conn4.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 2 WHERE codAgBordo = ?";
                comando.Connection = conn4;
                comando.Transaction = trans4;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo4.CodAgBordo;
                comando.ExecuteNonQuery();
                trans4.Commit();
                conn4.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn5 = conexaoOdbc();
            conn5.Open();
            OdbcTransaction trans5 = conn5.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Piloto set disp = 2 WHERE codPiloto = ?";
                comando.Connection = conn5;
                comando.Transaction = trans5;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.PilotoVoo.CodPiloto;
                comando.ExecuteNonQuery();
                trans5.Commit();
                conn5.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn6 = conexaoOdbc();
            conn6.Open();
            OdbcTransaction trans6 = conn6.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Piloto set disp = 2 WHERE codPiloto = ?";
                comando.Connection = conn6;
                comando.Transaction = trans6;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.CoPilotoVoo.CodPiloto;
                comando.ExecuteNonQuery();
                trans6.Commit();
                conn6.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn7 = conexaoOdbc();
            conn7.Open();
            OdbcTransaction trans7 = conn7.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Aeronave set patio = 2 WHERE codAeronave = ?";
                comando.Connection = conn7;
                comando.Transaction = trans7;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.NaveVoo.CodAeronave;
                comando.ExecuteNonQuery();
                trans7.Commit();
                conn7.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

        }

        public void confirmarAterrissagem(Voo voo)
        {
            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 1 WHERE codAgBordo = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo1.CodAgBordo;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 1 WHERE codAgBordo = ?";
                comando.Connection = conn2;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo2.CodAgBordo;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn3 = conexaoOdbc();
            conn3.Open();
            OdbcTransaction trans3 = conn3.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 1 WHERE codAgBordo = ?";
                comando.Connection = conn3;
                comando.Transaction = trans3;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo3.CodAgBordo;
                comando.ExecuteNonQuery();
                trans3.Commit();
                conn3.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn4 = conexaoOdbc();
            conn4.Open();
            OdbcTransaction trans4 = conn4.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 1 WHERE codAgBordo = ?";
                comando.Connection = conn4;
                comando.Transaction = trans4;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.AgBordo4.CodAgBordo;
                comando.ExecuteNonQuery();
                trans4.Commit();
                conn4.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn5 = conexaoOdbc();
            conn5.Open();
            OdbcTransaction trans5 = conn5.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Piloto set disp = 1 WHERE codPiloto = ?";
                comando.Connection = conn5;
                comando.Transaction = trans5;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.PilotoVoo.CodPiloto;
                comando.ExecuteNonQuery();
                trans5.Commit();
                conn5.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn6 = conexaoOdbc();
            conn6.Open();
            OdbcTransaction trans6 = conn6.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Piloto set disp = 1 WHERE codPiloto = ?";
                comando.Connection = conn6;
                comando.Transaction = trans6;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.CoPilotoVoo.CodPiloto;
                comando.ExecuteNonQuery();
                trans6.Commit();
                conn6.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }

            OdbcConnection conn7 = conexaoOdbc();
            conn7.Open();
            OdbcTransaction trans7 = conn7.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Aeronave set patio = 1 WHERE codAeronave = ?";
                comando.Connection = conn7;
                comando.Transaction = trans7;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = voo.NaveVoo.CodAeronave;
                comando.ExecuteNonQuery();
                trans7.Commit();
                conn7.Close();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
        }
    }
}
