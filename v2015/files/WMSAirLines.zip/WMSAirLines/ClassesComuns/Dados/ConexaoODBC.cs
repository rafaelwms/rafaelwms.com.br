﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using System.Data.Odbc;
using System.Data.SqlClient;

namespace ClassesComuns.Dados
{
   public abstract  class ConexaoODBC
    {

        protected string nomeConexao = "WMSAirLines";
        protected OdbcConnection conn;
        protected SqlConnection connSqlServer;


        public void abrirConexaoOdbc()
        {
            try
            {
                conn = new OdbcConnection("DSN=" + nomeConexao);
                conn.Open();
            }
            catch (Exception ex)
            {

            }
        }

        public OdbcConnection conexaoOdbc() {
            conn = new OdbcConnection("DSN=" + nomeConexao);
            return conn;
        }
        public void fecharConexaoOdbc()
        {
            conn.Close();
            conn.Dispose();
        }
        //public List<Usuario> select()
        //{
        //    this.abrirConexaoOdbc();
        //    OdbcCommand comando = conn.CreateCommand();
        //    comando.CommandText = "select numero, nome from setor";
        //    OdbcDataReader leitor = comando.ExecuteReader();
        //    List<Setor> retorno = new List<Setor>();
        //    while (leitor.Read())
        //    {
        //        Setor s = new Setor();
        //        s.Numero = leitor.GetInt32(leitor.GetOrdinal("numero"));
        //        s.Nome = leitor.GetString(leitor.GetOrdinal("nome"));
        //        retorno.Add(s);
        //    }
        //    leitor.Close();
        //    leitor.Dispose();
        //    this.fecharConexaoOdbc();
        //    return retorno;
        //}

    }
}
