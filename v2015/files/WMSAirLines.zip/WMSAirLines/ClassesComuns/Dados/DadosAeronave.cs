﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using System.Data.Odbc;
using System.Data.OleDb;

namespace ClassesComuns.Dados
{

    public class DadosAeronave : ConexaoODBC, InterfaceAeronave
    {

        public void inserirAeronave(Aeronave nave)
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Aeronave (idAeronave, apelidoAeronave, modeloAeronave, qtdPoltronas, milhas, patio) values (?, ?, ?, ?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = nave.IdAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = nave.ApelidoAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = nave.ModeloAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.QtdPoltronas;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.Milhas;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.Patio;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeronave> listarAeronaves()
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT codAeronave, idAeronave, apelidoAeronave, modeloAeronave, qtdPoltronas, milhas, patio from Aeronave";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Aeronave> retorno = new List<Aeronave>();
                while (leitor.Read())
                {
                    Aeronave nave = new Aeronave();
                    nave.CodAeronave = leitor.GetInt32(leitor.GetOrdinal("codAeronave"));
                    nave.IdAeronave = leitor.GetString(leitor.GetOrdinal("idAeronave"));
                    nave.ApelidoAeronave = leitor.GetString(leitor.GetOrdinal("apelidoAeronave"));
                    nave.ModeloAeronave = leitor.GetString(leitor.GetOrdinal("modeloAeronave"));
                    nave.QtdPoltronas = leitor.GetInt32(leitor.GetOrdinal("qtdPoltronas"));
                    nave.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhas"));
                    nave.Patio = leitor.GetInt32(leitor.GetOrdinal("patio"));
                    retorno.Add(nave);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeronave> procurarAeronave(string busca)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT codAeronave, idAeronave, apelidoAeronave, modeloAeronave, qtdPoltronas, milhas, patio from Aeronave WHERE apelidoAeronave like '%"+busca+"%'";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Aeronave> retorno = new List<Aeronave>();
                while (leitor.Read())
                {
                    Aeronave nave = new Aeronave();
                    nave.CodAeronave = leitor.GetInt32(leitor.GetOrdinal("codAeronave"));
                    nave.IdAeronave = leitor.GetString(leitor.GetOrdinal("idAeronave"));
                    nave.ApelidoAeronave = leitor.GetString(leitor.GetOrdinal("apelidoAeronave"));
                    nave.ModeloAeronave = leitor.GetString(leitor.GetOrdinal("modeloAeronave"));
                    nave.QtdPoltronas = leitor.GetInt32(leitor.GetOrdinal("qtdPoltronas"));
                    nave.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhas"));
                    nave.Patio = leitor.GetInt32(leitor.GetOrdinal("patio"));
                    retorno.Add(nave);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarAeronave(Aeronave nave)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Aeronave set idAeronave = ?, apelidoAeronave = ?, modeloAeronave = ?, qtdPoltronas = ?, milhas = ?, patio = ? WHERE codAeronave = ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = nave.IdAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = nave.ApelidoAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = nave.ModeloAeronave;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.QtdPoltronas;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.Milhas;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.Patio;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.CodAeronave;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirAeronave(Aeronave nave)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM Aeronave WHERE codAeronave = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = nave.CodAeronave;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeronave> procurarAeronaveVoo(int codigo)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Aeronave.codAeronave FROM Aeronave INNER JOIN Voo ON Aeronave.codAeronave = Voo.naveVoo where Aeronave.codAeronave = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = codigo;
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Aeronave> retorno = new List<Aeronave>();
                while (leitor.Read())
                {
                    Aeronave nave = new Aeronave();
                    nave.CodAeronave = leitor.GetInt32(leitor.GetOrdinal("codAeronave"));
                    retorno.Add(nave);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
     
    }
}
