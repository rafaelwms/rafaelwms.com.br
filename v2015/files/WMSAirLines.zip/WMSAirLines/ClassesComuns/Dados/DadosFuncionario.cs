﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Controladores;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace ClassesComuns.Dados
{
    class DadosFuncionario : ConexaoODBC, InterfaceFucionario
    {
        public void inserirFuncionario(Funcionario func)
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Funcionario (nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo) values (?, ?, ?, ?, ?, ?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.NomeFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.RgFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.CpfFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.LoginFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.SenhaFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.CargoFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Decimal).Value = func.Salario;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 1;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }

        public List<Funcionario> listarFuncionarios()
        {
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            comando.CommandText = "SELECT codFunc, nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo from Funcionario";
            OdbcDataReader leitor = comando.ExecuteReader();
            List<Funcionario> retorno = new List<Funcionario>();
            while (leitor.Read())
            {
                Funcionario func = new Funcionario();
                func.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                func.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFunc"));
                func.RgFunc = leitor.GetString(leitor.GetOrdinal("rgFunc"));
                func.CpfFunc = leitor.GetString(leitor.GetOrdinal("cpfFunc"));
                func.LoginFunc = leitor.GetString(leitor.GetOrdinal("loginFunc"));
                func.SenhaFunc = leitor.GetString(leitor.GetOrdinal("senhaFunc"));
                func.CargoFunc = leitor.GetString(leitor.GetOrdinal("cargoFunc"));
                func.Salario = leitor.GetDecimal(leitor.GetOrdinal("salario"));
                func.Ativo = leitor.GetInt32(leitor.GetOrdinal("ativo"));
                retorno.Add(func);
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();
            return retorno;
        }

        public List<Funcionario> procurarFuncionario(string busca)
        {
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            comando.CommandText = "SELECT codFunc, nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo from Funcionario WHERE nomeFunc like '%" + busca + "%'";
            OdbcDataReader leitor = comando.ExecuteReader();
            List<Funcionario> retorno = new List<Funcionario>();
            while (leitor.Read())
            {
                Funcionario func = new Funcionario();
                func.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                func.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFunc"));
                func.RgFunc = leitor.GetString(leitor.GetOrdinal("rgFunc"));
                func.CpfFunc = leitor.GetString(leitor.GetOrdinal("cpfFunc"));
                func.LoginFunc = leitor.GetString(leitor.GetOrdinal("loginFunc"));
                func.SenhaFunc = leitor.GetString(leitor.GetOrdinal("senhaFunc"));
                func.CargoFunc = leitor.GetString(leitor.GetOrdinal("cargoFunc"));
                func.Salario = leitor.GetDecimal(leitor.GetOrdinal("salario"));
                func.Ativo = leitor.GetInt32(leitor.GetOrdinal("ativo"));
                retorno.Add(func);
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();
            return retorno;
        }

        public void alterarFucionario(Funcionario func)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE  Funcionario set nomeFunc = ?, rgFunc = ?, cpfFunc = ?, loginFunc = ?, senhaFunc = ?, cargoFunc = ?, salario = ?, ativo = ? WHERE codFunc = ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.NomeFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.RgFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.CpfFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.LoginFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.SenhaFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = func.CargoFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Decimal).Value = func.Salario;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = func.CodFunc;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }

        public void demitirFuncionario(Funcionario func)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE  Funcionario set ativo = ? WHERE codFunc = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 0;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = func.CodFunc;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
