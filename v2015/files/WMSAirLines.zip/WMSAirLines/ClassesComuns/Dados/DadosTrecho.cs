﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using System.Data.Odbc;
using System.Data.OleDb;

namespace ClassesComuns.Dados
{
    class DadosTrecho : ConexaoODBC, InterfaceTrecho
    {


        public void inserirTrecho(Trecho trecho)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Trecho (nomeTrecho, origem, destino, milhasTrecho, minTrecho) values (?, ?, ?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = trecho.NomeTrecho;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.Origem.CodAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.Destino.CodAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.Milhas;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.MinTrecho;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Trecho> listarTrechos()
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Trecho.codTrecho, Trecho.nomeTrecho, Trecho.milhasTrecho, Trecho.minTrecho, Origem.codAeroporto AS origemCod,  Origem.nomeAeroporto AS origemNome, Origem.cidadeAeroporto AS origemCidade, Origem.ufAeroporto AS origemUf, Origem.siglaAeroporto AS origemSigla, Destino.codAeroporto AS destinoCod, Destino.nomeAeroporto AS destinoNome, Destino.cidadeAeroporto AS destinoCidade, Destino.ufAeroporto AS destinoUf, Destino.siglaAeroporto AS destinoSigla FROM Trecho INNER JOIN Aeroporto AS Destino ON Trecho.destino = Destino.codAeroporto INNER JOIN Aeroporto AS Origem ON Trecho.origem = Origem.codAeroporto";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Trecho> retorno = new List<Trecho>();
                while (leitor.Read())
                {
                    Trecho trecho = new Trecho();
                    trecho.CodTrecho = leitor.GetInt32(leitor.GetOrdinal("codTrecho"));
                    trecho.NomeTrecho = leitor.GetString(leitor.GetOrdinal("nomeTrecho"));
                    trecho.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhasTrecho"));
                    trecho.MinTrecho = leitor.GetInt32(leitor.GetOrdinal("minTrecho"));

                    Aeroporto origem = new Aeroporto();
                    origem.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("origemCod"));
                    origem.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("origemNome"));
                    origem.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("origemCidade"));
                    origem.UfAeroporto = leitor.GetString(leitor.GetOrdinal("origemUf"));
                    origem.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("origemSigla"));
                    trecho.Origem = origem;

                    Aeroporto destino = new Aeroporto();
                    destino.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("destinoCod"));
                    destino.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("destinoNome"));
                    destino.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("destinoCidade"));
                    destino.UfAeroporto = leitor.GetString(leitor.GetOrdinal("destinoUf"));
                    destino.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("destinoSigla"));
                    trecho.Destino = destino;

                    retorno.Add(trecho);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Trecho> procurarTrecho(string busca)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Trecho.codTrecho, Trecho.nomeTrecho, Trecho.milhasTrecho, Trecho.minTrecho, Origem.codAeroporto AS origemCod,  Origem.nomeAeroporto AS origemNome, Origem.cidadeAeroporto AS origemCidade, Origem.ufAeroporto AS origemUf, Origem.siglaAeroporto AS origemSigla, Destino.codAeroporto AS destinoCod, Destino.nomeAeroporto AS destinoNome, Destino.cidadeAeroporto AS destinoCidade, Destino.ufAeroporto AS destinoUf, Destino.siglaAeroporto AS destinoSigla FROM Trecho INNER JOIN Aeroporto AS Destino ON Trecho.destino = Destino.codAeroporto INNER JOIN Aeroporto AS Origem ON Trecho.origem = Origem.codAeroporto WHERE Trecho.nomeTrecho like '%"+busca+"%'";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Trecho> retorno = new List<Trecho>();
                while (leitor.Read())
                {
                    Trecho trecho = new Trecho();
                    trecho.CodTrecho = leitor.GetInt32(leitor.GetOrdinal("codTrecho"));
                    trecho.NomeTrecho = leitor.GetString(leitor.GetOrdinal("nomeTrecho"));
                    trecho.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhasTrecho"));
                    trecho.MinTrecho = leitor.GetInt32(leitor.GetOrdinal("minTrecho"));

                    Aeroporto origem = new Aeroporto();
                    origem.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("origemCod"));
                    origem.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("origemNome"));
                    origem.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("origemCidade"));
                    origem.UfAeroporto = leitor.GetString(leitor.GetOrdinal("origemUf"));
                    origem.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("origemSigla"));
                    trecho.Origem = origem;

                    Aeroporto destino = new Aeroporto();
                    destino.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("destinoCod"));
                    destino.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("destinoNome"));
                    destino.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("destinoCidade"));
                    destino.UfAeroporto = leitor.GetString(leitor.GetOrdinal("destinoUf"));
                    destino.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("destinoSigla"));
                    trecho.Destino = destino;

                    retorno.Add(trecho);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarTrecho(Trecho trecho)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Trecho SET nomeTrecho = ?, origem = ?, destino = ?, milhasTrecho = ?, minTrecho = ? WHERE codTrecho = ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = trecho.NomeTrecho;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.Origem.CodAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.Destino.CodAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.Milhas;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.MinTrecho;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.CodTrecho;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirTrecho(Trecho trecho)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM Trecho WHERE codTrecho = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.CodTrecho;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<Trecho> procurarTrechoRota(int cod) 
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT TrechosDaRota.codTrecho, Trecho.nomeTrecho, Trecho.milhasTrecho, Trecho.minTrecho, Origem.codAeroporto AS codOrigem, Origem.nomeAeroporto AS nomeOrigem, Origem.cidadeAeroporto AS cidadeOrigem, Origem.ufAeroporto AS ufOrigem, Origem.siglaAeroporto AS siglaOrigem, Destino.codAeroporto AS codDestino, Destino.nomeAeroporto AS nomeDestino, Destino.cidadeAeroporto AS cidadeDestino, Destino.ufAeroporto AS ufDestino, Destino.siglaAeroporto AS siglaDestino FROM TrechosDaRota INNER JOIN Trecho ON TrechosDaRota.codTrecho = Trecho.codTrecho INNER JOIN Aeroporto AS Origem ON Trecho.origem = Origem.codAeroporto INNER JOIN Aeroporto AS Destino ON Trecho.destino = Destino.codAeroporto WHERE TrechosDaRota.codTrecho = ?";
                comando.Parameters.AddWithValue("?", cod);
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Trecho> retorno = new List<Trecho>();
                while (leitor.Read())
                {
                    Trecho trecho = new Trecho();
                    trecho.CodTrecho = leitor.GetInt32(leitor.GetOrdinal("codTrecho"));
                    trecho.NomeTrecho = leitor.GetString(leitor.GetOrdinal("nomeTrecho"));
                    trecho.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhasTrecho"));
                    trecho.MinTrecho = leitor.GetInt32(leitor.GetOrdinal("minTrecho"));

                    Aeroporto origem = new Aeroporto();
                    origem.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("codOrigem"));
                    origem.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("nomeOrigem"));
                    origem.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("cidadeOrigem"));
                    origem.UfAeroporto = leitor.GetString(leitor.GetOrdinal("ufOrigem"));
                    origem.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("siglaOrigem"));
                    trecho.Origem = origem;

                    Aeroporto destino = new Aeroporto();
                    destino.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("codDestino"));
                    destino.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("nomeDestino"));
                    destino.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("cidadeDestino"));
                    destino.UfAeroporto = leitor.GetString(leitor.GetOrdinal("ufDestino"));
                    destino.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("siglaDestino"));
                    trecho.Destino = destino;

                    retorno.Add(trecho);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        
        }
    }
}
