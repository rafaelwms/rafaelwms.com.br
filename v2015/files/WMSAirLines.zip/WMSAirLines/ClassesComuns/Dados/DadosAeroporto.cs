﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data.Odbc;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;

namespace ClassesComuns.Dados
{
    class DadosAeroporto : ConexaoODBC, InterfaceAeroporto
    {

        public void inserirAeroporto(Aeroporto porto)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Aeroporto (nomeAeroporto, cidadeAeroporto, ufAeroporto, siglaAeroporto) values (?, ?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = porto.NomeAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = porto.CidadeAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Char).Value = porto.UfAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Char).Value = porto.SiglaAeroporto;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeroporto> listarAeroportos()
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT codAeroporto, nomeAeroporto, cidadeAeroporto, ufAeroporto, siglaAeroporto from Aeroporto";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Aeroporto> retorno = new List<Aeroporto>();
                while (leitor.Read())
                {
                    Aeroporto porto = new Aeroporto();
                    porto.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("codAeroporto"));
                    porto.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("nomeAeroporto"));
                    porto.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("cidadeAeroporto"));
                    porto.UfAeroporto = leitor.GetString(leitor.GetOrdinal("ufAeroporto"));
                    porto.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("siglaAeroporto"));
                    retorno.Add(porto);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Aeroporto> procurarAeroporto(string busca)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT codAeroporto, nomeAeroporto, cidadeAeroporto, ufAeroporto, siglaAeroporto from Aeroporto WHERE cidadeAeroporto like '%"+busca+"%'";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Aeroporto> retorno = new List<Aeroporto>();
                while (leitor.Read())
                {
                    Aeroporto porto = new Aeroporto();
                    porto.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("codAeroporto"));
                    porto.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("nomeAeroporto"));
                    porto.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("cidadeAeroporto"));
                    porto.UfAeroporto = leitor.GetString(leitor.GetOrdinal("ufAeroporto"));
                    porto.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("siglaAeroporto"));
                    retorno.Add(porto);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void alterarAeroporto(Aeroporto porto)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Aeroporto  set nomeAeroporto = ?, cidadeAeroporto = ?, ufAeroporto = ?, siglaAeroporto = ? WHERE codAeroporto = ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = porto.NomeAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = porto.CidadeAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Char).Value = porto.UfAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Char).Value = porto.SiglaAeroporto;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = porto.CodAeroporto;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void excluirAeroporto(Aeroporto porto)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM Aeroporto WHERE codAeroporto = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = porto.CodAeroporto;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Trecho> listarTrechos()
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Trecho.codTrecho, Trecho.nomeTrecho, Trecho.milhasTrecho, Trecho.minTrecho, Origem.codAeroporto AS origemCod,  Origem.nomeAeroporto AS origemNome, Origem.cidadeAeroporto AS origemCidade, Origem.ufAeroporto AS origemUf, Origem.siglaAeroporto AS origemSigla, Destino.codAeroporto AS destinoCod, Destino.nomeAeroporto AS destinoNome, Destino.cidadeAeroporto AS destinoCidade, Destino.ufAeroporto AS destinoUf, Destino.siglaAeroporto AS destinoSigla FROM Trecho INNER JOIN Aeroporto AS Destino ON Trecho.destino = Destino.codAeroporto INNER JOIN Aeroporto AS Origem ON Trecho.origem = Origem.codAeroporto";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Trecho> retorno = new List<Trecho>();
                while (leitor.Read())
                {
                    Trecho trecho = new Trecho();
                    trecho.CodTrecho = leitor.GetInt32(leitor.GetOrdinal("codTrecho"));
                    trecho.NomeTrecho = leitor.GetString(leitor.GetOrdinal("nomeTrecho"));
                    trecho.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhasTrecho"));
                    trecho.MinTrecho = leitor.GetInt32(leitor.GetOrdinal("minTrecho"));

                    Aeroporto origem = new Aeroporto();
                    origem.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("origemCod"));
                    origem.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("origemNome"));
                    origem.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("origemCidade"));
                    origem.UfAeroporto = leitor.GetString(leitor.GetOrdinal("origemUf"));
                    origem.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("origemSigla"));
                    trecho.Origem = origem;

                    Aeroporto destino = new Aeroporto();
                    destino.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("destinoCod"));
                    destino.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("destinoNome"));
                    destino.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("destinoCidade"));
                    destino.UfAeroporto = leitor.GetString(leitor.GetOrdinal("destinoUf"));
                    destino.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("destinoSigla"));
                    trecho.Destino = destino;

                    retorno.Add(trecho);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }



    }
}
