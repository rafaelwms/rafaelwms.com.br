﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Controladores;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace ClassesComuns.Dados
{
    class DadosUsuario : ConexaoODBC, InterfaceUsuario
    {

        public void inserirUsuario(Usuario usuario)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Usuario (nomeUser, rgUser, cpfUser, loginUser, senhaUser) values (?, ?, ?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.NomeUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.RgUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.CpfUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.LoginUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.SenhaUser;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }

        public List<Usuario> listarUsuarios()
        {
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            comando.CommandText = "SELECT codUser, nomeUser, rgUser,cpfUser, loginUser, senhaUser from Usuario";
            OdbcDataReader leitor = comando.ExecuteReader();
            List<Usuario> retorno = new List<Usuario>();
            while (leitor.Read())
            {
                Usuario usr = new Usuario();
                usr.CodUser = leitor.GetInt32(leitor.GetOrdinal("codUser"));
                usr.NomeUser = leitor.GetString(leitor.GetOrdinal("nomeUser"));
                usr.RgUser = leitor.GetString(leitor.GetOrdinal("rgUser"));
                usr.CpfUser = leitor.GetString(leitor.GetOrdinal("cpfUser"));
                usr.LoginUser = leitor.GetString(leitor.GetOrdinal("loginUser"));
                usr.SenhaUser = leitor.GetString(leitor.GetOrdinal("senhaUser"));
                retorno.Add(usr);
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();
            return retorno;
        }

        public Usuario procurarUsuario(Usuario usuario)
        {
            Usuario retorno = new Usuario();
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            String sql = "SELECT codUser, nomeUser, rgUser,cpfUser, loginUser, senhaUser from Usuario";
            if (usuario.NomeUser != null && usuario.NomeUser.Trim() != "")
            {
                sql += " WHERE nomeUser = '" + usuario.NomeUser + "'";
            }

            if (usuario.LoginUser != null && usuario.LoginUser.Trim() != "")
            {
                sql += " WHERE loginUser = '" + usuario.LoginUser + "' and senhaUser = '" + usuario.SenhaUser + "'";
            }
            comando.CommandText = sql;
            OdbcDataReader leitor = comando.ExecuteReader();
            while (leitor.Read())
            {
                Usuario usr = new Usuario();
                usr.CodUser = leitor.GetInt32(leitor.GetOrdinal("codUser"));
                usr.NomeUser = leitor.GetString(leitor.GetOrdinal("nomeUser"));
                usr.RgUser = leitor.GetString(leitor.GetOrdinal("rgUser"));
                usr.CpfUser = leitor.GetString(leitor.GetOrdinal("cpfUser"));
                usr.LoginUser = leitor.GetString(leitor.GetOrdinal("loginUser"));
                usr.SenhaUser = leitor.GetString(leitor.GetOrdinal("senhaUser"));
                retorno = usr;
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();

            return retorno;
        }



        public void excluirUsuario(Usuario usuario)
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM Usuario WHERE codUser = '?'";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = usuario.CodUser;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        public void alterarUsuario(Usuario usuario, string novasenha)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Usuario (nomeUser, rgUser,cpfUser, loginUser, senhaUser, modoAcesso) values (?, ?, ?, ?, ?) WHERE codUser = ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.NomeUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.RgUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.CpfUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = usuario.LoginUser;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = novasenha;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = usuario.CodUser;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }




        public List<Usuario> listarUsuarios(Usuario filtro)
        {
            throw new NotImplementedException();
        }
    }
}
