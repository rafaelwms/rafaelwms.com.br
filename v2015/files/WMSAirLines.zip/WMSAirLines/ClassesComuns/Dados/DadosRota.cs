﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Odbc;
using System.Data.OleDb;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;

namespace ClassesComuns.Dados
{
    class DadosRota : ConexaoODBC, InterfaceRota
    {


        public void inserirRota(Rota rota)
        {
            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();
            try
            {

                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Rota (nomeRota, milhasRota, minRota) values (?, ?, ?)";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = rota.NomeRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.MilhasRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.MinRota;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                trans1.Rollback();
                throw new Exception(ex.Message);
            }

        }

        public List<Rota> listarRotas()
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT codRota, nomeRota, milhasRota, minRota from Rota";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Rota> retorno = new List<Rota>();
                while (leitor.Read())
                {
                    Rota rota = new Rota();
                    rota.CodRota = leitor.GetInt32(leitor.GetOrdinal("codRota"));
                    rota.NomeRota = leitor.GetString(leitor.GetOrdinal("nomeRota"));
                    rota.MilhasRota = leitor.GetInt32(leitor.GetOrdinal("milhasRota"));
                    rota.MinRota = leitor.GetInt32(leitor.GetOrdinal("minRota"));
                    retorno.Add(rota);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }

        public List<Rota> procurarRota(string busca)
        {
            busca += "%";
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT codRota, nomeRota, milhasRota, minRota from Rota WHERE nomeRota like ?";
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = busca;
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Rota> retorno = new List<Rota>();
                while (leitor.Read())
                {
                    Rota rota = new Rota();
                    rota.CodRota = leitor.GetInt32(leitor.GetOrdinal("codRota"));
                    rota.NomeRota = leitor.GetString(leitor.GetOrdinal("nomeRota"));
                    rota.MilhasRota = leitor.GetInt32(leitor.GetOrdinal("milhasRota"));
                    rota.MinRota = leitor.GetInt32(leitor.GetOrdinal("minRota"));
                    retorno.Add(rota);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void alterarRota(Rota rota)
        {

            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();
            try
            {
                
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Rota set nomeRota = ?, milhasRota = ?, minRota = ? WHERE codRota = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = rota.NomeRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.MilhasRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.MinRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirRota(Rota rota)
        {


            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();

            try
            {

                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM TrechosDaRota WHERE codRota = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();

            try
            {
                
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM Rota WHERE codRota = ?";
                comando.Connection = conn2;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void inserirTrechoDaRota(Rota rota, int numTrecho, Trecho trecho)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO TrechosDaRota (codRota, numTrecho, codTrecho) values (?, ?, ?)";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = numTrecho;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.CodTrecho;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void removerTrechoDaRota(Rota rota, Trecho trecho)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM TrechosDaRota WHERE codRota = ? ADN codTrecho = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = trecho.CodTrecho;
                comando.ExecuteNonQuery();
                this.fecharConexaoOdbc();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Trecho> listarTrechosDaRota(Rota rota)
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT TrechosDaRota.codTrecho, Trecho.nomeTrecho, Trecho.milhasTrecho, Trecho.minTrecho, Origem.codAeroporto AS codOrigem, Origem.nomeAeroporto AS nomeOrigem, Origem.cidadeAeroporto AS cidadeOrigem, Origem.ufAeroporto AS ufOrigem, Origem.siglaAeroporto AS siglaOrigem, Destino.codAeroporto AS codDestino, Destino.nomeAeroporto AS nomeDestino, Destino.cidadeAeroporto AS cidadeDestino, Destino.ufAeroporto AS ufDestino, Destino.siglaAeroporto AS siglaDestino FROM TrechosDaRota INNER JOIN Trecho ON TrechosDaRota.codTrecho = Trecho.codTrecho INNER JOIN Aeroporto AS Origem ON Trecho.origem = Origem.codAeroporto INNER JOIN Aeroporto AS Destino ON Trecho.destino = Destino.codAeroporto WHERE TrechosDaRota.codRota = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Trecho> retorno = new List<Trecho>();
                while (leitor.Read())
                {
                    Trecho trecho = new Trecho();
                    trecho.CodTrecho = leitor.GetInt32(leitor.GetOrdinal("codTrecho"));
                    trecho.NomeTrecho = leitor.GetString(leitor.GetOrdinal("nomeTrecho"));
                    trecho.Milhas = leitor.GetInt32(leitor.GetOrdinal("milhasTrecho"));
                    trecho.MinTrecho = leitor.GetInt32(leitor.GetOrdinal("minTrecho"));

                    Aeroporto origem = new Aeroporto();
                    origem.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("codOrigem"));
                    origem.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("nomeOrigem"));
                    origem.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("cidadeOrigem"));
                    origem.UfAeroporto = leitor.GetString(leitor.GetOrdinal("ufOrigem"));
                    origem.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("siglaOrigem"));
                    trecho.Origem = origem;

                    Aeroporto destino = new Aeroporto();
                    destino.CodAeroporto = leitor.GetInt32(leitor.GetOrdinal("codDestino"));
                    destino.NomeAeroporto = leitor.GetString(leitor.GetOrdinal("nomeDestino"));
                    destino.CidadeAeroporto = leitor.GetString(leitor.GetOrdinal("cidadeDestino"));
                    destino.UfAeroporto = leitor.GetString(leitor.GetOrdinal("ufDestino"));
                    destino.SiglaAeroporto = leitor.GetString(leitor.GetOrdinal("siglaDestino"));
                    trecho.Destino = destino;

                    retorno.Add(trecho);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Rota> procurarRotaVoo(Rota rot)
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Rota.codRota, Rota.nomeRota, Rota.milhasRota, Rota.minRota FROM  Rota INNER JOIN Voo ON Rota.codRota = Voo.rotaVoo WHERE Rota.codRota = ?";
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rot.CodRota;
                OdbcDataReader leitor = comando.ExecuteReader();
                List<Rota> retorno = new List<Rota>();
                while (leitor.Read())
                {
                    Rota rota = new Rota();
                    rota.CodRota = leitor.GetInt32(leitor.GetOrdinal("codRota"));
                    rota.NomeRota = leitor.GetString(leitor.GetOrdinal("nomeRota"));
                    rota.MilhasRota = leitor.GetInt32(leitor.GetOrdinal("milhasRota"));
                    rota.MinRota = leitor.GetInt32(leitor.GetOrdinal("minRota"));
                    retorno.Add(rota);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public int localizarRotaInserida()
        {
            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT MAX (codRota) FROM Rota";
                OdbcDataReader leitor = comando.ExecuteReader();
                int codRota = 0;
                while (leitor.Read())
                {
                    
                    codRota = leitor.GetInt32(0);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return codRota;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void excluirTodosTrechosdaRota(Rota rota)
        {

            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();

            try
            {

                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "DELETE FROM TrechosDaRota WHERE codRota = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = rota.CodRota;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        
        }
    }
}