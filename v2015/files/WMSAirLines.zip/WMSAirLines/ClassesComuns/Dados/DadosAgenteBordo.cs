﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Controladores;
using System.Data.Odbc;
using System.Data.OleDb;

namespace ClassesComuns.Dados
{
    class DadosAgenteBordo : ConexaoODBC, InterfaceAgenteBordo
    {
        public void inserirAgenteBordo(AgenteBordo agbordo)
        {
            OdbcConnection conn = conexaoOdbc();
            conn.Open();
            OdbcTransaction trans = conn.BeginTransaction();
            try
            {

                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Funcionario (nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo) values (?, ?, ?, ?, ?, ?, ?, ?)";
                comando.Connection = conn;
                comando.Transaction = trans;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.NomeFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.RgFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.CpfFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.LoginFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.SenhaFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.CargoFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Decimal).Value = agbordo.Salario;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 1;
                comando.ExecuteNonQuery();
                trans.Commit();
                conn.Close();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                throw new Exception(ex.Message);
            }
            OdbcConnection conn2 = conexaoOdbc();
            OdbcConnection conn3 = conexaoOdbc();
            conn3.Open();
            OdbcTransaction trans2 = conn3.BeginTransaction();
            try
            {
                conn2.Open();
                OdbcCommand comando2 = conn2.CreateCommand();
                comando2.CommandText = "SELECT MAX (codFunc) FROM Funcionario";
                comando2.Connection = conn2;
                OdbcDataReader leitor = comando2.ExecuteReader();
                List<Funcionario> retorno = new List<Funcionario>();
                while (leitor.Read())
                {
                    agbordo.CodFunc = leitor.GetInt32(0);
                }
                leitor.Close();
                leitor.Dispose();
                conn2.Close();

                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO AgenteBordo (codFunc, enfermeiro, disp) VALUES (?, ?, ?)";
                comando.Connection = conn3;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.CodFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.Enfermeiro;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 1;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn3.Close();

            }
            catch (Exception ex)
            {
                trans2.Rollback();
                throw new Exception(ex.Message);
            }

        }

        public List<AgenteBordo> listarAgsBordo()
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Funcionario.codFunc, Funcionario.nomeFunc, Funcionario.rgFunc, Funcionario.cpfFunc, Funcionario.loginFunc, Funcionario.senhaFunc, Funcionario.cargoFunc, Funcionario.salario, Funcionario.ativo, AgenteBordo.codAgBordo, AgenteBordo.enfermeiro, AgenteBordo.disp FROM Funcionario INNER JOIN AgenteBordo ON Funcionario.codFunc = AgenteBordo.codFunc";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<AgenteBordo> retorno = new List<AgenteBordo>();
                while (leitor.Read())
                {
                    AgenteBordo agbordo = new AgenteBordo();
                    agbordo.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                    agbordo.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFunc"));
                    agbordo.RgFunc = leitor.GetString(leitor.GetOrdinal("rgFunc"));
                    agbordo.CpfFunc = leitor.GetString(leitor.GetOrdinal("cpfFunc"));
                    agbordo.LoginFunc = leitor.GetString(leitor.GetOrdinal("loginFunc"));
                    agbordo.SenhaFunc = leitor.GetString(leitor.GetOrdinal("senhaFunc"));
                    agbordo.CargoFunc = leitor.GetString(leitor.GetOrdinal("cargoFunc"));
                    agbordo.Salario = leitor.GetDecimal(leitor.GetOrdinal("salario"));
                    agbordo.Ativo = leitor.GetInt32(leitor.GetOrdinal("ativo"));
                    agbordo.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgBordo"));
                    agbordo.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiro"));
                    agbordo.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                    retorno.Add(agbordo);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public List<AgenteBordo> procurarAgBordo(string busca)
        {

            try
            {
                this.abrirConexaoOdbc();
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "SELECT Funcionario.codFunc, Funcionario.nomeFunc, Funcionario.rgFunc, Funcionario.cpfFunc, Funcionario.loginFunc, Funcionario.senhaFunc, Funcionario.cargoFunc, Funcionario.salario, Funcionario.ativo, AgenteBordo.codAgBordo, AgenteBordo.enfermeiro, AgenteBordo.disp FROM Funcionario INNER JOIN AgenteBordo ON Funcionario.codFunc = AgenteBordo.codFunc WHERE Funcionario.nomeFunc like '%" + busca + "%'";
                OdbcDataReader leitor = comando.ExecuteReader();
                List<AgenteBordo> retorno = new List<AgenteBordo>();
                while (leitor.Read())
                {
                    AgenteBordo agbordo = new AgenteBordo();
                    agbordo.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                    agbordo.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFunc"));
                    agbordo.RgFunc = leitor.GetString(leitor.GetOrdinal("rgFunc"));
                    agbordo.CpfFunc = leitor.GetString(leitor.GetOrdinal("cpfFunc"));
                    agbordo.LoginFunc = leitor.GetString(leitor.GetOrdinal("loginFunc"));
                    agbordo.SenhaFunc = leitor.GetString(leitor.GetOrdinal("senhaFunc"));
                    agbordo.CargoFunc = leitor.GetString(leitor.GetOrdinal("cargoFunc"));
                    agbordo.Salario = leitor.GetDecimal(leitor.GetOrdinal("salario"));
                    agbordo.Ativo = leitor.GetInt32(leitor.GetOrdinal("ativo"));
                    agbordo.CodAgBordo = leitor.GetInt32(leitor.GetOrdinal("codAgBordo"));
                    agbordo.Enfermeiro = leitor.GetInt32(leitor.GetOrdinal("enfermeiro"));
                    agbordo.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                    retorno.Add(agbordo);
                }
                leitor.Close();
                leitor.Dispose();
                this.fecharConexaoOdbc();
                return retorno;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void alterarAgenteBordo(AgenteBordo agbordo)
        {

            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();
            try
            {

                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE  Funcionario set nomeFunc = ?, rgFunc = ?, cpfFunc = ?, loginFunc = ?, senhaFunc = ?, cargoFunc = ?, salario = ?, ativo = ? WHERE codFunc = ?";
                comando.Connection = conn2;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.NomeFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.RgFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.CpfFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.LoginFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.SenhaFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = agbordo.CargoFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Decimal).Value = agbordo.Salario;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.Ativo;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.CodFunc;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
            }
            catch (Exception ex)
            {
                trans2.Rollback();
                throw new Exception(ex.Message);
            }

            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();
            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set enfermeiro = ?, disp = ? WHERE codAgBordo = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.Enfermeiro;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.Disp;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.CodAgBordo;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                trans1.Rollback();
                throw new Exception(ex.Message);
            }
        }

        public void demitirAgBordo(AgenteBordo agbordo)
        {
            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE AgenteBordo set disp = 0 WHERE codAgBordo = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.CodAgBordo;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                trans1.Rollback();
                throw new Exception(ex.Message);
            }

            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();

            try
            {
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Funcionario set disp = 0 WHERE codFunc = ?";
                comando.Connection = conn2;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = agbordo.CodFunc;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
            }
            catch (Exception ex)
            {
                trans2.Rollback();
                throw new Exception(ex.Message);
            }


        }
    }
}
