﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;
using ClassesComuns.Interfaces;
using ClassesComuns.Controladores;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace ClassesComuns.Dados
{
    class DadosPiloto : ConexaoODBC, InterfacePiloto
    {
        public void inserirPiloto(Piloto piloto)
        {
             OdbcConnection conn = conexaoOdbc();
             conn.Open();
             OdbcTransaction trans = conn.BeginTransaction();
            try
            {
                
                
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "INSERT INTO Funcionario (nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo) values (?, ?, ?, ?, ?, ?, ?, ?)";
                comando.Connection = conn;
                comando.Transaction = trans;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.NomeFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.RgFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.CpfFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.LoginFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.SenhaFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.CargoFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Decimal).Value = piloto.Salario;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 1;
                comando.ExecuteNonQuery();
                trans.Commit();
                conn.Close();
            }
            catch (Exception ex)
            {
                trans.Rollback();
                throw new Exception(ex.Message);
            }

            OdbcConnection conn2 = conexaoOdbc();
            OdbcConnection conn3 = conexaoOdbc();
            conn3.Open();
            OdbcTransaction trans2 = conn3.BeginTransaction();
            
            try
            {



                
                conn2.Open();
                OdbcCommand comando2 = conn2.CreateCommand();
                comando2.CommandText = "SELECT MAX (codFunc) FROM Funcionario";
                comando2.Connection = conn2;
                OdbcDataReader leitor = comando2.ExecuteReader();
                List<Funcionario> retorno = new List<Funcionario>();
                while (leitor.Read())
                {
                    piloto.CodFunc = leitor.GetInt32(0);
                }
                leitor.Close();
                leitor.Dispose();
                conn2.Close();


                
                
                
                OdbcCommand comando3 = conn3.CreateCommand();
                comando3.CommandText = "INSERT INTO Piloto (codFunc, breve, horasVooPiloto, disp) values (?, ?, ?, ?)";
                comando3.Connection = conn3;
                comando3.Transaction = trans2;
                comando3.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.CodFunc;
                comando3.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.Breve;
                comando3.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.HorasVoo;
                comando3.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.Disp;
                comando3.ExecuteNonQuery();
                trans2.Commit();
                conn3.Close();

            }
            catch (Exception ex)
            {
                trans2.Rollback();
                throw new Exception(ex.Message);
            }
        }

        public List<Piloto> listarPilotos()
        {
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            comando.CommandText = "SELECT Funcionario.codFunc, Funcionario.nomeFunc, Funcionario.rgFunc, Funcionario.cpfFunc, Funcionario.loginFunc, Funcionario.senhaFunc, Funcionario.cargoFunc, Funcionario.salario, Funcionario.ativo, Piloto.codPiloto, Piloto.breve, Piloto.horasVooPiloto, Piloto.disp FROM Funcionario INNER JOIN Piloto ON Funcionario.codFunc = Piloto.codFunc";
            OdbcDataReader leitor = comando.ExecuteReader();
            List<Piloto> retorno = new List<Piloto>();
            while (leitor.Read())
            {
                Piloto piloto = new Piloto();
                piloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                piloto.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFunc"));
                piloto.RgFunc = leitor.GetString(leitor.GetOrdinal("rgFunc"));
                piloto.CpfFunc = leitor.GetString(leitor.GetOrdinal("cpfFunc"));
                piloto.LoginFunc = leitor.GetString(leitor.GetOrdinal("loginFunc"));
                piloto.SenhaFunc = leitor.GetString(leitor.GetOrdinal("senhaFunc"));
                piloto.CargoFunc = leitor.GetString(leitor.GetOrdinal("cargoFunc"));
                piloto.Salario = leitor.GetDecimal(leitor.GetOrdinal("salario"));
                piloto.Ativo = leitor.GetInt32(leitor.GetOrdinal("ativo"));
                piloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codPiloto"));
                piloto.Breve = leitor.GetString(leitor.GetOrdinal("breve"));
                piloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooPiloto"));
                piloto.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                retorno.Add(piloto);
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();
            return retorno;
        }

        public List<Piloto> procurarPiloto(String busca)
        {
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            comando.CommandText = "SELECT Funcionario.codFunc, Funcionario.nomeFunc, Funcionario.rgFunc, Funcionario.cpfFunc, Funcionario.loginFunc, Funcionario.senhaFunc, Funcionario.cargoFunc, Funcionario.salario, Funcionario.ativo, Piloto.codPiloto, Piloto.breve, Piloto.horasVooPiloto, Piloto.disp FROM Funcionario INNER JOIN Piloto ON Funcionario.codFunc = Piloto.codFunc WHERE Funcionario.nomeFunc like '%"+busca+"%'";
            OdbcDataReader leitor = comando.ExecuteReader();
            List<Piloto> retorno = new List<Piloto>();
            while (leitor.Read())
            {
                Piloto piloto = new Piloto();
                piloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                piloto.NomeFunc = leitor.GetString(leitor.GetOrdinal("nomeFunc"));
                piloto.RgFunc = leitor.GetString(leitor.GetOrdinal("rgFunc"));
                piloto.CpfFunc = leitor.GetString(leitor.GetOrdinal("cpfFunc"));
                piloto.LoginFunc = leitor.GetString(leitor.GetOrdinal("loginFunc"));
                piloto.SenhaFunc = leitor.GetString(leitor.GetOrdinal("senhaFunc"));
                piloto.CargoFunc = leitor.GetString(leitor.GetOrdinal("cargoFunc"));
                piloto.Salario = leitor.GetDecimal(leitor.GetOrdinal("salario"));
                piloto.Ativo = leitor.GetInt32(leitor.GetOrdinal("ativo"));
                piloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codPiloto"));
                piloto.Breve = leitor.GetString(leitor.GetOrdinal("breve"));
                piloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooPiloto"));
                piloto.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                retorno.Add(piloto);
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();
            return retorno;
        }

        public void alterarPiloto(Piloto piloto)
        {



            OdbcConnection conn1 = conexaoOdbc();
            conn1.Open();
            OdbcTransaction trans1 = conn1.BeginTransaction();
            try
            {
               

                OdbcCommand comando = conn1.CreateCommand();
                comando.CommandText = "UPDATE  Funcionario set nomeFunc = ?, rgFunc = ?, cpfFunc = ?, loginFunc = ?, senhaFunc = ?, cargoFunc = ?, salario = ?, ativo = ? WHERE codFunc = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.NomeFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.RgFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.CpfFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.LoginFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.SenhaFunc;
                comando.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.CargoFunc;
                comando.Parameters.AddWithValue("?", OleDbType.Decimal).Value = piloto.Salario;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.CodFunc;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
                
                
            }
            catch (Exception ex)
            {
                trans1.Rollback();
                throw new Exception(ex.Message);
            }

            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();

            try
            {
                

                OdbcCommand comando2 = conn2.CreateCommand();
                comando2.CommandText = "UPDATE Piloto  set breve = ?, horasVooPiloto = ?, disp =? WHERE codPiloto = ?";
                comando2.Connection = conn2;
                comando2.Transaction = trans2;
                comando2.Parameters.AddWithValue("?", OleDbType.VarChar).Value = piloto.Breve;
                comando2.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.HorasVoo;
                comando2.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.Disp;
                comando2.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.CodPiloto;
                comando2.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
                
            }
            catch (Exception ex)
            {
                trans2.Rollback();
                throw new Exception(ex.Message);
            }

        }

        public void demitirPiloto(Piloto piloto)
        {
                OdbcConnection conn1 = conexaoOdbc();
                conn1.Open();
                OdbcTransaction trans1 = conn1.BeginTransaction();
            try
            {
                
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE Piloto set disp = ? WHERE codPiloto = ?";
                comando.Connection = conn1;
                comando.Transaction = trans1;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 0;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.CodPiloto;
                comando.ExecuteNonQuery();
                trans1.Commit();
                conn1.Close();
            }
            catch (Exception ex)
            {
                trans1.Rollback();
                throw new Exception(ex.Message);
            }

            OdbcConnection conn2 = conexaoOdbc();
            conn2.Open();
            OdbcTransaction trans2 = conn2.BeginTransaction();
            try
            {
                
                OdbcCommand comando = conn.CreateCommand();
                comando.CommandText = "UPDATE  Funcionario set ativo = ? WHERE codFunc = ?";
                comando.Connection = conn2;
                comando.Transaction = trans2;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = 0;
                comando.Parameters.AddWithValue("?", OleDbType.Integer).Value = piloto.CodFunc;
                comando.ExecuteNonQuery();
                trans2.Commit();
                conn2.Close();
                
            }
            catch (Exception ex)
            {
                trans2.Rollback();
                throw new Exception(ex.Message);
            }




        }

        public List<Piloto> listarPilotosVoo(int cod)
        {
            this.abrirConexaoOdbc();
            OdbcCommand comando = conn.CreateCommand();
            comando.CommandText = "SELECT Piloto.codFunc, Piloto.codPiloto, Piloto.breve, Piloto.horasVooPiloto, Piloto.disp FROM Piloto INNER JOIN Voo ON Piloto.codPiloto = Voo.piloto AND Piloto.codPiloto = Voo.copiloto WHERE Piloto.codPiloto = @codpiloto";
            comando.Parameters.AddWithValue("@codpiloto", cod);
            OdbcDataReader leitor = comando.ExecuteReader();
            List<Piloto> retorno = new List<Piloto>();
            while (leitor.Read())
            {
                Piloto piloto = new Piloto();
                piloto.CodFunc = leitor.GetInt32(leitor.GetOrdinal("codFunc"));
                piloto.CodPiloto = leitor.GetInt32(leitor.GetOrdinal("codPiloto"));
                piloto.Breve = leitor.GetString(leitor.GetOrdinal("breve"));
                piloto.HorasVoo = leitor.GetInt32(leitor.GetOrdinal("horasVooPiloto"));
                piloto.Disp = leitor.GetInt32(leitor.GetOrdinal("disp"));
                retorno.Add(piloto);
            }
            leitor.Close();
            leitor.Dispose();
            this.fecharConexaoOdbc();
            return retorno;
        }


    }
}

