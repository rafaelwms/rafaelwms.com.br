﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceAeronave
    {

        void inserirAeronave(Aeronave nave);

        List<Aeronave> listarAeronaves();

        List<Aeronave> procurarAeronave(String busca);

        void alterarAeronave(Aeronave nave);

        void excluirAeronave(Aeronave nave);
                
    }
}
