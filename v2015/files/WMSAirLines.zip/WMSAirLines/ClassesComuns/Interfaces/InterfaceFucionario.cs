﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceFucionario
    {

        void inserirFuncionario(Funcionario func);

        List<Funcionario> listarFuncionarios();

        List<Funcionario> procurarFuncionario(String busca);

        void alterarFucionario(Funcionario func);

        void demitirFuncionario(Funcionario func);

    }
}
