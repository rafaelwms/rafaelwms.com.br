﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceTrecho
    {

        void inserirTrecho(Trecho trecho);

        List<Trecho> listarTrechos();

        List<Trecho> procurarTrecho(String busca);

        void alterarTrecho(Trecho trecho);

        void excluirTrecho(Trecho trecho);

    }
}
