﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceVoo
    {

        void inserirVoo(Voo voo);

        void alterarVoo(Voo voo);

        void excluirVoo(Voo voo);

        List<Voo> listarVoos();

        List<Voo> procurarVoo(String busca);

        void confirmarDecolagem(Voo voo);

        void confirmarAterrissagem(Voo voo);

    }
}
