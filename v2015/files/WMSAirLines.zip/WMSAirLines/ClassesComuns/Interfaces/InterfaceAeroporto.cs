﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceAeroporto
    {

        void inserirAeroporto(Aeroporto porto);

        List<Aeroporto> listarAeroportos();

        List<Aeroporto> procurarAeroporto(String busca);

        void alterarAeroporto(Aeroporto porto);

        void excluirAeroporto(Aeroporto porto);


    }
}
