﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceUsuario
    {

        void inserirUsuario(Usuario usuario);

        List<Usuario> listarUsuarios(Usuario filtro);

        Usuario procurarUsuario(Usuario usuario);

        void alterarUsuario(Usuario usuario, String novasenha);

        void excluirUsuario(Usuario usuario);

    }
}
