﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceRota
    {

        void inserirRota(Rota rota);

        List<Rota> listarRotas();

        List<Rota> procurarRota(String busca);

        void alterarRota(Rota rota);

        void excluirRota(Rota rota);

        void inserirTrechoDaRota(Rota rota, int numTrecho, Trecho trecho);

        void removerTrechoDaRota(Rota rota, Trecho trecho);

        List<Trecho> listarTrechosDaRota(Rota rota);

        int localizarRotaInserida();

    }
}
