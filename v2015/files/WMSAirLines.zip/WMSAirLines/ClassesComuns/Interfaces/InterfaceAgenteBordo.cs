﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceAgenteBordo
    {

        void inserirAgenteBordo(AgenteBordo agbordo);

        List<AgenteBordo> listarAgsBordo();

        List<AgenteBordo> procurarAgBordo(String busca);

        void alterarAgenteBordo(AgenteBordo agbordo);

        void demitirAgBordo(AgenteBordo agbordo);

    }
}
