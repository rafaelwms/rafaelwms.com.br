﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfaceAgenteLocal
    {

        void inserirAgLocal(AgenteLocal aglocal);

        List<AgenteLocal> listarAgsLocal();

        List<AgenteLocal> procurarAgLocal(String busca);

        void alterarAgLocal(AgenteLocal aglocal);

        void demitirAgLocal(AgenteLocal aglocal);



    }
}
