﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassesComuns.Basicas;

namespace ClassesComuns.Interfaces
{
    interface InterfacePiloto
    {

        void inserirPiloto(Piloto piloto);

        List<Piloto> listarPilotos();

        List<Piloto> procurarPiloto(String busca);

        void alterarPiloto(Piloto piloto);

        void demitirPiloto(Piloto piloto);


    }
}
