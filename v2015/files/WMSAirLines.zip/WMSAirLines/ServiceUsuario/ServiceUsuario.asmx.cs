﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using ClassesComuns.Basicas;
using ClassesComuns.Controladores;

namespace ServiceUsuario
{
    /// <summary>
    /// Summary description for Service1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ServiceUsuario : System.Web.Services.WebService
    {



        [WebMethod]
        public void alterarUsuario(Usuario usuario, String novasenha)
        {
            try
            {
                ControladorUsuario ctl = new ControladorUsuario();
                ctl.alterarUsuario(usuario, novasenha);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        [WebMethod]
        public void excluirUsuario(Usuario usuario)
        {
            try
            {
                ControladorUsuario ctl = new ControladorUsuario();
                ctl.excluirUsuario(usuario);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        [WebMethod]
        public List<Usuario> listarUsuarios()
        {
            try
            {
                ControladorUsuario ctl = new ControladorUsuario();
                List<Usuario> usuarios = new List<Usuario>();
                usuarios = ctl.listarUsuarios(new Usuario());
                return usuarios;
            }
            catch (Exception ex) 
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirUsuario(Usuario usuario)
        {
            try
            {
                ControladorUsuario ctl = new ControladorUsuario();
                ctl.inserirUsuario(usuario);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public Usuario procurarUsuarios(Usuario usuario)
        {
            try
            {
                ControladorUsuario ctl = new ControladorUsuario();
                return ctl.procurarUsuario(usuario);
                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}