--CREATE DATABASE WMSAIRLINES
--GO 

--USE WMSAIRLINES

--CREATE TABLE Aeronave(
--codAeronave int primary key identity,
--idAeronave varchar (10) not null,
--apelidoAeronave varchar (30) not null,
--modeloAeronave varchar (30) not null,
--qtdPoltronas int not null,
--milhas int not null,
--patio int not null)

----select * from Aeronave

--CREATE TABLE Aeroporto(
--codAeroporto int primary key identity,
--nomeAeroporto varchar (30) not null,
--cidadeAeroporto varchar (30) not null,
--ufAeroporto char (2) not null,
--siglaAeroporto char (3) not null)

----select * from Aeroporto

--CREATE TABLE Trecho(
--codTrecho int primary key identity,
--nomeTrecho varchar (7) not null,
--origem int not null,
--destino int not null,
--milhasTrecho int not null,
--minTrecho int not null,
--foreign key (origem) references Aeroporto,
--foreign key (destino) references Aeroporto)

----select * from Trecho

--CREATE TABLE Rota(
--codRota int primary key identity,
--nomeRota varchar (30) not null,
--milhasRota int not null,
--minRota int not null)

--CREATE TABLE TrechosDaRota(
--codRota int not null,
--numTrecho int not null,
--codTrecho int not null,
--primary key (codRota, codTrecho),
--foreign key (codRota) references Rota,
--foreign key (codTrecho) references trecho)

----select * from TrechosDaRota

--CREATE TABLE Funcionario(
--codFunc int primary key identity,
--nomeFunc varchar (100) not null,
--rgFunc varchar (13) not null,
--cpfFunc varchar (15) not null,
--loginFunc varchar (20) not null,
--senhaFunc varchar (20) not null,
--cargoFunc varchar (20) not null,
--salario decimal (10,2) not null,
--ativo int not null)

----select * from Funcionario

--CREATE TABLE Piloto(
--codFunc int,
--codPiloto int identity,
--breve varchar (20) not null,
--horasVooPiloto int not null,
--disp int not null
--primary key (codPiloto)
--foreign key (codFunc) references Funcionario)

----select * from Piloto

--CREATE TABLE AgenteBordo(
--codFunc int,
--codAgBordo int identity,
--enfermeiro int not null,
--disp int not null
--primary key (codAgBordo)
--foreign key (codFunc) references Funcionario)

----select * from AgenteBordo

--CREATE TABLE AgenteLocal(
--codFunc int,
--codAgLocal int identity,
--posicao varchar (30)
--primary key (codAglocal)
--foreign key (codFunc) references Funcionario)


--CREATE TABLE Usuario(
--codUser int primary key identity,
--nomeUser varchar (100) not null,
--rgUser varchar (13) not null,
--cpfUser varchar (15) not null,
--loginUser varchar (20) not null,
--senhaUser varchar (20) not null)


--CREATE TABLE Voo(
--codVoo int primary key identity,
--numVoo int not null,
--rotaVoo int not null,
--naveVoo int not null,
--piloto int not null,
--copiloto int not null,
--agentea int not null,
--agenteb int not null,
--agentec int not null,
--agented int not null,
--dataVoo varchar (10) not null,
--horaVoo varchar (5) not null,
--foreign key (rotaVoo) references Rota,
--foreign key (naveVoo) references Aeronave,
--foreign key (piloto) references Piloto,
--foreign key (copiloto) references Piloto,
--foreign key (agentea) references AgenteBordo,
--foreign key (agenteb) references AgenteBordo,
--foreign key (agentec) references AgenteBordo,
--foreign key (agented) references AgenteBordo)

--INSERT INTO Funcionario (nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo) values ('Rafael RH', '5307268', '030.328.534-60', 'wms.rh', 'wmsrh', 'RH', 5000.00, 1)
--INSERT INTO Funcionario (nomeFunc, rgFunc, cpfFunc, loginFunc, senhaFunc, cargoFunc, salario, ativo) values ('Rafael ADM', '5307268', '030.328.534-60', 'wms.adm', 'wmsadm', 'Ag Administrativo', 5000.00, 1)