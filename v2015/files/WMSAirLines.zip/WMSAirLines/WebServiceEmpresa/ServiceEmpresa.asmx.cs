﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using ClassesComuns.Basicas;
using ClassesComuns.Controladores;

namespace WebServiceEmpresa
{
    /// <summary>
    /// Summary description for ServiceEmpresa
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class ServiceEmpresa : System.Web.Services.WebService
    {

        [WebMethod]
        public void inserirFuncionario(Funcionario func)
        {
            try
            {
                ControladorFuncionario ctl = new ControladorFuncionario();
                ctl.inserirFuncionario(func);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        [WebMethod]
        public void demitirFuncionario(Funcionario func)
        {
            try
            {
                ControladorFuncionario ctl = new ControladorFuncionario();
                ctl.demitirFuncionario(func);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        [WebMethod]
        public void alterarFuncionario(Funcionario func)
        {
            try
            {
                ControladorFuncionario ctl = new ControladorFuncionario();
                ctl.alterarFucionario(func);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        [WebMethod]
        public List<Funcionario> listarFuncionarios()
        {
            try
            {
                List<Funcionario> funcs = new List<Funcionario>();
                ControladorFuncionario ctl = new ControladorFuncionario();
                funcs = ctl.listarFuncionarios();
                return funcs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Funcionario> procurarFuncionarios(String busca)
        {
            try
            {
                List<Funcionario> funcs = new List<Funcionario>();
                ControladorFuncionario ctl = new ControladorFuncionario();
                funcs = ctl.procurarFuncionario(busca);
                return funcs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirPiloto(Piloto piloto)
        {
            try
            {
                ControladorPiloto ctl = new ControladorPiloto();
                ctl.inserirPiloto(piloto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        [WebMethod]
        public void alterarPiloto(Piloto piloto)
        {
            try
            {
                ControladorPiloto ctl = new ControladorPiloto();
                ctl.alterarPiloto(piloto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        [WebMethod]
        public void demitirPiloto(Piloto piloto)
        {
            try
            {
                ControladorPiloto ctl = new ControladorPiloto();
                ctl.demitirPiloto(piloto);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        [WebMethod]
        public List<Piloto> listarPilotos()
        {
            try
            {
                List<Piloto> lst = new List<Piloto>();
                ControladorPiloto ctl = new ControladorPiloto();
                lst = ctl.listarPilotos();
                return lst;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Piloto> procurarPilotos(String busca)
        {
            try
            {
                List<Piloto> lst = new List<Piloto>();
                ControladorPiloto ctl = new ControladorPiloto();
                lst = ctl.procurarPiloto(busca);
                return lst;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirAeronave(Aeronave nave)
        {
            try
            {
                ControladorAeronave ctl = new ControladorAeronave();
                ctl.inserirAeronave(nave);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void alterarAeronave(Aeronave nave)
        {
            try
            {
                ControladorAeronave ctl = new ControladorAeronave();
                ctl.alterarAeronave(nave);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void excluirAeronave(Aeronave nave)
        {
            try
            {
                ControladorAeronave ctl = new ControladorAeronave();
                ctl.excluirAeronave(nave);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Aeronave> listarAeronaves()
        {
            try
            {
                List<Aeronave> lista = new List<Aeronave>();
                ControladorAeronave ctl = new ControladorAeronave();
                lista = ctl.listarAeronaves();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<Aeronave> procurarAeronave(String busca)
        {
            try
            {
                List<Aeronave> lista = new List<Aeronave>();
                ControladorAeronave ctl = new ControladorAeronave();
                lista = ctl.procurarAeronave(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void inserirAgenteBordo(AgenteBordo agbordo)
        {
            try
            {
                ControladorAgenteBordo ctl = new ControladorAgenteBordo();
                ctl.inserirAgenteBordo(agbordo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void alterarAgenteBordo(AgenteBordo agbordo)
        {
            try
            {
                ControladorAgenteBordo ctl = new ControladorAgenteBordo();
                ctl.alterarAgenteBordo(agbordo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public void demitirAgBordo(AgenteBordo agbordo)
        {
            try
            {
                ControladorAgenteBordo ctl = new ControladorAgenteBordo();
                ctl.demitirAgBordo(agbordo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<AgenteBordo> listarAgsBordo()
        {
            try
            {
                List<AgenteBordo> lista = new List<AgenteBordo>();
                ControladorAgenteBordo ctl = new ControladorAgenteBordo();
                lista = ctl.listarAgsBordo();
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        [WebMethod]
        public List<AgenteBordo> procurarAgsBordo(String busca)
        {
            try
            {
                List<AgenteBordo> lista = new List<AgenteBordo>();
                ControladorAgenteBordo ctl = new ControladorAgenteBordo();
                lista = ctl.procurarAgBordo(busca);
                return lista;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}
