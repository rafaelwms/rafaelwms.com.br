<?php

require_once 'Banco.php';
require 'ClasseCategoria.php';
require 'InterfaceCategoria.php';

class RepositorioCategoria implements InterfaceCategoria{

    public function addCategoria(Categoria $categoria) {

        $sql = "INSERT INTO categoria (nomeCategoria) values ('" . $categoria->getNomeCategoria() . "')";
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function updCategoria(Categoria $categoria) {

        $sql = "UPDATE categoria SET nomeCategoria = '" . $categoria->getNomeCategoria() . "' WHERE codCategoria = " . $categoria->getCodCategoria();
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function delCategoria(Categoria $categoria) {
        try{
        $sql = "DELETE FROM categoria WHERE codCategoria = " . $categoria->getCodCategoria();
        $bd = new Banco();
        $bd->gerenciarbd($sql);
        }catch (ErrorException $x){
            throw new Exception($x->getMessage());
        }
    }

    public function listCategoria() {

        $sql = "SELECT codCategoria, nomeCategoria FROM categoria ORDER BY nomeCategoria";
        $bd = new Banco();
        $res = $bd->listarbd($sql);
        $retorno = array();
        while ($lin = mysql_fetch_assoc($res)) {
            $retorno[] = $lin;
        }
        return $retorno;
    }

    
    public function consisCat($par1, $par2) {
                $sql = $par1.$par2;
                $bd = new Banco();
                $res = $bd->listarbd($sql);
                $retorno = array();
                while ($lin = mysql_fetch_assoc($res)) {
                    $retorno[] = $lin;
                }
                return $retorno;
            }
    
    
}
