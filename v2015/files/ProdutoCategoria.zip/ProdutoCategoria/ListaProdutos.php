<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Bem Vindo a WMS GuitarShop</title>
    </head>

    <body bgcolor="grey" background="JPG\LOGO.jpg">
        <font face="arial">


        <?php
        require_once 'RepositorioProduto.php';
        $repProduto = new RepositorioProduto();
        $produtinhos = $repProduto->listProduto();
        foreach ($produtinhos as $value) {
            echo '<table border="2" width="800" align="center">';
            if (!$value['figuraProduto'] == ""){
            echo '<tr><td align=center bgcolor="white"><img src="JPG/' . $value['figuraProduto'] . '" width="780"/>"</td></tr>';
            }
            echo '<tr><td align=center bgcolor="white">NOME: <b>' . $value['nomeProduto'] . '</b> - MARCA: <b>'.$value['nomeMarca'].'</b> - CATEGORIA: <b>'.$value['nomeCategoria'].'</b> - PREÇO R$: <b>'.$value['precoProduto'].'</b></td></tr>';
            if (!$value['descProduto'] == ""){
                echo '<tr><td align="center" bgcolor="white">'.$value['descProduto'].'</td></tr>';
            }
            
            echo '</table> <br/><br/>';
        }
        ?>

        </font>
    </body>
</html>