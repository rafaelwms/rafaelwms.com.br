<?php


class Produto {

    private $categoria;
    private $marca;
    private $codProduto;
    private $nomeProduto;
    private $descProduto;
    private $figuraProduto;
    private $precoProduto;

    public function __construct() {
        $this->categoria = new Categoria();
        $this->marca = new Marca();
    }

    public function setCategoria(Categoria $categoria) {
        $this->categoria = $categoria;
    }

    public function getCategoria() {
        return $this->categoria;
    }

    public function setMarca(Marca $marca) {
        $this->marca = $marca;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function setCodProduto($codProduto) {
        $this->codProduto = $codProduto;
    }

    public function getCodProduto() {
        return $this->codProduto;
    }

    public function setNomeProduto($nomeProduto) {
        $this->nomeProduto = $nomeProduto;
    }

    public function getNomeProduto() {
        return $this->nomeProduto;
    }

    public function setDescProduto($descProduto) {
        $this->descProduto = $descProduto;
    }

    public function getDescProduto() {
        return $this->descProduto;
    }

    public function setFiguraProduto($figuraProduto) {
        $this->figuraProduto = $figuraProduto;
    }

    public function getFiguraProduto() {
        return $this->figuraProduto;
    }

    public function setPrecoProduto($precoProduto) {
        $this->precoProduto = $precoProduto;
    }

    public function getPrecoProduto() {
        return $this->precoProduto;
    }

}