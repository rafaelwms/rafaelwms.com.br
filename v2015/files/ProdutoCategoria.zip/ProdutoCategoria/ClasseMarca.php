<?php

class Marca {

    private $codMarca;
    private $nomeMarca;
    
    public function setCodMarca($codMarca){
        $this->codMarca = $codMarca;
    }

    public function getCodMarca(){
        return $this->codMarca;
    }
    
    public function setNomeMarca($nomeMarca){
        $this->nomeMarca = $nomeMarca;
    }
    
    public function getNomeMarca(){
        return $this->nomeMarca;
    }
    
    
}