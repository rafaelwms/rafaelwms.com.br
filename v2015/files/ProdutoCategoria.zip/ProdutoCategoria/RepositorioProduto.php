<?php

require_once 'Banco.php';
require_once 'ClasseCategoria.php';
require_once 'ClasseMarca.php';
require_once 'ClasseProduto.php';
require 'InterfaceProduto.php';

class RepositorioProduto implements InterfaceProduto {

    public function addProduto(Produto $produto) {

        $sql = "INSERT INTO produto (codCategoria, codMarca, nomeProduto, descProduto, figuraProduto, precoProduto) 
            values (" . $produto->getCategoria()->getCodCategoria() . ", " . $produto->getMarca()->getCodMarca() .
                ", '" . $produto->getNomeProduto() . "', '" . $produto->getDescProduto() . "', 
                '" . $produto->getFiguraProduto() . "', '" . $produto->getPrecoProduto() . "')";
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function updProduto(Produto $produto) {

        $sql = "UPDATE produto SET nomeProduto = '" . $produto->getNomeProduto() . "', descProduto = '" . $produto->getDescProduto() . "', 
            figuraProduto = '" . $produto->getFiguraProduto() . "', precoProduto = '" . $produto->getPrecoProduto() . "' WHERE codProduto = " . $produto->getCodProduto();
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function delProduto(Produto $produto) {

        $sql = "DELETE FROM produto WHERE codProduto = " . $produto->getCodProduto();
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function listProduto() {

        $sql = "SELECT produto.codCategoria, produto.codMarca, produto.codProduto, produto.nomeProduto, 
            produto.descProduto, produto.figuraProduto, produto.precoProduto, categoria.nomeCategoria, 
            marca.nomeMarca FROM produto INNER JOIN marca ON produto.codMarca = marca.codMarca INNER JOIN 
            categoria ON produto.codCategoria = categoria.codCategoria ORDER BY produto.nomeProduto";
        $bd = new Banco();
        $res = $bd->listarbd($sql);
        $retorno = array();
        while ($lin = mysql_fetch_assoc($res)) {
            $retorno[] = $lin;
        }
        return $retorno;
    }

    public function consProd(Produto $produto) {

        $sql = "SELECT codProduto FROM produto WHERE nomeProduto = '" . $produto->getNomeProduto() . "'";
        $bd = new Banco();
        $res = $bd->listarbd($sql);
        $retorno = array();
        while ($lin = mysql_fetch_assoc($res)) {
            $retorno[] = $lin;
        }
        return $retorno;
    }

}