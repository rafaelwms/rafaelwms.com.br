<?php
session_start();
require 'RepositorioMarca.php';
$_SESSION['fbmarcas'];
if (!isset($_SESSION['fbmarcas'])){
    $_SESSION['fbmarcas'] = "";
}

$nomeMarca = $_POST['nomeMarca'];

$marca = new Marca();
$repMarca = new RepositorioMarca();
$marca->setNomeMarca($nomeMarca);
$repMarca->addMarca($marca);


    $_SESSION['fbmarcas'] = "Marca ".$marca->getNomeMarca()." adicionada com êxito.";
header('location: index.php');
?>
