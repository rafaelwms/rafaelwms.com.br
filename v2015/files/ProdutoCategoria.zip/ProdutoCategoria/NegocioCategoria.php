<?php

require_once 'RepositorioCategoria.php';
require_once 'ClasseCategoria.php';
require_once 'InterfaceCategoria.php';

class NegocioCategoria implements InterfaceCategoria {

    public function addCategoria(\Categoria $categoria) {
        $repCategoria = new RepositorioCategoria();
        try {

            if (trim($categoria->getNomeCategoria()) === "") {
                throw new Exception("Digite algum valor para ser inserido.");
            }

            $par1 = "SELECT codCategoria FROM categoria ";
            $par2 = "WHERE nomeCategoria = '" . $categoria->getNomeCategoria() . "'";
            $consist = $repCategoria->consisCat($par1, $par2);
            if (empty($consist) == false) {
                throw new Exception("Nome de categoria já existente.");
            }


            $repCategoria->addCategoria($categoria);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function delCategoria(\Categoria $categoria) {
        $repCategoria = new RepositorioCategoria();
        try {
            $par1 = "SELECT codProduto FROM produto ";
            $par2 = "WHERE codCategoria = " . $categoria->getCodCategoria();
            $consist = $repCategoria->consisCat($par1, $par2);
            if (empty($consist) == false) {
                throw new Exception("Categoria associada a algum produto registrado.");
            }

            $repCategoria->delCategoria($categoria);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function listCategoria() {
        $repCategoria = new RepositorioCategoria();
        try {
            $repCategoria->listCategoria();
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function updCategoria(\Categoria $categoria) {
        $repCategoria = new RepositorioCategoria();
        try {

            if (trim($categoria->getCodCategoria()) === "-1") {
                throw new Exception("Selecione uma categoria para atualizar");
            }

            if (trim($categoria->getNomeCategoria()) === "") {
                throw new Exception("Digite algum valor para se atualizar");
            }

            $par1 = "SELECT codCategoria FROM categoria ";
            $par2 = "WHERE nomeCategoria = '" . $categoria->getNomeCategoria() . "'";
            $consist = $repCategoria->consisCat($par1, $par2);
            if (empty($consist) == false) {
                throw new Exception("Nome de categoria já existente.");
            }

            $repCategoria->updCategoria($categoria);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

}

