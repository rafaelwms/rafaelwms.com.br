<?php

require_once 'RepositorioMarca.php';
require_once 'ClasseMarca.php';
require_once 'InterfaceMarca.php';

class NegocioMarca implements InterfaceMarca {

    public function addMarca(\Marca $marca) {
        $repMarca = new RepositorioMarca();
        try {
            
            if(trim($marca->getNomeMarca()) === ""){
                throw new Exception("Digite algum valor para ser inserido.");
            }
            
            $par1 = "SELECT codMarca FROM marca ";
            $par2 = "WHERE nomeMarca = '".$marca->getNomeMarca()."'";
            $consist = $repMarca->consisMar($par1, $par2);
            if (empty($consist) == false) {
                throw new Exception("Nome de marca já utilizado.");
            }
            
            
            $repMarca->addMarca($marca);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function delMarca(\Marca $marca) {
        $repMarca = new RepositorioMarca();
        try {
            $par1 = "SELECT codProduto FROM produto WHERE codMarca =";
            $par2 = $marca->getCodMarca();
            $consist = $repMarca->consisMar($par1, $par2);
            if (empty($consist) == false) {
                throw new Exception("Marca associada a algum produto registrado.");
            }

            $repMarca->delMarca($marca);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function listMarca() {
        $repMarca = new RepositorioMarca();
        try {
            $repMarca->listMarca();
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function updMarca(\Marca $marca) {
        $repMarca = new RepositorioMarca();
        try {
            
            if(trim($marca->getCodMarca()) === "-1"){
                throw new Exception("Selecione uma marca para atualizar");
            }
            
            if(trim($marca->getNomeMarca())=== ""){
                throw new Exception("Digite algum valor para se atualizar");
            }
            
            $par1 = "SELECT codMarca FROM marca ";
            $par2 = "WHERE nomeMarca = '".$marca->getNomeMarca()."'";
            $consist = $repMarca->consisMar($par1, $par2);
            if (empty($consist) == false) {
                throw new Exception("Nome de marca já utilizado.");
            }
            
            $repMarca->updMarca($marca);
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

}
