<?php

 class Categoria {

    private $codCategoria;
    private $nomeCategoria;

    public function setCodCategoria($codCategoria) {
        $this->codCategoria = $codCategoria;
    }

    public function getCodCategoria() {
        return $this->codCategoria;
    }

    public function setNomeCategoria($nomeCategoria) {
        $this->nomeCategoria = $nomeCategoria;
    }

    public function getNomeCategoria() {
        return $this->nomeCategoria;
    }

}