<?php session_start() ?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Bem Vindo a WMS GuitarShop</title>
        <script language="JavaScript">
            function listaProd(){
            
                var width = 1024;
                var height = 768;
 
                var left = 99;
                var top = 99;
 
                window.open('ListaProdutos.php','janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');
            
            }
        
        </script>
    </head>

    <body bgcolor="grey" background="JPG\LOGO.jpg">
        
        <table align="center" width="800"><tr><td align=center>
                    <img src="JPG\LOGO.gif"/>
                </td></tr></table>
        
        <table width="800" border="2" align="center">
            <tr bgcolor="white"><td align=center>GERENCIA DE CATEGORIAS</td><td align=center>GERENCIA DE MARCAS</td></tr>
            <tr bgcolor="silver"><td width="400" align=center >
                    <br/>
                    <form method="post" action="Fachada.php">

                        &nbsp <select name="listaCategorias">

                            <option value="-1"> SELECIONE A CATEGORIA </option>

                            <?php
                            require 'RepositorioCategoria.php';
                            $repCategoria = new RepositorioCategoria();
                            $categs = $repCategoria->listCategoria();
                            foreach ($categs as $value) {
                                echo '<option value="' . $value['codCategoria'] . '" > ' . $value['nomeCategoria'] . ' </option>';
                            }
                            ?> 
                        </select>

                        <br/>
                        &nbsp Nome: <input type="text" name="nomeCategoria"/>
                        <br/>
                        <input type="hidden" name="oper" value="grabCat"/>
                        &nbsp<input type="submit" name="addCategoria" value="Inserir">
                        <input type="submit" name="updCategoria" value="Atualizar">
                        <input type="submit" name="delCategoria" value="Deletar">
                    </form>
                    <br>



                </td>


                <td width="400" align=center>

                    <br/>
                    <form method="post" action="Fachada.php">
                        &nbsp  <select name="listaMarcas">
                            <option value="-1"> SELECIONE A MARCA </option>

                            <?php
                            require 'RepositorioMarca.php';
                            $repMarca = new RepositorioMarca();
                            $marcas = $repMarca->listMarca();
                            foreach ($marcas as $value) {
                                echo '<option value="' . $value['codMarca'] . '" > ' . $value['nomeMarca'] . ' </option>';
                            }
                            ?>
                        </select>
                        <br/>
                        &nbsp  Nome:<input type="text" name="nomeMarca"/>
                        <br/>
                        <input type="hidden" name="oper" value="grabMarca"/>
                        &nbsp  <input type="submit" name="addMarca" value="Inserir">
                        <input type="submit" name="updMarca" value="Atualizar">
                        <input type="submit" name="delMarca" value="Deletar">
                    </form>
                    <br>



                </td>
            </tr>
        </table>
        <table align="center" border="2" width="800">
            <tr bgcolor="white"><td align=center> GERENCIA DE PRODUTO </td></tr>
        </table>

        <table align="center" border="2" width="800">
            <tr bgcolor="silver"><td width ="220"> 
                    <form method="post" action="Fachada.php">

                        <br/>
                        &nbsp <select name="prodCategoria">
                            <option value="-1"> SELECIONE A CATEGORIA </option>
                            <?php
                            $pcategs = $repCategoria->listCategoria();
                            foreach ($pcategs as $value) {
                                echo '<option value="' . $value['codCategoria'] . '" > ' . $value['nomeCategoria'] . ' </option>';
                            }
                            ?> 
                        </select>* &nbsp&nbsp&nbsp
                        <select name="prodMarca">
                            <option value="-1"> SELECIONE A MARCA </option>

                            <?php
                            $pmarcas = $repMarca->listMarca();
                            foreach ($pmarcas as $value) {
                                echo '<option value="' . $value['codMarca'] . '" > ' . $value['nomeMarca'] . ' </option>';
                            }
                            ?>
                        </select>* &nbsp&nbsp&nbsp
                        <select name="listaProdutos">
                            <option value="-1"> SELECIONE O PRODUTO </option>

                            <?php
                            require 'RepositorioProduto.php';
                            $repProduto = new RepositorioProduto();
                            $produtos = $repProduto->listProduto();
                            foreach ($produtos as $value) {
                                echo '<option value="' . $value['codProduto'] . '" > ' . $value['nomeProduto'] . ', Preço R$: ' . $value['precoProduto'] . ' </option>';
                            }
                            ?>
                        </select> + <br/><br/>

                        &nbsp   Nome: <input type="text" name="nomeProduto"/> * +
                        &nbsp&nbsp&nbsp Descrição: <input type="text" name="descProduto"/>                      
                        &nbsp&nbsp&nbsp Preço: <input type="text" name="precoProduto"/> * +<br/><br/>
                        &nbsp   Imagem:  <input type="file" name="figuraProduto"/>


                        <input type="hidden" name="oper" value="grabProduto"/>
                        <input type="submit" name="addProduto" value="Inserir"/> 
                        <input type="submit" name="updProduto" value="Alterar"/>
                        <input type="submit" name="delProduto" value="Deletar"/> 
                        <br/>
                        <br/>
                    </form>
                    * Campos Obrigatórios para INSERÇÃO. &nbsp&nbsp&nbsp&nbsp + Campos obrigatórios para ALTERAÇÃO.       

                    &nbsp&nbsp&nbsp&nbsp<button onclick="listaProd()">LISTAR PRODUTOS</button>
                </td></tr>
        </table>
        <table align="center" border="2" width="800">
            <tr ><td bgcolor="white" align=center>
                    &nbsp  
                    <?php
                    if (isset($_SESSION['msgs'])) {
                        echo $_SESSION['msgs'];
                    }
                    $_SESSION['msgs'] = " ";
                    ?>
                </td></tr>
        </table>
        
    </body>
</html>
