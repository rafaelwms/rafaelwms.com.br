<?php

require_once 'RepositorioProduto.php';
require_once 'ClasseProduto.php';
require_once 'InterfaceProduto.php';

class NegocioProduto implements InterfaceProduto {

    public function addProduto(\Produto $produto) {
        $repProduto = new RepositorioProduto();
        try {

            if ($produto->getCategoria()->getCodCategoria() === "-1") {
                throw new Exception("É necessário selecionar uma categoria.");
            }

            if ($produto->getMarca()->getCodMarca() === "-1") {
                throw new Exception("É necessário selecionar uma marca.");
            }

            if (trim($produto->getNomeProduto()) === "") {
                throw new Exception("É necessário digitar um nome para o produto.");
            }

            if (trim($produto->getPrecoProduto()) === "") {
                throw new Exception("É necessário digitar um preço para o produto.");
            }

            if (!is_numeric(trim($produto->getPrecoProduto()))) {
                throw new Exception("O campo de preço só pode ser preenchido com números.");
            }
            
            $consist = $repProduto->consProd($produto);
            if (empty($consist) == false) {
                throw new Exception("Nome do produto já existente.");
            }
            
            $repProduto->addProduto($produto);
            
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function delProduto(\Produto $produto) {
        $repProduto = new RepositorioProduto();
       try {
            
            if($produto->getCodProduto() === "-1"){
                throw new Exception("É necessário selecionar um produto.");
            }
            
            $repProduto->delProduto($produto);
            
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

    public function listProduto() {
        
    }

    public function updProduto(\Produto $produto) {
        $repProduto = new RepositorioProduto();

        try {
            
            if($produto->getCodProduto() === "-1"){
                throw new Exception("É necessário selecionar um produto.");
            }
            
            if (trim($produto->getNomeProduto()) === "") {
                throw new Exception("É necessário digitar um nome para o produto.");
            }

            if (trim($produto->getPrecoProduto()) === "") {
                throw new Exception("É necessário digitar um preço para o produto.");
            }

            if (!is_numeric(trim($produto->getPrecoProduto()))) {
                throw new Exception("O campo de preço só pode ser preenchido com números.");
            }
            
                       
            $repProduto->updProduto($produto);
            
        } catch (Exception $x) {
            throw new Exception($x->getMessage());
        }
    }

}
