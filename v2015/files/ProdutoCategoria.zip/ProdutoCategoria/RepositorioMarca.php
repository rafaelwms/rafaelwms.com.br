<?php

require_once 'Banco.php';
require 'ClasseMarca.php';
require 'InterfaceMarca.php';

class RepositorioMarca implements InterfaceMarca {

    public function addMarca(Marca $marca) {

        $sql = "INSERT INTO marca (nomeMarca) values ('" . $marca->getNomeMarca() . "')";
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function updMarca(Marca $marca) {

        $sql = "UPDATE marca SET nomeMarca = '" . $marca->getNomeMarca() . "' WHERE codMarca =" . $marca->getCodMarca();
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function delMarca(Marca $marca) {

        $sql = "DELETE FROM marca WHERE codMarca = " . $marca->getCodMarca();
        $bd = new Banco();
        $bd->gerenciarbd($sql);
    }

    public function listMarca() {

        $sql = "SELECT codMarca, nomeMarca FROM marca ORDER BY nomeMarca";
        $bd = new Banco();
        $res = $bd->listarbd($sql);
        $retorno = array();
        while ($lin = mysql_fetch_assoc($res)) {
            $retorno[] = $lin;
        }
        return $retorno;
    }

    public function consisMar($par1, $par2) {
        $sql = $par1.$par2;
        $bd = new Banco();
        $res = $bd->listarbd($sql);
        $retorno = array();
        while ($lin = mysql_fetch_assoc($res)) {
            $retorno[] = $lin;
        }
        return $retorno;
    }

}