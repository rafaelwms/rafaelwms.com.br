<?php

class Banco {

    public function gerenciarbd($sql) {

        $con = mysql_connect('localhost', 'root', '');
        mysql_select_db('prodcat', $con);
        mysql_query($sql, $con);
        
    }

    public function listarbd($sql) {

        $con = mysql_connect('localhost', 'root', '');
        mysql_select_db('prodcat', $con);
        $res = mysql_query($sql, $con);
        return $res;
        
     //   foreach ($res as $value) {
            
    //    }
        // $result = array();
      //  while ($row = mysql_fetch_array($res)) {
      //      $result[] = $row;
      //  }
      //  return $result;
    }

}







