<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rafael
 */
interface InterfaceCategoria {
   
    public function addCategoria(Categoria $categoria);
    
    public function updCategoria(Categoria $categoria);
    
    public function delCategoria(Categoria $categoria);
    
    public function listCategoria();
    
}

?>
