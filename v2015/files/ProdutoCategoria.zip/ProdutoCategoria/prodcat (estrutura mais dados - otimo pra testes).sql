-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.27
-- Versão do PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `prodcat`
--
CREATE DATABASE `prodcat` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `prodcat`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `codCategoria` int(11) NOT NULL AUTO_INCREMENT,
  `nomeCategoria` varchar(50) NOT NULL,
  PRIMARY KEY (`codCategoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`codCategoria`, `nomeCategoria`) VALUES
(10, 'Strato'),
(11, 'Les Paul'),
(12, 'Tele'),
(13, 'Semi AcÃºstica'),
(14, 'ViolÃ£o ClÃ¡ssico'),
(15, 'ViolÃ£o Folk'),
(16, 'Thunderbird'),
(17, 'Jaguar'),
(19, 'Mustang'),
(20, 'SG');

-- --------------------------------------------------------

--
-- Estrutura da tabela `marca`
--

CREATE TABLE IF NOT EXISTS `marca` (
  `codMarca` int(11) NOT NULL AUTO_INCREMENT,
  `nomeMarca` varchar(50) NOT NULL,
  PRIMARY KEY (`codMarca`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Extraindo dados da tabela `marca`
--

INSERT INTO `marca` (`codMarca`, `nomeMarca`) VALUES
(21, 'Fender'),
(23, 'Gibson'),
(24, 'Epiphone'),
(25, 'Gretsh'),
(26, 'Gianinni'),
(27, 'Di Giorgio'),
(28, 'Groovin'),
(29, 'Eagle');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE IF NOT EXISTS `produto` (
  `codCategoria` int(11) NOT NULL,
  `codMarca` int(11) NOT NULL,
  `codProduto` int(11) NOT NULL AUTO_INCREMENT,
  `nomeProduto` varchar(150) NOT NULL,
  `descProduto` varchar(500) DEFAULT NULL,
  `figuraProduto` varchar(150) DEFAULT NULL,
  `precoProduto` float NOT NULL,
  PRIMARY KEY (`codProduto`),
  KEY `codMarca` (`codMarca`),
  KEY `codCategoria` (`codCategoria`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`codCategoria`, `codMarca`, `codProduto`, `nomeProduto`, `descProduto`, `figuraProduto`, `precoProduto`) VALUES
(10, 21, 6, 'American Standard Stratocaster', 'O padrÃ£o norte americano da guitarra mais versÃ¡til existente.', 'Fender_Standard_Stratocaster.jpg', 4500.75),
(11, 23, 7, 'Standard Les Paul', 'O padrÃ£o da felicidade.', 'Gibson_LesPaul.jpg', 13750.5),
(12, 21, 8, 'American Vintage Telecaster', 'A sucessora da Fender Broadcaster.', 'Fender_TELECASTER_Vintage_52.jpg', 12500.7),
(17, 21, 9, 'American Vintage Jaguar', 'Um dos mais clÃ¡ssicos e antigos projetos da Fender.', 'Fender_JAGUAR_Vintage_62.jpg', 15875.4),
(10, 21, 10, 'American Artist SRV Stratocaster', 'Uma rÃ©plica fiel de nosso coleguinha Stevie Ray Vaughan.', 'Fender_SRV.jpg', 17500),
(10, 21, 11, 'American Artist David Gilmour NOS', 'A guitarra preferida do guitarrista do Pink Floyd.', 'David Gilmour - Blck Strat NOS.jpg', 25700.2),
(19, 21, 12, 'Mustang American Vintage', 'O bom e velho projeto da Fender, agora em rÃ©plica para nÃ³s!', 'fender-mustang-guitar.jpg', 15750.7),
(20, 23, 13, 'SG Custom', 'Tony Yommi e Angus Young curtiram muito esse modelo.', 'Gibson_SG.jpg', 17500.7);

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `produto`
--
ALTER TABLE `produto`
  ADD CONSTRAINT `produto_ibfk_1` FOREIGN KEY (`codCategoria`) REFERENCES `categoria` (`codCategoria`),
  ADD CONSTRAINT `produto_ibfk_2` FOREIGN KEY (`codMarca`) REFERENCES `marca` (`codMarca`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
