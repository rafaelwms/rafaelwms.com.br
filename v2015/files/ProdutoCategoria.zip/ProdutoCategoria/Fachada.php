<?php

session_start();


if (!isset($_SESSION['msgs'])) {
    $_SESSION['msgs'] = " ";
}



if (isset($_POST['oper'])) {
    $oper = $_POST['oper'];
    echo $oper;
}



switch ($oper) {



    case 'listMarca':
        require 'RepositorioMarca.php';
        $marca = new Marca();
        $repMarca = new RepositorioMarca();
        $listMarca = $repMarca->listMarca();
        return $listMarca;
        break;

    case 'grabMarca':
        if (isset($_POST['addMarca'])) {
            if ($_POST['addMarca']) {
                require 'NegocioMarca.php';
                $rnMarca = new NegocioMarca();
                $marca = new Marca();
                $nomeMarca = $_POST['nomeMarca'];
                $marca->setNomeMarca($nomeMarca);
                try {
                    $rnMarca->addMarca($marca);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Marca " . $marca->getNomeMarca() . " inserida com êxito.";
                } catch (Exception $x) {
                    $_SESSION['msgs'] = $x->getMessage();
                    $alvo = 'index.php';
                }
                break;
            }
        }


        if (isset($_POST['delMarca'])) {

            if ($_POST['delMarca']) {
                require 'NegocioMarca.php';
                $marca = new Marca();
                $codMarca = $_POST['listaMarcas'];
                $rnMarca = new NegocioMarca();
                $marca->setCodMarca($codMarca);
                try {
                    $rnMarca->delMarca($marca);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Marca " . $marca->getNomeMarca() . " removida com êxito.";
                } catch (Exception $x) {
                    $_SESSION['msgs'] = $x->getMessage();
                    $alvo = 'index.php';
                }
                break;
            }
        }



        if (isset($_POST['updMarca'])) {

            if ($_POST['updMarca']) {
                require 'NegocioMarca.php';
                $marca = new Marca();
                $codMarca = $_POST['listaMarcas'];
                $nomeMarca = $_POST['nomeMarca'];
                $rnMarca = new NegocioMarca();
                $marca->setNomemarca($nomeMarca);
                $marca->setCodMarca($codMarca);
                try {
                    $rnMarca->updMarca($marca);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Marca " . $marca->getNomeMarca() . " alterada com êxito.";
                } catch (Exception $x) {
                    $_SESSION['msgs'] = $x->getMessage();
                    $alvo = 'index.php';
                }
                break;
            }
        }



    case 'listCategorias':
        require 'RepositorioCategoria.php';
        $categoria = new Categoria();
        $repCategoria = new RepositorioCategoria();
        $listCategoria = $repCategoria->listCategoria();
        return $listCategoria;
        break;

    case 'grabCat':
        if (isset($_POST['addCategoria'])) {
            if ($_POST['addCategoria']) {
                require 'NegocioCategoria.php';
                $rnCategoria = new NegocioCategoria();
                $categoria = new Categoria();
                $nomeCategoria = $_POST['nomeCategoria'];
                $categoria->setNomeCategoria($nomeCategoria);
                try {
                    $rnCategoria->addCategoria($categoria);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Categoria " . $categoria->getNomeCategoria() . " inserida com êxito.";
                } catch (Exception $x) {
                    $_SESSION['msgs'] = $x->getMessage();
                    $alvo = 'index.php';
                }
                break;
            }
        }


        if (isset($_POST['delCategoria'])) {

            if ($_POST['delCategoria']) {
                require 'NegocioCategoria.php';
                $categoria = new Categoria();
                $codCategoria = $_POST['listaCategorias'];
                $rnCategoria = new NegocioCategoria();
                $categoria->setCodCategoria($codCategoria);
                try {
                    $rnCategoria->delCategoria($categoria);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Categoria " . $categoria->getNomeCategoria() . " removida com êxito.";
                } catch (Exception $x) {
                    $_SESSION['msgs'] = $x->getMessage();
                    $alvo = 'index.php';
                }
                break;
            }
        }



        if (isset($_POST['updCategoria'])) {

            if ($_POST['updCategoria']) {
                require 'NegocioCategoria.php';
                $categoria = new Categoria();
                $codCategoria = $_POST['listaCategorias'];
                $nomeCategoria = $_POST['nomeCategoria'];
                $rnCategoria = new NegocioCategoria();
                $categoria->setNomecategoria($nomeCategoria);
                $categoria->setCodCategoria($codCategoria);
                try {
                    $rnCategoria->updCategoria($categoria);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Categoria " . $categoria->getNomeCategoria() . " alterada com êxito.";
                } catch (Exception $x) {
                    $_SESSION['msgs'] = $x->getMessage();
                    $alvo = 'index.php';
                }
                break;
            }
        }



    case 'listProduto':
        require 'RepositorioProduto.php';
        $produto = new Produto();
        $repProduto = new RepositorioProduto();
        $listProduto = $repProduto->listProduto();
        return $listProduto;
        $alvo = "ListaProdutos.php";
        break;

    case 'grabProduto':

        if (isset($_POST['addProduto'])) {

            if ($_POST['addProduto']) {
                require 'NegocioProduto.php';
                $nomeProduto = $_POST['nomeProduto'];
                $descProduto = $_POST['descProduto'];
                $figuraProduto = $_POST['figuraProduto'];
                $precoProduto = $_POST['precoProduto'];
                $codCategoria = $_POST['prodCategoria'];
                $codMarca = $_POST['prodMarca'];
                $categoria = new Categoria();
                $marca = new Marca();
                $categoria->setCodCategoria($codCategoria);
                $marca->setCodMarca($codMarca);
                $produto = new Produto();
                $produto->setCategoria($categoria);
                $produto->setMarca($marca);
                $produto->setNomeProduto($nomeProduto);
                $produto->setDescProduto($descProduto);
                $produto->setFiguraProduto($figuraProduto);
                $produto->setPrecoProduto($precoProduto);
                $rnProduto = new NegocioProduto();
                try {
                    $rnProduto->addProduto($produto);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Produto " . $produto->getNomeProduto() . " adicionado com êxito.";
                } catch (Exception $x) {
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = $x->getMessage();
                }
                break;
            }
        }

        if (isset($_POST['delProduto'])) {

            if ($_POST['delProduto']) {
                require 'NegocioProduto.php';
                $produto = new Produto();
                $codProduto = $_POST['listaProdutos'];
                $rnProduto = new NegocioProduto();
                $produto->setCodProduto($codProduto);
                try {
                    $rnProduto->delProduto($produto);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Produto " . $produto->getNomeProduto() . " removido com êxito.";
                } catch (Exception $x) {
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = $x->getMessage();
                }
                break;
            }
        }

        if (isset($_POST['updProduto'])) {

            if ($_POST['updProduto']) {
                require 'NegocioProduto.php';
                $produto = new Produto();
                $codProduto = $_POST['listaProdutos'];
                $nomeProduto = $_POST['nomeProduto'];
                $descProduto = $_POST['descProduto'];
                $figuraProduto = $_POST['figuraProduto'];
                $precoProduto = $_POST['precoProduto'];
                $rnProduto = new NegocioProduto();
                $produto->setNomeProduto($nomeProduto);
                $produto->setCodProduto($codProduto);
                $produto->setPrecoProduto($precoProduto);
                $produto->setFiguraProduto($figuraProduto);
                $produto->setDescProduto($descProduto);
                try {
                    $rnProduto->updProduto($produto);
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = "Produto " . $produto->getNomeProduto() . " alterado com êxito.";
                } catch (Exception $x) {
                    $alvo = 'index.php';
                    $_SESSION['msgs'] = $x->getMessage();
                }
                break;
            }
        }
}


header('location:' . $alvo);






