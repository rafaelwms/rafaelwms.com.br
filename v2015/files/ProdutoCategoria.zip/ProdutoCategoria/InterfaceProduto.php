<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rafael
 */
interface InterfaceProduto {

    public function addProduto(Produto $produto);

    public function updProduto(Produto $produto);

    public function delProduto(Produto $produto);

    public function listProduto();
}

?>
