<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Rafael
 */
interface InterfaceMarca {
    
    public function addMarca(Marca $marca);
    
    public function updMarca(Marca $marca);
    
    public function delMarca(Marca $marca);
    
    public function listMarca();
}

?>
